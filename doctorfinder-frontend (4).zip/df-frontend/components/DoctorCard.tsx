import Link from 'next/link'
import { Star, MapPin, Clock, BadgeCheck } from 'lucide-react'
import { DoctorDetail } from '@/types'

export default function DoctorCard({ doctor }: { doctor: DoctorDetail }) {
  const stars = Array.from({ length: 5 }, (_, i) => i < Math.round(Number(doctor.rating) || 0))
  return (
    <Link href={`/doctors/${doctor.id}`}>
      <div className="card p-5 hover:shadow-md transition-shadow cursor-pointer group fade-up">
        <div className="flex gap-4">
          <div className="w-14 h-14 rounded-xl bg-primary-50 flex items-center justify-center text-xl font-bold text-primary-600 flex-shrink-0 group-hover:bg-primary-100 transition-colors">
            {doctor.fullName?.[0] || 'D'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold text-slate-800 group-hover:text-primary-700 transition-colors text-sm">
                  Dr. {doctor.fullName}
                </h3>
                <p className="text-xs text-primary-600 font-medium mt-0.5">
                  {doctor.specialization?.name || 'General Medicine'}
                </p>
              </div>
              <div className="flex flex-col items-end gap-1 flex-shrink-0">
                {doctor.isVerified && (
                  <span className="badge bg-primary-50 text-primary-700 text-xs">
                    <BadgeCheck size={10}/> Verified
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1 mt-1.5">
              {stars.map((f, i) => (
                <Star key={i} size={11} className={f ? 'text-amber-400 fill-amber-400' : 'text-slate-200'} />
              ))}
              <span className="text-xs text-slate-500 ml-1">
                {Number(doctor.rating || 0).toFixed(1)} ({doctor.totalReviews || 0})
              </span>
            </div>

            <div className="flex flex-wrap gap-3 mt-2">
              {doctor.city && (
                <span className="flex items-center gap-1 text-xs text-slate-400">
                  <MapPin size={10}/> {doctor.city}
                </span>
              )}
              <span className="flex items-center gap-1 text-xs text-slate-400">
                <Clock size={10}/> {doctor.experienceYears || 0} yrs
              </span>
              <span className="text-xs font-semibold text-slate-600">
                ₹{doctor.consultationFee || 0}
              </span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  )
}
