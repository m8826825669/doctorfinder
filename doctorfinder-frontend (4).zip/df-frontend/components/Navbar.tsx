'use client'
import Link from 'next/link'
import { useState, useEffect } from 'react'
import { Stethoscope, Menu, X, ChevronDown, LogOut, LayoutDashboard } from 'lucide-react'
import { getUser, logout, getDashboardPath } from '@/lib/auth'
import { User } from '@/types'

export default function Navbar() {
  const [user, setUser]         = useState<User | null>(null)
  const [open, setOpen]         = useState(false)
  const [drop, setDrop]         = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    setUser(getUser())
    const fn = () => setScrolled(window.scrollY > 8)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])

  const roleColor = user?.role === 'ADMIN' ? 'bg-violet-100 text-violet-700'
                  : user?.role === 'DOCTOR' ? 'bg-blue-100 text-blue-700'
                  : 'bg-primary-100 text-primary-700'

  return (
    <nav className={`fixed inset-x-0 top-0 z-50 transition-all ${scrolled ? 'bg-white/95 backdrop-blur shadow-sm border-b border-slate-100' : 'bg-white'}`}>
      <div className="page">
        <div className="flex items-center justify-between h-16">

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
              <Stethoscope size={17} className="text-white" />
            </div>
            <span className="font-bold text-lg text-slate-800">
              Doctor<span className="text-primary-600">Finder</span>
            </span>
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-1">
            <Link href="/" className="btn-ghost">Home</Link>
            {user && <Link href={getDashboardPath(user.role)} className="btn-ghost">Dashboard</Link>}
          </div>

          {/* Right */}
          <div className="hidden md:flex items-center gap-2">
            {user ? (
              <div className="relative">
                <button onClick={() => setDrop(v => !v)}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-slate-50">
                  <div className="w-7 h-7 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-xs font-bold text-primary-700">{user.fullName?.[0] || 'U'}</span>
                  </div>
                  <span className="text-sm font-medium text-slate-700">{user.fullName?.split(' ')[0]}</span>
                  <span className={`badge text-xs ${roleColor}`}>{user.role}</span>
                  <ChevronDown size={13} className={`text-slate-400 transition-transform ${drop ? 'rotate-180' : ''}`} />
                </button>

                {drop && (
                  <div className="absolute right-0 top-12 w-48 bg-white rounded-2xl shadow-lg border border-slate-100 py-2 z-50">
                    <div className="px-4 py-2 border-b border-slate-50 mb-1">
                      <p className="text-xs text-slate-400 truncate">{user.email}</p>
                    </div>
                    <Link href={getDashboardPath(user.role)} onClick={() => setDrop(false)}
                      className="flex items-center gap-2 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">
                      <LayoutDashboard size={14}/> Dashboard
                    </Link>
                    <button onClick={logout}
                      className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50">
                      <LogOut size={14}/> Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link href="/auth/login" className="btn-ghost">Sign In</Link>
                <Link href="/auth/register" className="btn-primary">Get Started</Link>
              </>
            )}
          </div>

          {/* Mobile toggle */}
          <button className="md:hidden p-2 rounded-xl hover:bg-slate-100" onClick={() => setOpen(v => !v)}>
            {open ? <X size={20}/> : <Menu size={20}/>}
          </button>
        </div>

        {/* Mobile menu */}
        {open && (
          <div className="md:hidden border-t border-slate-100 py-3 space-y-1 fade-up">
            <Link href="/" className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl">Home</Link>
            {user ? (
              <>
                <Link href={getDashboardPath(user.role)} className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl">Dashboard</Link>
                <button onClick={logout} className="w-full text-left px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 rounded-xl">Sign Out</button>
              </>
            ) : (
              <>
                <Link href="/auth/login" className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl">Sign In</Link>
                <Link href="/auth/register" className="block px-4 py-2.5 text-sm font-semibold text-primary-700 hover:bg-primary-50 rounded-xl">Get Started</Link>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  )
}
