import Cookies from 'js-cookie'
import { User } from '@/types'

export const getUser = (): User | null => {
  try {
    const u = Cookies.get('user')
    return u ? JSON.parse(u) : null
  } catch { return null }
}

export const getToken  = (): string | null => Cookies.get('token') || null
export const isLoggedIn = (): boolean => !!getToken()

export const saveAuth = (token: string, refreshToken: string, user: User) => {
  Cookies.set('token',        token,                     { expires: 1 })
  Cookies.set('refreshToken', refreshToken,              { expires: 7 })
  Cookies.set('user',         JSON.stringify(user),      { expires: 1 })
}

export const logout = () => {
  Cookies.remove('token')
  Cookies.remove('refreshToken')
  Cookies.remove('user')
  window.location.href = '/auth/login'
}

export const getDashboardPath = (role: string): string => {
  if (role === 'DOCTOR') return '/dashboard/doctor'
  if (role === 'ADMIN')  return '/admin'
  return '/dashboard/patient'
}
