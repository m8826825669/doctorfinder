import axios from 'axios'
import Cookies from 'js-cookie'

const BASE = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api/v1'

export const api = axios.create({ baseURL: BASE })

// Attach JWT to every request
api.interceptors.request.use(cfg => {
  const token = Cookies.get('token')
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
})

// Auto refresh on 401
api.interceptors.response.use(
  res => res,
  async err => {
    const orig = err.config
    if (err.response?.status === 401 && !orig._retry) {
      orig._retry = true
      try {
        const refresh = Cookies.get('refreshToken')
        if (!refresh) throw new Error('no refresh')
        const { data } = await axios.post(`${BASE}/auth/refresh`, { refresh_token: refresh, refreshToken: refresh })
        const newToken = data.access_token || data.accessToken
        Cookies.set('token', newToken, { expires: 1 })
        orig.headers.Authorization = `Bearer ${newToken}`
        return api(orig)
      } catch {
        Cookies.remove('token'); Cookies.remove('refreshToken'); Cookies.remove('user')
        window.location.href = '/auth/login'
      }
    }
    return Promise.reject(err)
  }
)

// ─── Helper: normalize FastAPI snake_case OR Spring camelCase response ──────
export function normalizeAuth(raw: Record<string, unknown>) {
  const token        = (raw.accessToken  || raw.access_token)  as string
  const refreshToken = (raw.refreshToken || raw.refresh_token) as string
  const u = (raw.user || {}) as Record<string, unknown>
  const user = {
    id:        u.id        as string,
    email:     u.email     as string,
    fullName:  (u.fullName || u.full_name) as string,
    role:      (u.role)                    as string,
    phone:     (u.phone)                   as string | undefined,
    createdAt: (u.createdAt || u.created_at) as string,
  }
  return { token, refreshToken, user }
}

// ─── Helper: build register payload supporting both backends ────────────────
function registerPayload(data: {
  email: string; password: string; fullName: string
  role: string; phone?: string
}) {
  // Send both camelCase + snake_case so either backend accepts it
  const p: Record<string, string> = {
    email:     data.email.trim(),
    password:  data.password,
    fullName:  data.fullName.trim(),
    full_name: data.fullName.trim(),
    role:      data.role.toUpperCase(),
  }
  if (data.phone?.trim()) {
    p.phone = data.phone.trim()
  }
  return p
}

// ─── Auth ────────────────────────────────────────────────────────────────────
export const authApi = {
  register: (data: { email: string; password: string; fullName: string; role: string; phone?: string }) =>
    api.post('/auth/register', registerPayload(data)),

  login: (email: string, password: string) =>
    api.post('/auth/login', { email: email.trim(), password }),

  me: () => api.get('/auth/me'),

  changePassword: (oldPassword: string, newPassword: string) =>
    api.post('/auth/change-password', {
      oldPassword, old_password: oldPassword,
      newPassword, new_password: newPassword,
    }),
}

// ─── Doctors ─────────────────────────────────────────────────────────────────
export const doctorApi = {
  search: (params: Record<string, unknown>) =>
    api.get('/doctors/search', { params }),

  getById: (id: string) => api.get(`/doctors/${id}`),

  getSpecializations: () => api.get('/doctors/specializations'),

  createProfile: (data: Record<string, unknown>) =>
    api.post('/doctors/profile', data),

  updateProfile: (data: Record<string, unknown>) =>
    api.put('/doctors/profile', data),

  getReviews: (id: string, page = 0, size = 10) =>
    api.get(`/doctors/${id}/reviews`, { params: { page, size } }),

  addAvailability: (id: string, data: Record<string, unknown>) =>
    api.post(`/doctors/${id}/availability`, data),

  getAvailability: (id: string) =>
    api.get(`/doctors/${id}/availability`),

  deleteAvailability: (id: string, aid: string) =>
    api.delete(`/doctors/${id}/availability/${aid}`),

  generateSlots: (id: string, data: { fromDate: string; toDate: string }) =>
    api.post(`/doctors/${id}/slots/generate`, {
      fromDate: data.fromDate, from_date: data.fromDate,
      toDate:   data.toDate,   to_date:   data.toDate,
    }),

  getSlots: (id: string, date: string) =>
    api.get(`/doctors/${id}/slots`, { params: { date } }),

  getSlotsRange: (id: string, from: string, to: string) =>
    api.get(`/doctors/${id}/slots/range`, { params: { from, to } }),
}

// ─── Appointments ─────────────────────────────────────────────────────────────
export const appointmentApi = {
  book: (timeSlotId: string, reason?: string) =>
    api.post('/appointments', {
      timeSlotId, time_slot_id: timeSlotId,
      ...(reason ? { reason } : {}),
    }),

  myAppointments: (page = 0, size = 20) =>
    api.get('/appointments/my', { params: { page, size } }),

  doctorAppointments: (page = 0, size = 50) =>
    api.get('/appointments/doctor', { params: { page, size } }),

  getById: (id: string) => api.get(`/appointments/${id}`),

  updateNotes: (id: string, data: Record<string, string>) =>
    api.patch(`/appointments/${id}`, data),

  confirm:  (id: string) => api.post(`/appointments/${id}/confirm`),
  cancel:   (id: string) => api.post(`/appointments/${id}/cancel`),
  complete: (id: string) => api.post(`/appointments/${id}/complete`),

  review: (id: string, rating: number, comment?: string) =>
    api.post(`/appointments/${id}/review`, { rating, ...(comment ? { comment } : {}) }),
}

// ─── Notifications ────────────────────────────────────────────────────────────
export const notificationApi = {
  getAll:     (page = 0, size = 20) => api.get('/notifications', { params: { page, size } }),
  markRead:   (id: string)          => api.post(`/notifications/${id}/read`),
  markAllRead: ()                   => api.post('/notifications/read-all'),
}

// ─── Admin ────────────────────────────────────────────────────────────────────
export const adminApi = {
  getStats:     ()                          => api.get('/admin/stats'),
  verifyDoctor: (id: string)               => api.post(`/admin/doctors/${id}/verify`),
  featureDoctor:(id: string, f: boolean)   => api.post(`/admin/doctors/${id}/feature`, { featured: f }),
}
