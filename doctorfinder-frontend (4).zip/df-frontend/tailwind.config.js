/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#edfaf5', 100: '#d2f4e5', 200: '#a9e8ce',
          300: '#72d5b0', 400: '#3aba8d', 500: '#1a9e73',
          600: '#0e7f5c', 700: '#0c664b', 800: '#0b513c', 900: '#0a4332',
        },
      },
    },
  },
  plugins: [],
}
