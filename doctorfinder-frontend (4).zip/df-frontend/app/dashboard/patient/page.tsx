'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { appointmentApi, notificationApi } from '@/lib/api'
import { getUser, isLoggedIn } from '@/lib/auth'
import { AppointmentInfo, NotificationInfo, PagedResult, User } from '@/types'
import { Calendar, Bell, Clock, CheckCircle, XCircle, Star, X } from 'lucide-react'
import { format } from 'date-fns'
import toast from 'react-hot-toast'

type Tab = 'appointments' | 'notifications'

const STATUS_CFG = {
  PENDING:   { label: 'Pending',   cls: 'bg-amber-50 text-amber-700' },
  CONFIRMED: { label: 'Confirmed', cls: 'bg-blue-50 text-blue-700' },
  COMPLETED: { label: 'Completed', cls: 'bg-primary-50 text-primary-700' },
  CANCELLED: { label: 'Cancelled', cls: 'bg-red-50 text-red-600' },
}

export default function PatientDashboard() {
  const router = useRouter()
  const [user, setUser]         = useState<User | null>(null)
  const [tab, setTab]           = useState<Tab>('appointments')
  const [appts, setAppts]       = useState<AppointmentInfo[]>([])
  const [notifs, setNotifs]     = useState<NotificationInfo[]>([])
  const [loading, setLoading]   = useState(true)
  const [unread, setUnread]     = useState(0)
  const [reviewId, setReviewId] = useState<string | null>(null)
  const [rating, setRating]     = useState(5)
  const [comment, setComment]   = useState('')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (!u || u.role !== 'PATIENT') { router.push('/'); return }
    setUser(u)
    load()
  }, [])

  const load = async () => {
    setLoading(true)
    try {
      const [a, n] = await Promise.all([
        appointmentApi.myAppointments(0, 30),
        notificationApi.getAll(0, 20),
      ])
      const aList = (a.data as PagedResult<AppointmentInfo>).content || []
      const nList = (n.data as PagedResult<NotificationInfo>).content || []
      setAppts(aList)
      setNotifs(nList)
      setUnread(nList.filter(x => !x.isRead).length)
    } catch { toast.error('Failed to load') }
    finally { setLoading(false) }
  }

  const cancel = async (id: string) => {
    try { await appointmentApi.cancel(id); toast.success('Cancelled'); load() }
    catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string } } }
      toast.error(e?.response?.data?.message || 'Failed to cancel')
    }
  }

  const submitReview = async () => {
    if (!reviewId) return
    setSubmitting(true)
    try {
      await appointmentApi.review(reviewId, rating, comment || undefined)
      toast.success('Review submitted! 🌟')
      setReviewId(null); setRating(5); setComment(''); load()
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string } } }
      toast.error(e?.response?.data?.message || 'Failed to submit review')
    } finally { setSubmitting(false) }
  }

  const markAllRead = async () => {
    await notificationApi.markAllRead()
    setUnread(0)
    setNotifs(n => n.map(x => ({ ...x, isRead: true })))
  }

  const stats = {
    total:     appts.length,
    upcoming:  appts.filter(a => a.status === 'CONFIRMED').length,
    completed: appts.filter(a => a.status === 'COMPLETED').length,
    cancelled: appts.filter(a => a.status === 'CANCELLED').length,
  }

  return (
    <>
      <Navbar/>
      <main className="pt-20 pb-16 min-h-screen bg-slate-50">
        <div className="page">
          <div className="py-6">
            <h1 className="text-2xl font-bold text-slate-800">
              Welcome, {user?.fullName?.split(' ')[0] || 'User'} 👋
            </h1>
            <p className="text-slate-500 text-sm mt-1">Manage your health appointments</p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {[
              { label: 'Total',     val: stats.total,     icon: <Calendar size={16}/>, cls: 'text-blue-600 bg-blue-50' },
              { label: 'Upcoming',  val: stats.upcoming,  icon: <Clock size={16}/>,    cls: 'text-primary-600 bg-primary-50' },
              { label: 'Completed', val: stats.completed, icon: <CheckCircle size={16}/>, cls: 'text-green-600 bg-green-50' },
              { label: 'Cancelled', val: stats.cancelled, icon: <XCircle size={16}/>,  cls: 'text-red-500 bg-red-50' },
            ].map((s, i) => (
              <div key={i} className="card p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-400">{s.label}</span>
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${s.cls}`}>{s.icon}</div>
                </div>
                <p className="text-2xl font-bold text-slate-800">{s.val}</p>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-white rounded-xl p-1 border border-slate-100 w-fit mb-5 shadow-sm">
            {[
              { id: 'appointments'  as Tab, label: 'Appointments' },
              { id: 'notifications' as Tab, label: `Notifications${unread > 0 ? ` (${unread})` : ''}` },
            ].map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
                  tab === t.id ? 'bg-primary-600 text-white' : 'text-slate-500 hover:text-slate-700'
                }`}>
                {t.label}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1,2,3,4].map(i => <div key={i} className="card p-5 animate-pulse h-36"/>)}
            </div>
          ) : tab === 'appointments' ? (
            appts.length === 0 ? (
              <div className="card p-16 text-center">
                <Calendar size={40} className="text-slate-200 mx-auto mb-3"/>
                <p className="text-slate-400 mb-4">No appointments yet</p>
                <button onClick={() => router.push('/')} className="btn-primary">Find Doctors</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {appts.map(a => {
                  const cfg = STATUS_CFG[a.status]
                  return (
                    <div key={a.id} className="card p-5 fade-up">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-semibold text-slate-800 text-sm">Dr. {a.doctor?.fullName}</p>
                          <p className="text-xs text-primary-600">{a.doctor?.specialization?.name}</p>
                        </div>
                        <span className={`badge text-xs ${cfg.cls}`}>{cfg.label}</span>
                      </div>
                      <div className="flex gap-4 text-xs text-slate-400 mb-3">
                        <span className="flex items-center gap-1">
                          <Calendar size={11}/>
                          {a.timeSlot?.slotDate ? format(new Date(a.timeSlot.slotDate), 'dd MMM yyyy') : '—'}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock size={11}/>
                          {a.timeSlot?.startTime?.slice(0,5)}
                        </span>
                        {a.amount != null && <span className="font-semibold text-slate-600">₹{a.amount}</span>}
                      </div>
                      {a.reason && <p className="text-xs text-slate-500 bg-slate-50 rounded-lg px-3 py-2 mb-3">{a.reason}</p>}
                      <div className="flex gap-2 flex-wrap">
                        {(a.status === 'PENDING' || a.status === 'CONFIRMED') && (
                          <button onClick={() => cancel(a.id)} className="btn-danger text-xs py-1.5 px-3">Cancel</button>
                        )}
                        {a.status === 'COMPLETED' && (
                          <button onClick={() => setReviewId(a.id)} className="btn-outline text-xs py-1.5 px-3">Leave Review</button>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )
          ) : (
            <div className="space-y-3">
              {unread > 0 && (
                <div className="flex justify-end">
                  <button onClick={markAllRead} className="text-sm text-primary-600 hover:underline">Mark all read</button>
                </div>
              )}
              {notifs.length === 0 ? (
                <div className="card p-16 text-center">
                  <Bell size={40} className="text-slate-200 mx-auto mb-3"/>
                  <p className="text-slate-400">No notifications</p>
                </div>
              ) : notifs.map(n => (
                <div key={n.id} className={`card p-4 flex gap-3 ${!n.isRead ? 'border-l-4 border-l-primary-500' : ''}`}>
                  <div className="w-8 h-8 rounded-xl bg-primary-50 flex items-center justify-center flex-shrink-0">
                    <Bell size={13} className="text-primary-500"/>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-slate-700">{n.title}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{n.message}</p>
                  </div>
                  {!n.isRead && <div className="w-2 h-2 bg-primary-500 rounded-full mt-1.5 flex-shrink-0"/>}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Review Modal */}
      {reviewId && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 fade-up">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-800">Leave a Review</h3>
              <button onClick={() => setReviewId(null)}><X size={18} className="text-slate-400"/></button>
            </div>
            <div className="text-center mb-5">
              <p className="text-sm text-slate-500 mb-3">How was your experience?</p>
              <div className="flex justify-center gap-2">
                {[1,2,3,4,5].map(s => (
                  <button key={s} onClick={() => setRating(s)}>
                    <Star size={30} className={s <= rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200'}/>
                  </button>
                ))}
              </div>
              <p className="text-sm font-semibold text-primary-600 mt-2">
                {['','Poor','Fair','Good','Very Good','Excellent'][rating]}
              </p>
            </div>
            <label className="label">Comment (optional)</label>
            <textarea className="input resize-none mb-4" rows={3}
              placeholder="Share your experience..."
              value={comment} onChange={e => setComment(e.target.value)}/>
            <div className="flex gap-3">
              <button onClick={() => setReviewId(null)} className="btn-ghost flex-1">Cancel</button>
              <button onClick={submitReview} disabled={submitting} className="btn-primary flex-1">
                {submitting ? <span className="spin"/> : null}
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
