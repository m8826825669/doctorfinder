'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { appointmentApi, doctorApi } from '@/lib/api'
import { getUser, isLoggedIn } from '@/lib/auth'
import { AppointmentInfo, AvailabilityInfo, PagedResult, User } from '@/types'
import { Calendar, Clock, Plus, Trash2, Layers, X, CheckCircle } from 'lucide-react'
import { format, addDays } from 'date-fns'
import toast from 'react-hot-toast'

type Tab = 'appointments' | 'availability' | 'slots'
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
const STATUS_CFG = {
  PENDING:   { label: 'Pending',   cls: 'bg-amber-50 text-amber-700' },
  CONFIRMED: { label: 'Confirmed', cls: 'bg-blue-50 text-blue-700' },
  COMPLETED: { label: 'Completed', cls: 'bg-primary-50 text-primary-700' },
  CANCELLED: { label: 'Cancelled', cls: 'bg-red-50 text-red-600' },
}

export default function DoctorDashboard() {
  const router = useRouter()
  const [user, setUser]           = useState<User | null>(null)
  const [tab, setTab]             = useState<Tab>('appointments')
  const [appts, setAppts]         = useState<AppointmentInfo[]>([])
  const [avList, setAvList]       = useState<AvailabilityInfo[]>([])
  const [doctorId, setDoctorId]   = useState('')
  const [loading, setLoading]     = useState(true)
  const [avForm, setAvForm]       = useState({ dayOfWeek: 0, startTime: '09:00', endTime: '17:00', slotDuration: 30 })
  const [savingAv, setSavingAv]   = useState(false)
  const [slotForm, setSlotForm]   = useState({
    fromDate: format(new Date(), 'yyyy-MM-dd'),
    toDate:   format(addDays(new Date(), 6), 'yyyy-MM-dd'),
  })
  const [genSlots, setGenSlots]   = useState(false)
  const [notesId, setNotesId]     = useState('')
  const [notes, setNotes]         = useState({ notes: '', prescription: '', diagnosis: '' })
  const [savingNotes, setSavingNotes] = useState(false)

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (!u || u.role !== 'DOCTOR') { router.push('/'); return }
    setUser(u)
    load()
  }, [])

  const load = async () => {
    setLoading(true)
    try {
      const a = await appointmentApi.doctorAppointments(0, 50)
      const list = (a.data as PagedResult<AppointmentInfo>).content || []
      setAppts(list)
      if (list.length > 0 && list[0].doctor?.id) {
        const did = list[0].doctor.id
        setDoctorId(did)
        const av = await doctorApi.getAvailability(did)
        setAvList(Array.isArray(av.data) ? av.data : [])
      }
    } catch { toast.error('Failed to load') }
    finally { setLoading(false) }
  }

  const doAction = async (action: string, id: string) => {
    try {
      if (action === 'confirm')  await appointmentApi.confirm(id)
      if (action === 'complete') await appointmentApi.complete(id)
      if (action === 'cancel')   await appointmentApi.cancel(id)
      toast.success(`Appointment ${action}ed`)
      load()
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string } } }
      toast.error(e?.response?.data?.message || 'Action failed')
    }
  }

  const addAv = async () => {
    if (!doctorId) { toast.error('No doctor profile found. Create profile first.'); return }
    setSavingAv(true)
    try {
      await doctorApi.addAvailability(doctorId, {
        ...avForm,
        startTime: avForm.startTime + ':00',
        endTime:   avForm.endTime   + ':00',
      })
      toast.success('Schedule added!')
      const av = await doctorApi.getAvailability(doctorId)
      setAvList(Array.isArray(av.data) ? av.data : [])
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string } } }
      toast.error(e?.response?.data?.message || 'Failed')
    } finally { setSavingAv(false) }
  }

  const deleteAv = async (aid: string) => {
    if (!doctorId) return
    try {
      await doctorApi.deleteAvailability(doctorId, aid)
      setAvList(a => a.filter(x => x.id !== aid))
      toast.success('Removed')
    } catch { toast.error('Failed to delete') }
  }

  const generateSlots = async () => {
    if (!doctorId) { toast.error('No doctor profile'); return }
    if (avList.length === 0) { toast.error('Add availability schedule first'); return }
    setGenSlots(true)
    try {
      const res = await doctorApi.generateSlots(doctorId, slotForm)
      toast.success(res.data?.message || 'Slots generated!')
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string } } }
      toast.error(e?.response?.data?.message || 'Failed to generate slots')
    } finally { setGenSlots(false) }
  }

  const saveNotes = async () => {
    setSavingNotes(true)
    try {
      await appointmentApi.updateNotes(notesId, notes)
      toast.success('Notes saved!')
      setNotesId('')
      setNotes({ notes: '', prescription: '', diagnosis: '' })
    } catch { toast.error('Failed to save') }
    finally { setSavingNotes(false) }
  }

  const stats = {
    total:    appts.length,
    pending:  appts.filter(a => a.status === 'PENDING').length,
    today:    appts.filter(a => a.timeSlot?.slotDate === format(new Date(), 'yyyy-MM-dd')).length,
    completed:appts.filter(a => a.status === 'COMPLETED').length,
  }

  return (
    <>
      <Navbar/>
      <main className="pt-20 pb-16 min-h-screen bg-slate-50">
        <div className="page">
          <div className="py-6 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-800">Doctor Dashboard</h1>
              <p className="text-slate-500 text-sm mt-1">
                {!doctorId && (
                  <span className="text-amber-600 font-medium">
                    ⚠️ No profile found —{' '}
                    <button onClick={() => router.push('/dashboard/doctor/setup')} className="underline">
                      Create your profile
                    </button>
                  </span>
                )}
              </p>
            </div>
            {!doctorId && (
              <button onClick={() => router.push('/dashboard/doctor/setup')} className="btn-primary text-sm">
                Setup Profile
              </button>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {[
              { label: 'Total',     val: stats.total,     cls: 'text-blue-600 bg-blue-50',    icon: <Calendar size={16}/> },
              { label: "Today's",   val: stats.today,     cls: 'text-amber-600 bg-amber-50',  icon: <Clock size={16}/> },
              { label: 'Pending',   val: stats.pending,   cls: 'text-primary-600 bg-primary-50', icon: <Clock size={16}/> },
              { label: 'Completed', val: stats.completed, cls: 'text-green-600 bg-green-50',  icon: <CheckCircle size={16}/> },
            ].map((s, i) => (
              <div key={i} className="card p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-400">{s.label}</span>
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${s.cls}`}>{s.icon}</div>
                </div>
                <p className="text-2xl font-bold text-slate-800">{s.val}</p>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-white rounded-xl p-1 border border-slate-100 w-fit mb-5 shadow-sm flex-wrap">
            {([
              { id: 'appointments' as Tab, label: 'Appointments' },
              { id: 'availability' as Tab, label: 'Availability' },
              { id: 'slots'        as Tab, label: 'Generate Slots' },
            ]).map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
                  tab === t.id ? 'bg-primary-600 text-white' : 'text-slate-500 hover:text-slate-700'
                }`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* Appointments */}
          {tab === 'appointments' && (
            loading ? <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{[1,2,3,4].map(i => <div key={i} className="card p-5 animate-pulse h-36"/>)}</div>
            : appts.length === 0 ? (
              <div className="card p-16 text-center">
                <Calendar size={40} className="text-slate-200 mx-auto mb-3"/>
                <p className="text-slate-400">No appointments yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {appts.map(a => {
                  const cfg = STATUS_CFG[a.status]
                  return (
                    <div key={a.id} className="card p-5 fade-up">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-semibold text-sm text-slate-800">{a.patient?.fullName}</p>
                          <p className="text-xs text-slate-400">{a.patient?.email}</p>
                        </div>
                        <span className={`badge text-xs ${cfg.cls}`}>{cfg.label}</span>
                      </div>
                      <div className="flex gap-4 text-xs text-slate-400 mb-3">
                        <span className="flex items-center gap-1">
                          <Calendar size={11}/>
                          {a.timeSlot?.slotDate ? format(new Date(a.timeSlot.slotDate), 'dd MMM') : '—'}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock size={11}/>
                          {a.timeSlot?.startTime?.slice(0,5)}
                        </span>
                        {a.amount != null && <span className="font-semibold text-slate-600">₹{a.amount}</span>}
                      </div>
                      {a.reason && <p className="text-xs bg-slate-50 rounded-lg px-3 py-2 text-slate-500 mb-3">{a.reason}</p>}
                      <div className="flex gap-2 flex-wrap">
                        {a.status === 'PENDING'   && <button onClick={() => doAction('confirm', a.id)}  className="btn-primary text-xs py-1.5 px-3">Confirm</button>}
                        {a.status === 'CONFIRMED' && <button onClick={() => doAction('complete', a.id)} className="btn-primary text-xs py-1.5 px-3">Complete</button>}
                        {(a.status === 'PENDING' || a.status === 'CONFIRMED') &&
                          <button onClick={() => doAction('cancel', a.id)} className="btn-danger text-xs py-1.5 px-3">Cancel</button>}
                        <button onClick={() => setNotesId(a.id)}
                          className="text-xs py-1.5 px-3 rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50">
                          + Notes
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            )
          )}

          {/* Availability */}
          {tab === 'availability' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <div className="card p-6">
                <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2 text-sm">
                  <Plus size={15} className="text-primary-500"/> Add Weekly Schedule
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="label">Day of Week</label>
                    <select className="input" value={avForm.dayOfWeek}
                      onChange={e => setAvForm(f => ({ ...f, dayOfWeek: +e.target.value }))}>
                      {DAYS.map((d, i) => <option key={i} value={i}>{d}</option>)}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label">Start Time</label>
                      <input type="time" className="input" value={avForm.startTime}
                        onChange={e => setAvForm(f => ({ ...f, startTime: e.target.value }))}/>
                    </div>
                    <div>
                      <label className="label">End Time</label>
                      <input type="time" className="input" value={avForm.endTime}
                        onChange={e => setAvForm(f => ({ ...f, endTime: e.target.value }))}/>
                    </div>
                  </div>
                  <div>
                    <label className="label">Slot Duration</label>
                    <select className="input" value={avForm.slotDuration}
                      onChange={e => setAvForm(f => ({ ...f, slotDuration: +e.target.value }))}>
                      {[15,20,30,45,60].map(d => <option key={d} value={d}>{d} minutes</option>)}
                    </select>
                  </div>
                  <button onClick={addAv} disabled={savingAv} className="btn-primary w-full">
                    {savingAv ? <span className="spin"/> : <Plus size={15}/>}
                    Add Schedule
                  </button>
                </div>
              </div>

              <div className="card p-6">
                <h3 className="font-semibold text-slate-800 mb-4 text-sm">Current Schedule</h3>
                {avList.length === 0 ? (
                  <p className="text-slate-400 text-sm text-center py-8">No schedule set yet</p>
                ) : (
                  <div className="space-y-2">
                    {avList.map(av => (
                      <div key={av.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                        <div>
                          <p className="font-medium text-slate-700 text-sm">{av.dayName}</p>
                          <p className="text-xs text-slate-400">
                            {av.startTime?.slice(0,5)} – {av.endTime?.slice(0,5)} · {av.slotDuration}min slots
                          </p>
                        </div>
                        <button onClick={() => deleteAv(av.id)}
                          className="w-8 h-8 flex items-center justify-center text-red-400 hover:bg-red-50 rounded-xl">
                          <Trash2 size={14}/>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Slots */}
          {tab === 'slots' && (
            <div className="max-w-lg">
              <div className="card p-6">
                <h3 className="font-semibold text-slate-800 mb-2 flex items-center gap-2 text-sm">
                  <Layers size={15} className="text-primary-500"/> Generate Time Slots
                </h3>
                <p className="text-xs text-slate-400 mb-5">
                  First set your weekly schedule, then generate slots for a date range.
                </p>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="label">From Date</label>
                      <input type="date" className="input" value={slotForm.fromDate}
                        min={format(new Date(), 'yyyy-MM-dd')}
                        onChange={e => setSlotForm(f => ({ ...f, fromDate: e.target.value }))}/>
                    </div>
                    <div>
                      <label className="label">To Date</label>
                      <input type="date" className="input" value={slotForm.toDate}
                        min={slotForm.fromDate}
                        onChange={e => setSlotForm(f => ({ ...f, toDate: e.target.value }))}/>
                    </div>
                  </div>
                  <div className="p-3 bg-primary-50 border border-primary-100 rounded-xl text-xs text-primary-700 space-y-1">
                    <p className="font-medium">ℹ️ How it works</p>
                    <p>• Slots are created from your weekly schedule</p>
                    <p>• Existing bookings are not affected</p>
                    <p>• Duplicate slots are skipped</p>
                  </div>
                  <button onClick={generateSlots} disabled={genSlots} className="btn-primary w-full">
                    {genSlots ? <span className="spin"/> : <Layers size={15}/>}
                    {genSlots ? 'Generating...' : 'Generate Slots'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Notes Modal */}
      {notesId && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6 fade-up">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-800">Clinical Notes</h3>
              <button onClick={() => setNotesId('')}><X size={18} className="text-slate-400"/></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="label">Notes</label>
                <textarea className="input resize-none" rows={3} placeholder="Clinical observations..."
                  value={notes.notes} onChange={e => setNotes(n => ({ ...n, notes: e.target.value }))}/>
              </div>
              <div>
                <label className="label">Prescription</label>
                <textarea className="input resize-none" rows={3} placeholder="Prescribed medications..."
                  value={notes.prescription} onChange={e => setNotes(n => ({ ...n, prescription: e.target.value }))}/>
              </div>
              <div>
                <label className="label">Diagnosis</label>
                <textarea className="input resize-none" rows={2} placeholder="Diagnosis..."
                  value={notes.diagnosis} onChange={e => setNotes(n => ({ ...n, diagnosis: e.target.value }))}/>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <button onClick={() => setNotesId('')} className="btn-ghost flex-1">Cancel</button>
              <button onClick={saveNotes} disabled={savingNotes} className="btn-primary flex-1">
                {savingNotes ? <span className="spin"/> : null} Save
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
