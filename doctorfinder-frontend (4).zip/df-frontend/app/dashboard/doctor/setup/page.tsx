'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { doctorApi } from '@/lib/api'
import { isLoggedIn, getUser } from '@/lib/auth'
import { Specialization } from '@/types'
import toast from 'react-hot-toast'

export default function DoctorSetupPage() {
  const router = useRouter()
  const [specs, setSpecs]     = useState<Specialization[]>([])
  const [loading, setLoading] = useState(false)
  const [form, setForm]       = useState({
    specializationId: '', bio: '', experienceYears: '',
    consultationFee: '', qualification: '', clinicName: '',
    clinicAddress: '', city: '', state: '', languages: '',
  })

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (!u || u.role !== 'DOCTOR') { router.push('/'); return }
    doctorApi.getSpecializations()
      .then(r => setSpecs(Array.isArray(r.data) ? r.data : r.data?.content || []))
      .catch(() => {})
  }, [])

  const up = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const payload: Record<string, unknown> = {}
      if (form.specializationId) payload.specializationId = +form.specializationId
      if (form.bio.trim())        payload.bio              = form.bio.trim()
      if (form.experienceYears)   payload.experienceYears  = +form.experienceYears
      if (form.consultationFee)   payload.consultationFee  = +form.consultationFee
      if (form.qualification.trim()) payload.qualification = form.qualification.trim()
      if (form.clinicName.trim())    payload.clinicName    = form.clinicName.trim()
      if (form.clinicAddress.trim()) payload.clinicAddress = form.clinicAddress.trim()
      if (form.city.trim())          payload.city          = form.city.trim()
      if (form.state.trim())         payload.state         = form.state.trim()
      if (form.languages.trim()) {
        payload.languages = form.languages.split(',').map(l => l.trim()).filter(Boolean)
      }

      await doctorApi.createProfile(payload)
      toast.success('Profile created!')
      router.push('/dashboard/doctor')
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string; detail?: unknown } } }
      const detail = e?.response?.data?.detail
      let msg = e?.response?.data?.message || 'Failed to create profile'
      if (Array.isArray(detail)) {
        msg = detail.map((d: { msg: string }) => d.msg).join(', ')
      }
      toast.error(msg)
      console.error(e?.response?.data)
    } finally { setLoading(false) }
  }

  return (
    <>
      <Navbar/>
      <main className="pt-24 pb-16 min-h-screen bg-slate-50">
        <div className="page max-w-2xl">
          <div className="text-center mb-7">
            <h1 className="text-2xl font-bold text-slate-800">Complete Your Doctor Profile</h1>
            <p className="text-slate-500 text-sm mt-1">Patients will see this information when booking</p>
          </div>

          <div className="card p-7 fade-up">
            <form onSubmit={submit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Specialization</label>
                  <select className="input" value={form.specializationId}
                    onChange={e => up('specializationId', e.target.value)}>
                    <option value="">Select...</option>
                    {specs.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Qualification</label>
                  <input className="input" placeholder="MBBS, MD..."
                    value={form.qualification} onChange={e => up('qualification', e.target.value)}/>
                </div>
              </div>

              <div>
                <label className="label">Bio</label>
                <textarea className="input resize-none" rows={3}
                  placeholder="Tell patients about yourself..."
                  value={form.bio} onChange={e => up('bio', e.target.value)}/>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Experience (years)</label>
                  <input type="number" className="input" min="0" placeholder="5"
                    value={form.experienceYears} onChange={e => up('experienceYears', e.target.value)}/>
                </div>
                <div>
                  <label className="label">Consultation Fee (₹)</label>
                  <input type="number" className="input" min="0" placeholder="500"
                    value={form.consultationFee} onChange={e => up('consultationFee', e.target.value)}/>
                </div>
              </div>

              <div>
                <label className="label">Clinic Name</label>
                <input className="input" placeholder="Apollo Clinic"
                  value={form.clinicName} onChange={e => up('clinicName', e.target.value)}/>
              </div>

              <div>
                <label className="label">Clinic Address</label>
                <input className="input" placeholder="123 MG Road..."
                  value={form.clinicAddress} onChange={e => up('clinicAddress', e.target.value)}/>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">City</label>
                  <input className="input" placeholder="Delhi"
                    value={form.city} onChange={e => up('city', e.target.value)}/>
                </div>
                <div>
                  <label className="label">State</label>
                  <input className="input" placeholder="Delhi"
                    value={form.state} onChange={e => up('state', e.target.value)}/>
                </div>
              </div>

              <div>
                <label className="label">Languages (comma separated)</label>
                <input className="input" placeholder="Hindi, English"
                  value={form.languages} onChange={e => up('languages', e.target.value)}/>
              </div>

              <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
                {loading ? <span className="spin"/> : null}
                {loading ? 'Saving...' : 'Save Profile'}
              </button>
            </form>
          </div>
        </div>
      </main>
    </>
  )
}
