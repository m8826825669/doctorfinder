import type { Metadata } from 'next'
import './globals.css'
import { Toaster } from 'react-hot-toast'

export const metadata: Metadata = {
  title: 'DoctorFinder',
  description: 'Find & book doctors instantly',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body suppressHydrationWarning>
        {children}
        <Toaster position="top-right"
          toastOptions={{
            style: { fontSize: '13px', borderRadius: '12px', border: '1px solid #e2e8f0' },
            success: { iconTheme: { primary: '#0e7f5c', secondary: '#fff' } },
          }}
        />
      </body>
    </html>
  )
}
