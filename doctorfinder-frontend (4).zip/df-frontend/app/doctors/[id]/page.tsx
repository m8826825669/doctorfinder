'use client'
import { use, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { doctorApi, appointmentApi } from '@/lib/api'
import { DoctorDetail, SlotInfo, ReviewInfo, PagedResult } from '@/types'
import { isLoggedIn } from '@/lib/auth'
import { Star, MapPin, Clock, BadgeCheck, Calendar, ChevronLeft, X } from 'lucide-react'
import { format, addDays } from 'date-fns'
import toast from 'react-hot-toast'

export default function DoctorPage({ params }: { params: Promise<{ id: string }> }) {
  const { id }  = use(params)
  const router  = useRouter()

  const [doctor, setDoctor]     = useState<DoctorDetail | null>(null)
  const [reviews, setReviews]   = useState<ReviewInfo[]>([])
  const [slots, setSlots]       = useState<SlotInfo[]>([])
  const [loading, setLoading]   = useState(true)
  const [selDate, setSelDate]   = useState(format(new Date(), 'yyyy-MM-dd'))
  const [selSlot, setSelSlot]   = useState<SlotInfo | null>(null)
  const [reason, setReason]     = useState('')
  const [booking, setBooking]   = useState(false)
  const [modal, setModal]       = useState(false)

  const dates = Array.from({ length: 7 }, (_, i) =>
    format(addDays(new Date(), i), 'yyyy-MM-dd'))

  useEffect(() => {
    Promise.all([doctorApi.getById(id), doctorApi.getReviews(id)])
      .then(([d, r]) => {
        setDoctor(d.data)
        const rev = r.data
        setReviews(Array.isArray(rev) ? rev : (rev as PagedResult<ReviewInfo>).content || [])
      })
      .catch(() => toast.error('Failed to load doctor'))
      .finally(() => setLoading(false))
  }, [id])

  useEffect(() => {
    if (!id) return
    doctorApi.getSlots(id, selDate)
      .then(r => setSlots(Array.isArray(r.data) ? r.data : []))
      .catch(() => setSlots([]))
  }, [id, selDate])

  const book = async () => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    if (!selSlot) { toast.error('Select a slot first'); return }
    setBooking(true)
    try {
      await appointmentApi.book(selSlot.id, reason || undefined)
      toast.success('Appointment booked! 🎉')
      setModal(false); setSelSlot(null); setReason('')
      const r = await doctorApi.getSlots(id, selDate)
      setSlots(Array.isArray(r.data) ? r.data : [])
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string; detail?: string } } }
      toast.error(e?.response?.data?.message || e?.response?.data?.detail || 'Booking failed')
    } finally { setBooking(false) }
  }

  if (loading) return (
    <>
      <Navbar/>
      <div className="pt-24 page animate-pulse space-y-4">
        <div className="h-8 bg-slate-100 rounded w-1/3"/>
        <div className="h-48 bg-slate-100 rounded-2xl"/>
      </div>
    </>
  )
  if (!doctor) return null

  const stars = Array.from({ length: 5 }, (_, i) => i < Math.round(Number(doctor.rating) || 0))

  return (
    <>
      <Navbar/>
      <main className="pt-20 pb-16">
        <div className="page">
          <button onClick={() => router.back()}
            className="flex items-center gap-1 text-sm text-slate-500 hover:text-primary-600 my-5">
            <ChevronLeft size={15}/> Back
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Left */}
            <div className="lg:col-span-2 space-y-4">
              {/* Profile card */}
              <div className="card p-6 fade-up">
                <div className="flex gap-4">
                  <div className="w-20 h-20 rounded-2xl bg-primary-50 flex items-center justify-center text-3xl font-bold text-primary-600 flex-shrink-0">
                    {doctor.fullName?.[0] || 'D'}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <h1 className="text-xl font-bold text-slate-800">Dr. {doctor.fullName}</h1>
                        <p className="text-primary-600 font-medium text-sm">{doctor.specialization?.name}</p>
                        {doctor.qualification && <p className="text-xs text-slate-500 mt-0.5">{doctor.qualification}</p>}
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        {doctor.isVerified && <span className="badge bg-primary-50 text-primary-700 text-xs"><BadgeCheck size={10}/> Verified</span>}
                        {doctor.isFeatured && <span className="badge bg-amber-50 text-amber-700 text-xs">⭐ Featured</span>}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 mt-2">
                      {stars.map((f, i) => <Star key={i} size={13} className={f ? 'text-amber-400 fill-amber-400' : 'text-slate-200'}/>)}
                      <span className="text-sm font-semibold ml-1">{Number(doctor.rating || 0).toFixed(1)}</span>
                      <span className="text-xs text-slate-400">({doctor.totalReviews || 0} reviews)</span>
                    </div>

                    <div className="flex flex-wrap gap-4 mt-2">
                      {doctor.city && <span className="flex items-center gap-1 text-xs text-slate-400"><MapPin size={11}/>{doctor.city}</span>}
                      <span className="flex items-center gap-1 text-xs text-slate-400"><Clock size={11}/>{doctor.experienceYears || 0} yrs exp</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-5 pt-5 border-t border-slate-50">
                  {[
                    { label: 'Fee',        value: `₹${doctor.consultationFee || 0}` },
                    { label: 'Experience', value: `${doctor.experienceYears || 0} Yrs` },
                    { label: 'Reviews',    value: String(doctor.totalReviews || 0) },
                  ].map(s => (
                    <div key={s.label} className="text-center p-3 bg-slate-50 rounded-xl">
                      <p className="font-bold text-slate-800">{s.value}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {doctor.bio && (
                <div className="card p-5 fade-up">
                  <h2 className="font-semibold text-slate-800 mb-2 text-sm">About</h2>
                  <p className="text-slate-600 text-sm leading-relaxed">{doctor.bio}</p>
                </div>
              )}

              {doctor.clinicName && (
                <div className="card p-5 fade-up">
                  <h2 className="font-semibold text-slate-800 mb-2 text-sm">Clinic</h2>
                  <p className="font-medium text-slate-700 text-sm">{doctor.clinicName}</p>
                  {doctor.clinicAddress && <p className="text-xs text-slate-400 mt-1">{doctor.clinicAddress}</p>}
                </div>
              )}

              {reviews.length > 0 && (
                <div className="card p-5 fade-up">
                  <h2 className="font-semibold text-slate-800 mb-4 text-sm">Reviews</h2>
                  <div className="space-y-3">
                    {reviews.map(r => (
                      <div key={r.id} className="pb-3 border-b border-slate-50 last:border-0 last:pb-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-slate-700">{r.patient?.fullName || 'Anonymous'}</span>
                          <div className="flex">
                            {Array.from({ length: 5 }, (_, i) => (
                              <Star key={i} size={11} className={i < r.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-200'}/>
                            ))}
                          </div>
                        </div>
                        {r.comment && <p className="text-xs text-slate-500">{r.comment}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right — Booking */}
            <div>
              <div className="card p-5 sticky top-24 fade-up">
                <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2 text-sm">
                  <Calendar size={15} className="text-primary-500"/> Book Appointment
                </h2>

                {/* Date strip */}
                <div className="flex gap-1.5 overflow-x-auto pb-2 mb-4">
                  {dates.map(d => {
                    const dt = new Date(d)
                    return (
                      <button key={d} onClick={() => { setSelDate(d); setSelSlot(null) }}
                        className={`flex-shrink-0 flex flex-col items-center px-2.5 py-2 rounded-xl border text-xs transition-all ${
                          selDate === d ? 'bg-primary-600 border-primary-600 text-white' : 'border-slate-200 text-slate-600 hover:border-primary-300'
                        }`}>
                        <span>{format(dt, 'EEE')}</span>
                        <span className="font-bold text-sm">{format(dt, 'd')}</span>
                        <span>{format(dt, 'MMM')}</span>
                      </button>
                    )
                  })}
                </div>

                <p className="text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wide">Available Slots</p>
                {slots.length === 0 ? (
                  <p className="text-sm text-slate-400 text-center py-4">No slots on this date</p>
                ) : (
                  <div className="grid grid-cols-3 gap-1.5">
                    {slots.map(s => (
                      <button key={s.id} onClick={() => setSelSlot(s)}
                        className={`text-xs py-2 rounded-xl border text-center transition-all ${
                          selSlot?.id === s.id ? 'bg-primary-600 border-primary-600 text-white font-semibold' : 'border-slate-200 text-slate-600 hover:border-primary-400'
                        }`}>
                        {s.startTime?.slice(0, 5)}
                      </button>
                    ))}
                  </div>
                )}

                {selSlot && (
                  <div className="mt-3 p-3 bg-primary-50 rounded-xl border border-primary-100 text-sm">
                    <p className="text-primary-700 font-medium text-xs">Selected</p>
                    <p className="font-semibold text-primary-800">
                      {format(new Date(selDate), 'dd MMM')} · {selSlot.startTime?.slice(0,5)}
                    </p>
                    <p className="text-xs text-primary-600 mt-0.5">Fee: ₹{doctor.consultationFee || 0}</p>
                  </div>
                )}

                <button
                  onClick={() => {
                    if (!isLoggedIn()) { router.push('/auth/login'); return }
                    if (!selSlot) { toast.error('Select a slot first'); return }
                    setModal(true)
                  }}
                  disabled={!selSlot}
                  className="btn-primary w-full mt-4 disabled:opacity-40"
                >
                  Book Appointment
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Booking modal */}
      {modal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 fade-up">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-800">Confirm Appointment</h3>
              <button onClick={() => setModal(false)}><X size={18} className="text-slate-400"/></button>
            </div>
            <div className="bg-slate-50 rounded-xl p-4 mb-4 text-sm space-y-1.5">
              <p><span className="text-slate-400">Doctor:</span> <span className="font-medium">Dr. {doctor.fullName}</span></p>
              <p><span className="text-slate-400">Date:</span> <span className="font-medium">{format(new Date(selDate), 'dd MMM yyyy')}</span></p>
              <p><span className="text-slate-400">Time:</span> <span className="font-medium">{selSlot?.startTime?.slice(0, 5)}</span></p>
              <p><span className="text-slate-400">Fee:</span> <span className="font-semibold text-primary-700">₹{doctor.consultationFee}</span></p>
            </div>
            <label className="label">Reason (optional)</label>
            <textarea className="input resize-none mb-4" rows={3}
              placeholder="Describe your symptoms..."
              value={reason} onChange={e => setReason(e.target.value)}/>
            <div className="flex gap-3">
              <button onClick={() => setModal(false)} className="btn-ghost flex-1">Cancel</button>
              <button onClick={book} disabled={booking} className="btn-primary flex-1">
                {booking ? <span className="spin"/> : null}
                {booking ? 'Booking...' : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
