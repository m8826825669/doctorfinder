'use client'
import { useState, useEffect } from 'react'
import { Search, MapPin, Shield, Stethoscope } from 'lucide-react'
import Navbar from '@/components/Navbar'
import DoctorCard from '@/components/DoctorCard'
import { doctorApi } from '@/lib/api'
import { DoctorDetail, Specialization, PagedResult } from '@/types'
import toast from 'react-hot-toast'

const SPEC_ICONS: Record<string, string> = {
  'General Medicine':'🩺','Cardiology':'❤️','Dermatology':'✨','Orthopedics':'🦴',
  'Pediatrics':'👶','Gynecology':'🌸','Neurology':'🧠','Psychiatry':'💭',
  'ENT':'👂','Ophthalmology':'👁️','Dentistry':'🦷','Gastroenterology':'🫁',
  'Pulmonology':'🫁','Endocrinology':'⚗️','Urology':'🔬',
}

export default function HomePage() {
  const [query, setQuery]         = useState('')
  const [city, setCity]           = useState('')
  const [specs, setSpecs]         = useState<Specialization[]>([])
  const [specId, setSpecId]       = useState<number|null>(null)
  const [doctors, setDoctors]     = useState<DoctorDetail[]>([])
  const [total, setTotal]         = useState(0)
  const [loading, setLoading]     = useState(false)
  const [searched, setSearched]   = useState(false)

  useEffect(() => {
    doctorApi.getSpecializations()
      .then(r => setSpecs(Array.isArray(r.data) ? r.data : r.data?.content || []))
      .catch(() => {})
  }, [])

  const search = async (overrideSpecId?: number | null) => {
    setLoading(true); setSearched(true)
    try {
      const sid = overrideSpecId !== undefined ? overrideSpecId : specId
      const params: Record<string, unknown> = { page: 0, size: 12 }
      if (query.trim()) params.q = query.trim()
      if (city.trim())  params.city = city.trim()
      if (sid != null)  params.specializationId = sid
      const r = await doctorApi.search(params)
      const data: PagedResult<DoctorDetail> = r.data
      setDoctors(data.content || [])
      setTotal(data.totalElements || 0)
    } catch { toast.error('Search failed') }
    finally { setLoading(false) }
  }

  const toggleSpec = (id: number) => {
    const next = specId === id ? null : id
    setSpecId(next)
    search(next)
  }

  return (
    <>
      <Navbar />
      <main className="pt-16">
        {/* Hero */}
        <section className="bg-gradient-to-br from-primary-700 to-primary-900 py-20">
          <div className="page text-center">
            <div className="inline-flex items-center gap-2 bg-white/15 text-white text-xs font-medium px-4 py-2 rounded-full mb-5">
              <Shield size={13}/> Trusted Doctor Booking Platform
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight">
              Find the Right Doctor,<br/>
              <span className="text-primary-200">Right Now</span>
            </h1>
            <p className="text-primary-100 mb-10 text-lg">Book verified specialists instantly</p>

            <form onSubmit={e => { e.preventDefault(); search() }}
              className="bg-white rounded-2xl shadow-xl p-2 flex flex-col sm:flex-row gap-2 max-w-2xl mx-auto">
              <div className="flex items-center gap-2 px-3 flex-1">
                <Search size={15} className="text-slate-400"/>
                <input value={query} onChange={e => setQuery(e.target.value)}
                  placeholder="Doctor name or specialization..."
                  className="flex-1 py-2.5 text-sm text-slate-700 outline-none placeholder-slate-400 bg-transparent"/>
              </div>
              <div className="flex items-center gap-2 px-3 sm:border-l border-slate-100">
                <MapPin size={15} className="text-slate-400"/>
                <input value={city} onChange={e => setCity(e.target.value)}
                  placeholder="City"
                  className="w-24 py-2.5 text-sm text-slate-700 outline-none placeholder-slate-400 bg-transparent"/>
              </div>
              <button type="submit" className="btn-primary rounded-xl">Search</button>
            </form>
          </div>
        </section>

        {/* Specializations */}
        <section className="page py-10">
          <h2 className="text-xl font-bold text-slate-800 mb-5">Browse by Specialization</h2>
          <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 gap-2">
            {specs.map(s => (
              <button key={s.id} onClick={() => toggleSpec(s.id)}
                className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 text-center transition-all hover:border-primary-400 ${
                  specId === s.id ? 'border-primary-500 bg-primary-50' : 'border-slate-100 bg-white'
                }`}>
                <span className="text-xl">{SPEC_ICONS[s.name] || '🏥'}</span>
                <span className="text-xs font-medium text-slate-600 leading-tight">{s.name}</span>
              </button>
            ))}
          </div>
        </section>

        {/* Results */}
        <section className="page pb-16">
          {loading && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="card p-5 animate-pulse h-36">
                  <div className="flex gap-3">
                    <div className="w-14 h-14 bg-slate-100 rounded-xl"/>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-slate-100 rounded w-2/3"/>
                      <div className="h-3 bg-slate-100 rounded w-1/2"/>
                      <div className="h-3 bg-slate-100 rounded w-1/3"/>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {!loading && searched && (
            <>
              <p className="text-sm text-slate-500 mb-4">{total} doctor{total !== 1 ? 's' : ''} found</p>
              {doctors.length === 0 ? (
                <div className="text-center py-16 card">
                  <Stethoscope size={40} className="text-slate-200 mx-auto mb-3"/>
                  <p className="text-slate-400">No doctors found. Try different filters.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {doctors.map(d => <DoctorCard key={d.id} doctor={d}/>)}
                </div>
              )}
            </>
          )}

          {!loading && !searched && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-3">
                <Search size={26} className="text-primary-400"/>
              </div>
              <p className="text-slate-500 mb-4">Search for doctors above, or</p>
              <button onClick={() => search()} className="btn-outline">Show All Doctors</button>
            </div>
          )}
        </section>

        <footer className="bg-slate-900 text-slate-400 py-8">
          <div className="page text-center text-sm">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Stethoscope size={16} className="text-primary-400"/>
              <span className="font-bold text-white">DoctorFinder</span>
            </div>
            © 2025 DoctorFinder. All rights reserved.
          </div>
        </footer>
      </main>
    </>
  )
}
