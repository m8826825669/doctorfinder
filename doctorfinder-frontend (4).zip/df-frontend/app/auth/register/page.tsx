'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Stethoscope, Eye, EyeOff, Lock } from 'lucide-react'
import { authApi, normalizeAuth } from '@/lib/api'
import { saveAuth, getDashboardPath } from '@/lib/auth'
import toast from 'react-hot-toast'

type Role = 'PATIENT' | 'DOCTOR' | 'ADMIN'
const ADMIN_SECRET = process.env.NEXT_PUBLIC_ADMIN_SECRET || 'DOCFINDER@ADMIN2025'

const ROLES: { id: Role; label: string; icon: string; desc: string }[] = [
  { id: 'PATIENT', label: 'Patient',  icon: '🧑',  desc: 'Book appointments' },
  { id: 'DOCTOR',  label: 'Doctor',   icon: '👨‍⚕️', desc: 'Manage patients' },
  { id: 'ADMIN',   label: 'Admin',    icon: '🛡️', desc: 'Platform admin' },
]

export default function RegisterPage() {
  const router = useRouter()
  const [role, setRole]             = useState<Role>('PATIENT')
  const [form, setForm]             = useState({ fullName: '', email: '', password: '', phone: '' })
  const [show, setShow]             = useState(false)
  const [loading, setLoading]       = useState(false)
  const [adminCode, setAdminCode]   = useState('')
  const [adminOpen, setAdminOpen]   = useState(false)
  const [adminOk, setAdminOk]       = useState(false)

  const up = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const selectRole = (r: Role) => {
    if (r === 'ADMIN' && !adminOk) { setAdminOpen(true); return }
    setRole(r)
  }

  const verifyAdmin = () => {
    if (adminCode === ADMIN_SECRET) {
      setAdminOk(true); setRole('ADMIN'); setAdminOpen(false)
      toast.success('Admin access granted ✅')
    } else {
      toast.error('Wrong secret code')
    }
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.fullName.trim()) { toast.error('Enter your full name'); return }
    if (!form.email.trim())    { toast.error('Enter email'); return }
    if (form.password.length < 6) { toast.error('Password min 6 characters'); return }
    if (role === 'ADMIN' && !adminOk) { toast.error('Verify admin code first'); return }

    setLoading(true)
    try {
      const payload: Record<string, string> = {
        email:     form.email.trim(),
        password:  form.password,
        fullName:  form.fullName.trim(),
        full_name: form.fullName.trim(),   // for FastAPI
        role:      role,
      }
      if (form.phone.trim()) payload.phone = form.phone.trim()

      const { data } = await authApi.register(payload as any)
      const { token, refreshToken, user } = normalizeAuth(data)
      if (!token) throw new Error('No token in response')
      saveAuth(token, refreshToken, user)
      toast.success(`Welcome, ${user.fullName?.split(' ')[0] || 'User'}! 🎉`)
      router.push(getDashboardPath(user.role))
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string; detail?: unknown } } }
      const detail = e?.response?.data?.detail
      let msg = e?.response?.data?.message || 'Registration failed'
      if (Array.isArray(detail)) {
        // FastAPI validation errors
        msg = detail.map((d: { msg: string }) => d.msg).join(', ')
      } else if (typeof detail === 'string') {
        msg = detail
      }
      toast.error(msg)
      console.error('Register error:', e?.response?.data)
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2.5">
            <div className="w-11 h-11 bg-primary-600 rounded-xl flex items-center justify-center">
              <Stethoscope size={22} className="text-white"/>
            </div>
            <span className="font-bold text-xl text-slate-800">Doctor<span className="text-primary-600">Finder</span></span>
          </Link>
          <h1 className="mt-6 text-2xl font-bold text-slate-800">Create your account</h1>
          <p className="text-slate-500 text-sm mt-1">Choose your account type below</p>
        </div>

        <div className="card p-7 fade-up">
          {/* Role selector */}
          <div className="grid grid-cols-3 gap-2 mb-5">
            {ROLES.map(r => (
              <button key={r.id} type="button" onClick={() => selectRole(r.id)}
                className={`flex flex-col items-center gap-1 py-3 px-2 rounded-xl border-2 text-center transition-all ${
                  role === r.id
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-slate-200 hover:border-primary-300 bg-white'
                }`}>
                <span className="text-xl">{r.icon}</span>
                <span className={`text-xs font-semibold ${role === r.id ? 'text-primary-700' : 'text-slate-600'}`}>
                  {r.label}
                </span>
                <span className="text-xs text-slate-400">{r.desc}</span>
                {r.id === 'ADMIN' && !adminOk && <Lock size={10} className="text-amber-500"/>}
              </button>
            ))}
          </div>

          {/* Admin code input */}
          {adminOpen && !adminOk && (
            <div className="mb-4 p-4 bg-amber-50 border border-amber-200 rounded-xl fade-up">
              <p className="text-sm font-semibold text-amber-800 mb-2 flex items-center gap-1.5">
                <Lock size={13}/> Admin Secret Required
              </p>
              <div className="flex gap-2">
                <input type="password" className="input flex-1" placeholder="Enter secret code"
                  value={adminCode} onChange={e => setAdminCode(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && verifyAdmin()}/>
                <button type="button" onClick={verifyAdmin} className="btn-primary px-4 py-2 text-sm">
                  Verify
                </button>
              </div>
              <button type="button" onClick={() => setAdminOpen(false)}
                className="text-xs text-slate-400 mt-2 hover:text-slate-600">
                Cancel
              </button>
            </div>
          )}

          {adminOk && role === 'ADMIN' && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl text-xs text-green-700 font-medium">
              ✅ Admin access verified — registering as Admin
            </div>
          )}

          {/* Form */}
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="label">Full Name</label>
              <input className="input"
                placeholder={role === 'DOCTOR' ? 'Dr. Rahul Sharma' : 'Rahul Sharma'}
                value={form.fullName} onChange={e => up('fullName', e.target.value)} required/>
            </div>
            <div>
              <label className="label">Email</label>
              <input type="email" className="input" placeholder="you@example.com"
                value={form.email} onChange={e => up('email', e.target.value)} required/>
            </div>
            <div>
              <label className="label">Phone <span className="font-normal normal-case text-slate-400">(optional)</span></label>
              <input className="input" placeholder="+91 98765 43210"
                value={form.phone} onChange={e => up('phone', e.target.value)}/>
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input type={show ? 'text' : 'password'} className="input pr-10"
                  placeholder="Min. 6 characters"
                  value={form.password} onChange={e => up('password', e.target.value)} required/>
                <button type="button" onClick={() => setShow(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {show ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
              {loading ? <span className="spin"/> : null}
              {loading ? 'Creating...' : `Create ${role} Account`}
            </button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-5">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-primary-600 font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
