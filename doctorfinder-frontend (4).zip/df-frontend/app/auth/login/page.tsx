'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Stethoscope, Eye, EyeOff } from 'lucide-react'
import { authApi, normalizeAuth } from '@/lib/api'
import { saveAuth, getDashboardPath } from '@/lib/auth'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow]         = useState(false)
  const [loading, setLoading]   = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim() || !password) { toast.error('Fill all fields'); return }
    setLoading(true)
    try {
      const { data } = await authApi.login(email, password)
      const { token, refreshToken, user } = normalizeAuth(data)
      if (!token) throw new Error('No token received')
      saveAuth(token, refreshToken, user)
      toast.success(`Welcome back, ${user.fullName?.split(' ')[0] || 'User'}!`)
      router.push(getDashboardPath(user.role))
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string; detail?: string } } }
      const msg = e?.response?.data?.message || e?.response?.data?.detail || 'Invalid email or password'
      toast.error(msg)
    } finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2.5">
            <div className="w-11 h-11 bg-primary-600 rounded-xl flex items-center justify-center">
              <Stethoscope size={22} className="text-white"/>
            </div>
            <span className="font-bold text-xl text-slate-800">Doctor<span className="text-primary-600">Finder</span></span>
          </Link>
          <h1 className="mt-6 text-2xl font-bold text-slate-800">Sign in to your account</h1>
          <p className="text-slate-500 text-sm mt-1">Enter your credentials below</p>
        </div>

        <div className="card p-7 fade-up">
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input type="email" className="input" placeholder="you@example.com"
                value={email} onChange={e => setEmail(e.target.value)} required/>
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input type={show ? 'text' : 'password'} className="input pr-10"
                  placeholder="••••••••" value={password}
                  onChange={e => setPassword(e.target.value)} required/>
                <button type="button" onClick={() => setShow(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {show ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full mt-2">
              {loading ? <span className="spin"/> : null}
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-5">
            No account?{' '}
            <Link href="/auth/register" className="text-primary-600 font-semibold hover:underline">Create one</Link>
          </p>
        </div>

        <div className="mt-3 card p-4 bg-amber-50 border-amber-100 text-xs text-amber-700">
          <p className="font-semibold mb-1">Test Credentials</p>
          <p>Register a new account or use SQL to create admin</p>
          <p className="mt-1">Admin secret code: <code className="bg-amber-100 px-1 rounded">DOCFINDER@ADMIN2025</code></p>
        </div>
      </div>
    </div>
  )
}
