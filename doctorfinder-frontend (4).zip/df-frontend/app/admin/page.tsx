'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import DoctorCard from '@/components/DoctorCard'
import { adminApi, doctorApi } from '@/lib/api'
import { getUser, isLoggedIn } from '@/lib/auth'
import { AdminStats, DoctorDetail, PagedResult } from '@/types'
import { Users, Stethoscope, Calendar, CheckCircle, XCircle, Clock, Search, BadgeCheck, Star, RefreshCw } from 'lucide-react'
import toast from 'react-hot-toast'

type Tab = 'overview' | 'doctors'

export default function AdminPage() {
  const router = useRouter()
  const [tab, setTab]         = useState<Tab>('overview')
  const [stats, setStats]     = useState<AdminStats | null>(null)
  const [doctors, setDoctors] = useState<DoctorDetail[]>([])
  const [loading, setLoading] = useState(true)
  const [dLoading, setDLoading] = useState(false)
  const [q, setQ]             = useState('')

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (!u || u.role !== 'ADMIN') { router.push('/'); return }
    loadStats()
  }, [])

  const loadStats = async () => {
    setLoading(true)
    try {
      const r = await adminApi.getStats()
      setStats(r.data)
    } catch { toast.error('Failed to load stats') }
    finally { setLoading(false) }
  }

  const loadDoctors = async () => {
    setDLoading(true)
    try {
      const params: Record<string, unknown> = { page: 0, size: 20 }
      if (q.trim()) params.q = q.trim()
      const r = await doctorApi.search(params)
      setDoctors((r.data as PagedResult<DoctorDetail>).content || [])
    } catch { toast.error('Failed to load doctors') }
    finally { setDLoading(false) }
  }

  useEffect(() => {
    if (tab === 'doctors') loadDoctors()
  }, [tab])

  const verify = async (id: string) => {
    try {
      await adminApi.verifyDoctor(id)
      toast.success('Doctor verified ✅')
      setDoctors(d => d.map(x => x.id === id ? { ...x, isVerified: true } : x))
    } catch { toast.error('Failed') }
  }

  const feature = async (id: string, f: boolean) => {
    try {
      await adminApi.featureDoctor(id, f)
      toast.success(f ? 'Marked as featured ⭐' : 'Removed from featured')
      setDoctors(d => d.map(x => x.id === id ? { ...x, isFeatured: f } : x))
    } catch { toast.error('Failed') }
  }

  const statCards = stats ? [
    { label: 'Total Users',       val: stats.totalUsers,          icon: <Users size={18}/>,       cls: 'text-blue-600 bg-blue-50' },
    { label: 'Doctors',           val: stats.totalDoctors,        icon: <Stethoscope size={18}/>, cls: 'text-primary-600 bg-primary-50' },
    { label: 'Verified Doctors',  val: stats.verifiedDoctors,     icon: <CheckCircle size={18}/>, cls: 'text-green-600 bg-green-50' },
    { label: 'Patients',          val: stats.totalPatients,       icon: <Users size={18}/>,       cls: 'text-violet-600 bg-violet-50' },
    { label: 'Total Appointments',val: stats.totalAppointments,   icon: <Calendar size={18}/>,    cls: 'text-amber-600 bg-amber-50' },
    { label: 'Pending',           val: stats.pendingAppointments, icon: <Clock size={18}/>,       cls: 'text-orange-600 bg-orange-50' },
    { label: 'Completed',         val: stats.completedAppointments,icon:<CheckCircle size={18}/>, cls: 'text-teal-600 bg-teal-50' },
    { label: 'Cancelled',         val: stats.cancelledAppointments,icon:<XCircle size={18}/>,     cls: 'text-red-500 bg-red-50' },
  ] : []

  return (
    <>
      <Navbar/>
      <main className="pt-20 pb-16 min-h-screen bg-slate-50">
        <div className="page">
          <div className="py-6 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-800">Admin Panel</h1>
              <p className="text-slate-500 text-sm mt-1">Platform management</p>
            </div>
            <button onClick={loadStats} className="btn-ghost flex items-center gap-2 text-sm">
              <RefreshCw size={13}/> Refresh
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-white rounded-xl p-1 border border-slate-100 w-fit mb-5 shadow-sm">
            {([
              { id: 'overview' as Tab, label: 'Overview' },
              { id: 'doctors'  as Tab, label: 'Manage Doctors' },
            ]).map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                  tab === t.id ? 'bg-primary-600 text-white' : 'text-slate-500 hover:text-slate-700'
                }`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* Overview */}
          {tab === 'overview' && (
            loading ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => <div key={i} className="card p-5 animate-pulse h-28"/>)}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  {statCards.map((s, i) => (
                    <div key={i} className="card p-5 fade-up">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs text-slate-400">{s.label}</span>
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${s.cls}`}>{s.icon}</div>
                      </div>
                      <p className="text-3xl font-bold text-slate-800">{s.val?.toLocaleString()}</p>
                    </div>
                  ))}
                </div>

                {stats && (
                  <div className="card p-6 fade-up">
                    <h3 className="font-semibold text-slate-800 mb-4 text-sm">Appointment Breakdown</h3>
                    <div className="space-y-3">
                      {[
                        { label: 'Pending',   val: stats.pendingAppointments,   color: 'bg-amber-400' },
                        { label: 'Completed', val: stats.completedAppointments, color: 'bg-primary-500' },
                        { label: 'Cancelled', val: stats.cancelledAppointments, color: 'bg-red-400' },
                      ].map(b => {
                        const pct = stats.totalAppointments > 0
                          ? Math.round((b.val / stats.totalAppointments) * 100) : 0
                        return (
                          <div key={b.label}>
                            <div className="flex justify-between text-sm mb-1">
                              <span className="text-slate-600">{b.label}</span>
                              <span className="font-semibold text-slate-700">{b.val} ({pct}%)</span>
                            </div>
                            <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                              <div className={`h-full ${b.color} rounded-full`} style={{ width: `${pct}%` }}/>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </>
            )
          )}

          {/* Doctors */}
          {tab === 'doctors' && (
            <>
              <div className="flex gap-3 mb-5 flex-wrap">
                <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 flex-1 max-w-sm">
                  <Search size={13} className="text-slate-400"/>
                  <input className="flex-1 text-sm outline-none text-slate-700 placeholder-slate-400"
                    placeholder="Search doctors..."
                    value={q} onChange={e => setQ(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && loadDoctors()}/>
                </div>
                <button onClick={loadDoctors} className="btn-primary text-sm py-2">Search</button>
              </div>

              {dLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[1,2,3,4].map(i => <div key={i} className="card p-5 animate-pulse h-36"/>)}
                </div>
              ) : doctors.length === 0 ? (
                <div className="card p-16 text-center">
                  <Stethoscope size={40} className="text-slate-200 mx-auto mb-3"/>
                  <p className="text-slate-400">No doctors found</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {doctors.map(d => (
                    <div key={d.id}>
                      <DoctorCard doctor={d}/>
                      <div className="flex gap-2 px-1 mt-1.5">
                        {!d.isVerified && (
                          <button onClick={() => verify(d.id)}
                            className="flex items-center gap-1.5 text-xs px-3 py-1.5 bg-green-50 text-green-700 border border-green-200 rounded-xl hover:bg-green-100 font-medium">
                            <BadgeCheck size={11}/> Verify
                          </button>
                        )}
                        <button onClick={() => feature(d.id, !d.isFeatured)}
                          className={`flex items-center gap-1.5 text-xs px-3 py-1.5 border rounded-xl font-medium ${
                            d.isFeatured ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-slate-50 text-slate-600 border-slate-200'
                          }`}>
                          <Star size={11}/> {d.isFeatured ? 'Unfeature' : 'Feature'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>
    </>
  )
}
