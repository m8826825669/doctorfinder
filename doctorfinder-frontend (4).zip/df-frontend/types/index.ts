export type Role = 'PATIENT' | 'DOCTOR' | 'ADMIN'

export interface User {
  id: string
  email: string
  fullName: string
  role: Role
  phone?: string
  createdAt?: string
}

export interface AuthData {
  token: string
  refreshToken: string
  user: User
}

export interface Specialization {
  id: number
  name: string
  description?: string
}

export interface DoctorDetail {
  id: string
  userId?: string
  email?: string
  fullName: string
  phone?: string
  specialization?: Specialization
  bio?: string
  experienceYears: number
  consultationFee: number
  qualification?: string
  clinicName?: string
  clinicAddress?: string
  city?: string
  state?: string
  languages?: string[]
  isVerified: boolean
  isFeatured: boolean
  rating: number
  totalReviews: number
  profilePicture?: string
}

export interface SlotInfo {
  id: string
  slotDate: string
  startTime: string
  endTime: string
  isBooked: boolean
}

export interface AvailabilityInfo {
  id: string
  dayOfWeek: number
  dayName: string
  startTime: string
  endTime: string
  slotDuration: number
}

export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'CANCELLED'

export interface AppointmentInfo {
  id: string
  patient: User
  doctor: DoctorDetail
  timeSlot: SlotInfo
  status: AppointmentStatus
  reason?: string
  notes?: string
  prescription?: string
  diagnosis?: string
  amount?: number
  createdAt: string
}

export interface ReviewInfo {
  id: string
  appointmentId: string
  patient: Partial<User>
  rating: number
  comment?: string
  createdAt: string
}

export interface NotificationInfo {
  id: string
  title: string
  message: string
  type: string
  isRead: boolean
  createdAt: string
}

export interface AdminStats {
  totalUsers: number
  totalDoctors: number
  verifiedDoctors: number
  totalPatients: number
  totalAppointments: number
  pendingAppointments: number
  completedAppointments: number
  cancelledAppointments: number
}

export interface PagedResult<T> {
  content: T[]
  page: number
  size: number
  totalElements: number
  totalPages: number
  last: boolean
}
