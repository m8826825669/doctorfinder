package com.doctorfinder.controller;

import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.service.AdminService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/admin")

public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/stats")
    public ResponseEntity<ApiResponse.AdminStats> getStats() {
        return ResponseEntity.ok(adminService.getStats());
    }

    @PostMapping("/doctors/{id}/verify")
    public ResponseEntity<ApiResponse.MessageResponse> verifyDoctor(@PathVariable UUID id) {
        return ResponseEntity.ok(adminService.verifyDoctor(id));
    }

    @PostMapping("/doctors/{id}/feature")
    public ResponseEntity<ApiResponse.MessageResponse> featureDoctor(
            @PathVariable UUID id,
            @RequestBody(required = false) Map<String, Boolean> body) {
        boolean featured = body == null || body.getOrDefault("featured", true);
        return ResponseEntity.ok(adminService.featureDoctor(id, featured));
    }
}
