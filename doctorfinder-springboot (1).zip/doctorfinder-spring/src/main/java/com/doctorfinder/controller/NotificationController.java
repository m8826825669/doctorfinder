package com.doctorfinder.controller;

import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.service.NotificationService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/notifications")

public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping
    public ResponseEntity<ApiResponse.PagedResult<ApiResponse.NotificationInfo>> getNotifications(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(
            notificationService.getNotifications(userDetails.getUsername(), page, size));
    }

    @PostMapping("/{id}/read")
    public ResponseEntity<ApiResponse.MessageResponse> markRead(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable UUID id) {
        return ResponseEntity.ok(
            notificationService.markRead(userDetails.getUsername(), id));
    }

    @PostMapping("/read-all")
    public ResponseEntity<ApiResponse.MessageResponse> markAllRead(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(
            notificationService.markAllRead(userDetails.getUsername()));
    }
}
