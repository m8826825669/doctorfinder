package com.doctorfinder.controller;

import com.doctorfinder.dto.request.AppointmentRequest;
import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.service.AppointmentService;
import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/appointments")

public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @PostMapping
    public ResponseEntity<ApiResponse.AppointmentInfo> book(
            @AuthenticationPrincipal UserDetails userDetails,
            @Valid @RequestBody AppointmentRequest.Book req) {
        return ResponseEntity.ok(
            appointmentService.book(userDetails.getUsername(), req));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse.PagedResult<ApiResponse.AppointmentInfo>> myAppointments(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(
            appointmentService.getMyAppointments(userDetails.getUsername(), page, size));
    }

    @GetMapping("/doctor")
    public ResponseEntity<ApiResponse.PagedResult<ApiResponse.AppointmentInfo>> doctorAppointments(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(
            appointmentService.getDoctorAppointments(userDetails.getUsername(), page, size));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse.AppointmentInfo> getById(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable UUID id) {
        return ResponseEntity.ok(
            appointmentService.getById(userDetails.getUsername(), id));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<ApiResponse.AppointmentInfo> updateNotes(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable UUID id,
            @RequestBody AppointmentRequest.UpdateNotes req) {
        return ResponseEntity.ok(
            appointmentService.updateNotes(userDetails.getUsername(), id, req));
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<ApiResponse.AppointmentInfo> confirm(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable UUID id) {
        return ResponseEntity.ok(
            appointmentService.confirm(userDetails.getUsername(), id));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse.AppointmentInfo> cancel(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable UUID id) {
        return ResponseEntity.ok(
            appointmentService.cancel(userDetails.getUsername(), id));
    }

    @PostMapping("/{id}/complete")
    public ResponseEntity<ApiResponse.AppointmentInfo> complete(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable UUID id) {
        return ResponseEntity.ok(
            appointmentService.complete(userDetails.getUsername(), id));
    }

    @PostMapping("/{id}/review")
    public ResponseEntity<ApiResponse.ReviewInfo> review(
            @AuthenticationPrincipal UserDetails userDetails,
            @PathVariable UUID id,
            @Valid @RequestBody AppointmentRequest.Review req) {
        return ResponseEntity.ok(
            appointmentService.submitReview(userDetails.getUsername(), id, req));
    }
}
