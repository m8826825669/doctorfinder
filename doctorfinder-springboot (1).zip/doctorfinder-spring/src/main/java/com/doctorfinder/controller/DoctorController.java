package com.doctorfinder.controller;

import com.doctorfinder.dto.request.DoctorRequest;
import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.entity.Review;
import com.doctorfinder.repository.ReviewRepository;
import com.doctorfinder.service.DoctorService;
import jakarta.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/doctors")

public class DoctorController {

    @Autowired
    private DoctorService doctorService;
    @Autowired
    private ReviewRepository reviewRepository;

    // GET /specializations
    @GetMapping("/specializations")
    public ResponseEntity<List<ApiResponse.SpecializationInfo>> getSpecializations() {
        return ResponseEntity.ok(doctorService.getAllSpecializations());
    }

    // POST /specializations (ADMIN)
    @PostMapping("/specializations")
    public ResponseEntity<ApiResponse.SpecializationInfo> createSpecialization(
            @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(
            doctorService.createSpecialization(body.get("name"), body.get("description")));
    }

    // GET /search
    @GetMapping("/search")
    public ResponseEntity<ApiResponse.PagedResult<ApiResponse.DoctorDetail>> search(
            DoctorRequest.Search req) {
        return ResponseEntity.ok(doctorService.search(req));
    }

    // POST /profile (DOCTOR)
    @PostMapping("/profile")
    public ResponseEntity<ApiResponse.DoctorDetail> createProfile(
            @AuthenticationPrincipal UserDetails userDetails,
            @Valid @RequestBody DoctorRequest.CreateProfile req) {
        return ResponseEntity.ok(
            doctorService.createProfile(userDetails.getUsername(), req));
    }

    // GET /{id}
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse.DoctorDetail> getById(@PathVariable UUID id) {
        return ResponseEntity.ok(doctorService.getById(id));
    }

    // PUT /profile (DOCTOR)
    @PutMapping("/profile")
    public ResponseEntity<ApiResponse.DoctorDetail> updateProfile(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestBody DoctorRequest.UpdateProfile req) {
        return ResponseEntity.ok(
            doctorService.updateProfile(userDetails.getUsername(), req));
    }

    // GET /{id}/reviews
    @GetMapping("/{id}/reviews")
    public ResponseEntity<ApiResponse.PagedResult<ApiResponse.ReviewInfo>> getReviews(
            @PathVariable UUID id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        // Explicit types used — avoids IntelliJ type inference issue with nested lambdas
        Page<Review> reviewPage = reviewRepository
            .findByDoctorIdOrderByCreatedAtDesc(id, PageRequest.of(page, size));

        List<ApiResponse.ReviewInfo> content = new ArrayList<>();
        for (Review r : reviewPage.getContent()) {
            content.add(mapReview(r));
        }

        ApiResponse.PagedResult<ApiResponse.ReviewInfo> result =
            ApiResponse.PagedResult.<ApiResponse.ReviewInfo>builder()
                .content(content)
                .page(reviewPage.getNumber())
                .size(reviewPage.getSize())
                .totalElements(reviewPage.getTotalElements())
                .totalPages(reviewPage.getTotalPages())
                .last(reviewPage.isLast())
                .build();

        return ResponseEntity.ok(result);
    }

    // Helper — extracted to avoid nested-lambda type inference errors in IntelliJ
    private ApiResponse.ReviewInfo mapReview(Review r) {
        ApiResponse.UserInfo patientInfo = ApiResponse.UserInfo.builder()
            .id(r.getPatient().getId())
            .fullName(r.getPatient().getFullName())
            .build();

        return ApiResponse.ReviewInfo.builder()
            .id(r.getId())
            .appointmentId(r.getAppointment().getId())
            .patient(patientInfo)
            .rating(r.getRating())
            .comment(r.getComment())
            .createdAt(r.getCreatedAt())
            .build();
    }

    // POST /{id}/availability (DOCTOR)
    @PostMapping("/{id}/availability")
    public ResponseEntity<ApiResponse.AvailabilityInfo> addAvailability(
            @PathVariable UUID id,
            @Valid @RequestBody DoctorRequest.AddAvailability req) {
        return ResponseEntity.ok(doctorService.addAvailability(id, req));
    }

    // GET /{id}/availability
    @GetMapping("/{id}/availability")
    public ResponseEntity<List<ApiResponse.AvailabilityInfo>> getAvailability(
            @PathVariable UUID id) {
        return ResponseEntity.ok(doctorService.getAvailability(id));
    }

    // DELETE /{id}/availability/{aid} (DOCTOR)
    @DeleteMapping("/{id}/availability/{aid}")
    public ResponseEntity<ApiResponse.MessageResponse> deleteAvailability(
            @PathVariable UUID id, @PathVariable UUID aid) {
        return ResponseEntity.ok(doctorService.deleteAvailability(id, aid));
    }

    // POST /{id}/slots/generate (DOCTOR)
    @PostMapping("/{id}/slots/generate")
    public ResponseEntity<ApiResponse.MessageResponse> generateSlots(
            @PathVariable UUID id,
            @Valid @RequestBody DoctorRequest.GenerateSlots req) {
        return ResponseEntity.ok(doctorService.generateSlots(id, req));
    }

    // GET /{id}/slots?date=2025-06-01
    @GetMapping("/{id}/slots")
    public ResponseEntity<List<ApiResponse.SlotInfo>> getSlots(
            @PathVariable UUID id,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(doctorService.getSlots(id, date));
    }

    // GET /{id}/slots/range?from=2025-06-01&to=2025-06-07
    @GetMapping("/{id}/slots/range")
    public ResponseEntity<List<ApiResponse.SlotInfo>> getSlotsRange(
            @PathVariable UUID id,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return ResponseEntity.ok(doctorService.getSlotsRange(id, from, to));
    }
}
