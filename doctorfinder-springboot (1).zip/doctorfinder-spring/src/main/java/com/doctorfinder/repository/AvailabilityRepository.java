package com.doctorfinder.repository;

import com.doctorfinder.entity.Availability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface AvailabilityRepository extends JpaRepository<Availability, UUID> {
    List<Availability> findByDoctorId(UUID doctorId);
    void deleteByDoctorIdAndId(UUID doctorId, UUID availabilityId);
}
