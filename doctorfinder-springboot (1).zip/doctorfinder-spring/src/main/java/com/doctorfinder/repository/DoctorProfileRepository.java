package com.doctorfinder.repository;

import com.doctorfinder.entity.DoctorProfile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface DoctorProfileRepository extends JpaRepository<DoctorProfile, UUID>,
        JpaSpecificationExecutor<DoctorProfile> {

    Optional<DoctorProfile> findByUserId(UUID userId);

    boolean existsByUserId(UUID userId);

    Page<DoctorProfile> findByIsVerifiedTrue(Pageable pageable);

    @Query("SELECT d FROM DoctorProfile d WHERE d.isVerified = true AND d.city = :city")
    Page<DoctorProfile> findVerifiedByCity(@Param("city") String city, Pageable pageable);

    @Query("SELECT COUNT(d) FROM DoctorProfile d WHERE d.isVerified = true")
    long countVerified();

    @Query("SELECT COUNT(d) FROM DoctorProfile d WHERE d.isFeatured = true")
    long countFeatured();
}
