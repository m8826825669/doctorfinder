package com.doctorfinder.repository;

import com.doctorfinder.entity.TimeSlot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface TimeSlotRepository extends JpaRepository<TimeSlot, UUID> {

    List<TimeSlot> findByDoctorIdAndSlotDateAndIsBookedFalseOrderByStartTime(
            UUID doctorId, LocalDate slotDate);

    List<TimeSlot> findByDoctorIdAndSlotDateBetweenAndIsBookedFalseOrderBySlotDateAscStartTimeAsc(
            UUID doctorId, LocalDate from, LocalDate to);

    boolean existsByDoctorIdAndSlotDateAndStartTime(
            UUID doctorId, LocalDate slotDate, java.time.LocalTime startTime);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT t FROM TimeSlot t WHERE t.id = :id")
    Optional<TimeSlot> findByIdForUpdate(@Param("id") UUID id);

    @Query("SELECT COUNT(t) FROM TimeSlot t WHERE t.doctor.id = :doctorId AND t.isBooked = true")
    long countBookedByDoctor(@Param("doctorId") UUID doctorId);
}
