package com.doctorfinder.config;

// ✅ Spring Data Elasticsearch native approach — no low-level RestClient needed
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchConfiguration;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;

@Configuration
public class ElasticsearchConfig extends ElasticsearchConfiguration {

    @Value("${spring.elasticsearch.host:localhost}")
    private String esHost;

    @Value("${spring.elasticsearch.port:9200}")
    private int esPort;

    @Value("${spring.elasticsearch.username:elastic}")
    private String esUsername;

    @Value("${spring.elasticsearch.password}")
    private String esPassword;

    @Override
    public ClientConfiguration clientConfiguration() {
        try {
            SSLContext sslContext = createTrustAllSslContext();

            return ClientConfiguration.builder()
                .connectedTo(esHost + ":" + esPort)
                .usingSsl(sslContext, (hostname, session) -> true)  // trust self-signed cert
                .withBasicAuth(esUsername, esPassword)
                .build();

        } catch (Exception e) {
            throw new RuntimeException("Failed to configure Elasticsearch client", e);
        }
    }

    private SSLContext createTrustAllSslContext() throws Exception {
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, new TrustManager[]{
            new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
            }
        }, new java.security.SecureRandom());
        return sslContext;
    }
}
