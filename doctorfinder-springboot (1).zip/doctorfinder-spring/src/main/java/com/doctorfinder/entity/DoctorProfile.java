package com.doctorfinder.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "doctor_profiles")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class DoctorProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", unique = true, nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "specialization_id")
    private Specialization specialization;

    @Column(columnDefinition = "TEXT")
    private String bio;

    @Builder.Default
    private Integer experienceYears = 0;

    @Builder.Default
    private BigDecimal consultationFee = BigDecimal.ZERO;

    private String qualification;
    private String clinicName;
    private String clinicAddress;
    private String city;
    private String state;

    private Double latitude;
    private Double longitude;

    @Column(columnDefinition = "text[]")
    private List<String> languages;

    @Builder.Default
    private Boolean isVerified = false;

    @Builder.Default
    private Boolean isFeatured = false;

    @Builder.Default
    private BigDecimal rating = BigDecimal.ZERO;

    @Builder.Default
    private Integer totalReviews = 0;

    private String profilePicture;

    @CreationTimestamp
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    private OffsetDateTime updatedAt;
}
