package com.doctorfinder.service;

import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.entity.Appointment;
import com.doctorfinder.entity.User;
import com.doctorfinder.repository.AppointmentRepository;
import com.doctorfinder.repository.DoctorProfileRepository;
import com.doctorfinder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class AdminService {

    @Autowired private UserRepository userRepository;
    @Autowired private DoctorProfileRepository doctorRepo;
    @Autowired private AppointmentRepository appointmentRepo;

    public ApiResponse.AdminStats getStats() {
        return ApiResponse.AdminStats.builder()
            .totalUsers(userRepository.count())
            .totalDoctors(userRepository.countByRole(User.Role.DOCTOR))
            .verifiedDoctors(doctorRepo.countVerified())
            .totalPatients(userRepository.countByRole(User.Role.PATIENT))
            .totalAppointments(appointmentRepo.countTotal())
            .pendingAppointments(appointmentRepo.countByStatus(Appointment.Status.PENDING))
            .completedAppointments(appointmentRepo.countByStatus(Appointment.Status.COMPLETED))
            .cancelledAppointments(appointmentRepo.countByStatus(Appointment.Status.CANCELLED))
            .build();
    }

    @Transactional
    public ApiResponse.MessageResponse verifyDoctor(UUID doctorId) {
        var doctor = doctorRepo.findById(doctorId)
            .orElseThrow(() -> new RuntimeException("Doctor not found"));
        doctor.setIsVerified(true);
        doctorRepo.save(doctor);
        return ApiResponse.MessageResponse.builder()
            .message("Doctor verified successfully").success(true).build();
    }

    @Transactional
    public ApiResponse.MessageResponse featureDoctor(UUID doctorId, boolean featured) {
        var doctor = doctorRepo.findById(doctorId)
            .orElseThrow(() -> new RuntimeException("Doctor not found"));
        doctor.setIsFeatured(featured);
        doctorRepo.save(doctor);
        return ApiResponse.MessageResponse.builder()
            .message("Doctor " + (featured ? "featured" : "unfeatured") + " successfully")
            .success(true).build();
    }
}
