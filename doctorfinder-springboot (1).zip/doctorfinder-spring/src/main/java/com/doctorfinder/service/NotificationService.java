package com.doctorfinder.service;

import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.entity.Notification;
import com.doctorfinder.entity.User;
import com.doctorfinder.repository.NotificationRepository;
import com.doctorfinder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class NotificationService {

    @Autowired private NotificationRepository notificationRepo;
    @Autowired private UserRepository userRepository;

    public ApiResponse.PagedResult<ApiResponse.NotificationInfo> getNotifications(
            String email, int page, int size) {

        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        Page<Notification> notifPage = notificationRepo
            .findByUserIdOrderByCreatedAtDesc(user.getId(), PageRequest.of(page, size));

        return ApiResponse.PagedResult.<ApiResponse.NotificationInfo>builder()
            .content(notifPage.getContent().stream().map(this::toInfo).toList())
            .page(notifPage.getNumber())
            .size(notifPage.getSize())
            .totalElements(notifPage.getTotalElements())
            .totalPages(notifPage.getTotalPages())
            .last(notifPage.isLast())
            .build();
    }

    @Transactional
    public ApiResponse.MessageResponse markRead(String email, UUID notifId) {
        Notification notif = notificationRepo.findById(notifId)
            .orElseThrow(() -> new RuntimeException("Notification not found"));
        notif.setIsRead(true);
        notificationRepo.save(notif);
        return ApiResponse.MessageResponse.builder()
            .message("Marked as read").success(true).build();
    }

    @Transactional
    public ApiResponse.MessageResponse markAllRead(String email) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));
        int updated = notificationRepo.markAllReadByUserId(user.getId());
        return ApiResponse.MessageResponse.builder()
            .message(updated + " notifications marked as read").success(true).build();
    }

    private ApiResponse.NotificationInfo toInfo(Notification n) {
        return ApiResponse.NotificationInfo.builder()
            .id(n.getId())
            .title(n.getTitle())
            .message(n.getMessage())
            .type(n.getType())
            .isRead(n.getIsRead())
            .createdAt(n.getCreatedAt())
            .build();
    }
}
