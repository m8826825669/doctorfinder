package com.doctorfinder.service;

import com.doctorfinder.dto.request.DoctorRequest;
import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.entity.*;
import com.doctorfinder.repository.*;


import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Service
@SuppressWarnings("unused")
public class DoctorService {

    private static final String[] DAY_NAMES = {
        "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"
    };

    @Autowired
    private DoctorProfileRepository doctorRepo;
    @Autowired
    private SpecializationRepository specializationRepo;
    @Autowired
    private AvailabilityRepository availabilityRepo;
    @Autowired
    private TimeSlotRepository timeSlotRepo;
    @Autowired
    private UserRepository userRepository;

    // ─── Specializations ────────────────────────────────────────────────────

    @Cacheable("specializations")
    public List<ApiResponse.SpecializationInfo> getAllSpecializations() {
        return specializationRepo.findAll().stream()
            .map(s -> ApiResponse.SpecializationInfo.builder()
                .id(s.getId()).name(s.getName()).description(s.getDescription())
                .build())
            .toList();
    }

    @CacheEvict(value = "specializations", allEntries = true)
    @Transactional
    public ApiResponse.SpecializationInfo createSpecialization(String name, String description) {
        if (specializationRepo.existsByNameIgnoreCase(name)) {
            throw new RuntimeException("Specialization already exists: " + name);
        }
        Specialization s = specializationRepo.save(
            Specialization.builder().name(name).description(description).build());
        return ApiResponse.SpecializationInfo.builder()
            .id(s.getId()).name(s.getName()).description(s.getDescription()).build();
    }

    // ─── Search ─────────────────────────────────────────────────────────────

    public ApiResponse.PagedResult<ApiResponse.DoctorDetail> search(DoctorRequest.Search req) {
        // Build specification for filtering
        Pageable pageable = PageRequest.of(
            req.getPage(), req.getSize(),
            Sort.by(
                "asc".equalsIgnoreCase(req.getSortDir())
                    ? Sort.Direction.ASC : Sort.Direction.DESC,
                resolveSort(req.getSortBy())
            )
        );

        Page<DoctorProfile> page = doctorRepo.findAll(
            DoctorSpecification.build(req), pageable);

        return toPagedResult(page);
    }

    private String resolveSort(String sortBy) {
        return switch (sortBy == null ? "rating" : sortBy) {
            case "fee"        -> "consultationFee";
            case "experience" -> "experienceYears";
            default           -> "rating";
        };
    }

    // ─── Profile ─────────────────────────────────────────────────────────────

    @Transactional
    public ApiResponse.DoctorDetail createProfile(String email, DoctorRequest.CreateProfile req) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        if (doctorRepo.existsByUserId(user.getId())) {
            throw new RuntimeException("Doctor profile already exists");
        }

        Specialization spec = null;
        if (req.getSpecializationId() != null) {
            spec = specializationRepo.findById(req.getSpecializationId())
                .orElseThrow(() -> new RuntimeException("Specialization not found"));
        }

        DoctorProfile profile = DoctorProfile.builder()
            .user(user)
            .specialization(spec)
            .bio(req.getBio())
            .experienceYears(req.getExperienceYears() != null ? req.getExperienceYears() : 0)
            .consultationFee(req.getConsultationFee() != null ? req.getConsultationFee() : BigDecimal.ZERO)
            .qualification(req.getQualification())
            .clinicName(req.getClinicName())
            .clinicAddress(req.getClinicAddress())
            .city(req.getCity())
            .state(req.getState())
            .latitude(req.getLatitude())
            .longitude(req.getLongitude())
            .languages(req.getLanguages())
            .profilePicture(req.getProfilePicture())
            .build();

        return toDetail(doctorRepo.save(profile));
    }

    @Cacheable(value = "doctorDetail", key = "#id")
    public ApiResponse.DoctorDetail getById(UUID id) {
        DoctorProfile profile = doctorRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Doctor not found: " + id));
        return toDetail(profile);
    }

    @CacheEvict(value = "doctorDetail", key = "#result.id")
    @Transactional
    public ApiResponse.DoctorDetail updateProfile(String email, DoctorRequest.UpdateProfile req) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        DoctorProfile profile = doctorRepo.findByUserId(user.getId())
            .orElseThrow(() -> new RuntimeException("Doctor profile not found"));

        if (req.getSpecializationId() != null) {
            profile.setSpecialization(specializationRepo.findById(req.getSpecializationId())
                .orElseThrow(() -> new RuntimeException("Specialization not found")));
        }
        if (req.getBio() != null)             profile.setBio(req.getBio());
        if (req.getExperienceYears() != null) profile.setExperienceYears(req.getExperienceYears());
        if (req.getConsultationFee() != null) profile.setConsultationFee(req.getConsultationFee());
        if (req.getQualification() != null)   profile.setQualification(req.getQualification());
        if (req.getClinicName() != null)      profile.setClinicName(req.getClinicName());
        if (req.getClinicAddress() != null)   profile.setClinicAddress(req.getClinicAddress());
        if (req.getCity() != null)            profile.setCity(req.getCity());
        if (req.getState() != null)           profile.setState(req.getState());
        if (req.getLatitude() != null)        profile.setLatitude(req.getLatitude());
        if (req.getLongitude() != null)       profile.setLongitude(req.getLongitude());
        if (req.getLanguages() != null)       profile.setLanguages(req.getLanguages());
        if (req.getProfilePicture() != null)  profile.setProfilePicture(req.getProfilePicture());

        return toDetail(doctorRepo.save(profile));
    }

    // ─── Availability ─────────────────────────────────────────────────────────

    @Transactional
    public ApiResponse.AvailabilityInfo addAvailability(UUID doctorId, DoctorRequest.AddAvailability req) {
        DoctorProfile doctor = doctorRepo.findById(doctorId)
            .orElseThrow(() -> new RuntimeException("Doctor not found"));

        Availability av = Availability.builder()
            .doctor(doctor)
            .dayOfWeek(req.getDayOfWeek())
            .startTime(req.getStartTime())
            .endTime(req.getEndTime())
            .slotDuration(req.getSlotDuration())
            .build();

        return toAvailabilityInfo(availabilityRepo.save(av));
    }

    public List<ApiResponse.AvailabilityInfo> getAvailability(UUID doctorId) {
        return availabilityRepo.findByDoctorId(doctorId)
            .stream().map(this::toAvailabilityInfo).toList();
    }

    @Transactional
    public ApiResponse.MessageResponse deleteAvailability(UUID doctorId, UUID availabilityId) {
        availabilityRepo.deleteByDoctorIdAndId(doctorId, availabilityId);
        return ApiResponse.MessageResponse.builder()
            .message("Availability removed").success(true).build();
    }

    // ─── Slots ────────────────────────────────────────────────────────────────

    @Transactional
    public ApiResponse.MessageResponse generateSlots(UUID doctorId, DoctorRequest.GenerateSlots req) {
        DoctorProfile doctor = doctorRepo.findById(doctorId)
            .orElseThrow(() -> new RuntimeException("Doctor not found"));

        List<Availability> schedules = availabilityRepo.findByDoctorId(doctorId);
        if (schedules.isEmpty()) {
            throw new RuntimeException("No availability set for this doctor");
        }

        List<TimeSlot> slotsToSave = new ArrayList<>();
        LocalDate current = req.getFromDate();

        while (!current.isAfter(req.getToDate())) {
            final LocalDate date = current;
            // dayOfWeek: Monday=0, Sunday=6 (our convention)
            int dayIdx = date.getDayOfWeek().getValue() - 1; // Java: MON=1, so -1

            schedules.stream()
                .filter(av -> av.getDayOfWeek() == dayIdx)
                .forEach(av -> {
                    LocalTime slot = av.getStartTime();
                    while (slot.plusMinutes(av.getSlotDuration()).compareTo(av.getEndTime()) <= 0) {
                        LocalTime slotStart = slot;
                        LocalTime slotEnd   = slot.plusMinutes(av.getSlotDuration());

                        if (!timeSlotRepo.existsByDoctorIdAndSlotDateAndStartTime(
                                doctorId, date, slotStart)) {
                            slotsToSave.add(TimeSlot.builder()
                                .doctor(doctor)
                                .slotDate(date)
                                .startTime(slotStart)
                                .endTime(slotEnd)
                                .build());
                        }
                        slot = slotEnd;
                    }
                });

            current = current.plusDays(1);
        }

        timeSlotRepo.saveAll(slotsToSave);

        return ApiResponse.MessageResponse.builder()
            .message(slotsToSave.size() + " slots generated")
            .success(true).build();
    }

    @Cacheable(value = "doctorSlots", key = "#doctorId + '_' + #date")
    public List<ApiResponse.SlotInfo> getSlots(UUID doctorId, LocalDate date) {
        return timeSlotRepo
            .findByDoctorIdAndSlotDateAndIsBookedFalseOrderByStartTime(doctorId, date)
            .stream().map(this::toSlotInfo).toList();
    }

    public List<ApiResponse.SlotInfo> getSlotsRange(UUID doctorId, LocalDate from, LocalDate to) {
        if (from.plusDays(30).isBefore(to)) {
            throw new RuntimeException("Date range cannot exceed 30 days");
        }
        return timeSlotRepo
            .findByDoctorIdAndSlotDateBetweenAndIsBookedFalseOrderBySlotDateAscStartTimeAsc(
                doctorId, from, to)
            .stream().map(this::toSlotInfo).toList();
    }

    // ─── Converters ──────────────────────────────────────────────────────────

    public ApiResponse.DoctorDetail toDetail(DoctorProfile p) {
        ApiResponse.SpecializationInfo specInfo = null;
        if (p.getSpecialization() != null) {
            specInfo = ApiResponse.SpecializationInfo.builder()
                .id(p.getSpecialization().getId())
                .name(p.getSpecialization().getName())
                .description(p.getSpecialization().getDescription())
                .build();
        }

        return ApiResponse.DoctorDetail.builder()
            .id(p.getId())
            .userId(p.getUser().getId())
            .email(p.getUser().getEmail())
            .fullName(p.getUser().getFullName())
            .phone(p.getUser().getPhone())
            .specialization(specInfo)
            .bio(p.getBio())
            .experienceYears(p.getExperienceYears())
            .consultationFee(p.getConsultationFee())
            .qualification(p.getQualification())
            .clinicName(p.getClinicName())
            .clinicAddress(p.getClinicAddress())
            .city(p.getCity())
            .state(p.getState())
            .latitude(p.getLatitude())
            .longitude(p.getLongitude())
            .languages(p.getLanguages())
            .isVerified(p.getIsVerified())
            .isFeatured(p.getIsFeatured())
            .rating(p.getRating())
            .totalReviews(p.getTotalReviews())
            .profilePicture(p.getProfilePicture())
            .createdAt(p.getCreatedAt())
            .build();
    }

    private ApiResponse.AvailabilityInfo toAvailabilityInfo(Availability av) {
        return ApiResponse.AvailabilityInfo.builder()
            .id(av.getId())
            .dayOfWeek(av.getDayOfWeek())
            .dayName(DAY_NAMES[av.getDayOfWeek()])
            .startTime(av.getStartTime())
            .endTime(av.getEndTime())
            .slotDuration(av.getSlotDuration())
            .build();
    }

    public ApiResponse.SlotInfo toSlotInfo(TimeSlot t) {
        return ApiResponse.SlotInfo.builder()
            .id(t.getId())
            .slotDate(t.getSlotDate())
            .startTime(t.getStartTime())
            .endTime(t.getEndTime())
            .isBooked(t.getIsBooked())
            .build();
    }

    private ApiResponse.PagedResult<ApiResponse.DoctorDetail> toPagedResult(Page<DoctorProfile> page) {
        return ApiResponse.PagedResult.<ApiResponse.DoctorDetail>builder()
            .content(page.getContent().stream().map(this::toDetail).toList())
            .page(page.getNumber())
            .size(page.getSize())
            .totalElements(page.getTotalElements())
            .totalPages(page.getTotalPages())
            .last(page.isLast())
            .build();
    }
}
