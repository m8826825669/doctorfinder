package com.doctorfinder.service;

import com.doctorfinder.dto.request.AuthRequest;
import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.entity.User;
import com.doctorfinder.repository.UserRepository;
import com.doctorfinder.security.JwtUtil;
import com.doctorfinder.security.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    @Autowired private UserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private UserDetailsServiceImpl userDetailsService;

    @Transactional
    public ApiResponse.Auth register(AuthRequest.Register req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new RuntimeException("Email already registered: " + req.getEmail());
        }

        User user = new User();
        user.setEmail(req.getEmail());
        user.setFullName(req.getFullName());
        user.setPassword(passwordEncoder.encode(req.getPassword()));
        user.setRole(req.getRole());
        user.setPhone(req.getPhone());
        user.setIsActive(true);
        userRepository.save(user);

        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        String accessToken  = jwtUtil.generateToken(userDetails);
        String refreshToken = jwtUtil.generateRefreshToken(userDetails);

        return ApiResponse.Auth.builder()
            .accessToken(accessToken)
            .refreshToken(refreshToken)
            .expiresIn(jwtUtil.getExpiration())
            .user(toUserInfo(user))
            .build();
    }

    public ApiResponse.Auth login(AuthRequest.Login req) {
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));

        User user = userRepository.findByEmail(req.getEmail())
            .orElseThrow(() -> new RuntimeException("User not found"));

        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        String accessToken  = jwtUtil.generateToken(userDetails);
        String refreshToken = jwtUtil.generateRefreshToken(userDetails);

        return ApiResponse.Auth.builder()
            .accessToken(accessToken)
            .refreshToken(refreshToken)
            .expiresIn(jwtUtil.getExpiration())
            .user(toUserInfo(user))
            .build();
    }

    public ApiResponse.Auth refresh(AuthRequest.Refresh req) {
        String email = jwtUtil.extractUsername(req.getRefreshToken());
        UserDetails userDetails = userDetailsService.loadUserByUsername(email);

        if (!jwtUtil.isTokenValid(req.getRefreshToken(), userDetails)) {
            throw new RuntimeException("Invalid or expired refresh token");
        }

        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        return ApiResponse.Auth.builder()
            .accessToken(jwtUtil.generateToken(userDetails))
            .refreshToken(jwtUtil.generateRefreshToken(userDetails))
            .expiresIn(jwtUtil.getExpiration())
            .user(toUserInfo(user))
            .build();
    }

    public ApiResponse.UserInfo getMe(String email) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));
        return toUserInfo(user);
    }

    @Transactional
    public ApiResponse.MessageResponse changePassword(String email, AuthRequest.ChangePassword req) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(req.getOldPassword(), user.getPassword())) {
            throw new RuntimeException("Old password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(req.getNewPassword()));
        userRepository.save(user);

        return ApiResponse.MessageResponse.builder()
            .message("Password changed successfully").success(true).build();
    }

    public static ApiResponse.UserInfo toUserInfo(User user) {
        return ApiResponse.UserInfo.builder()
            .id(user.getId())
            .email(user.getEmail())
            .fullName(user.getFullName())
            .role(user.getRole())
            .phone(user.getPhone())
            .createdAt(user.getCreatedAt())
            .build();
    }
}
