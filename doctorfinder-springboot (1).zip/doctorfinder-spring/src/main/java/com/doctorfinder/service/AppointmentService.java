package com.doctorfinder.service;

import com.doctorfinder.dto.request.AppointmentRequest;
import com.doctorfinder.dto.response.ApiResponse;
import com.doctorfinder.entity.*;
import com.doctorfinder.repository.*;

import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

@Service

public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepo;
    @Autowired
    private TimeSlotRepository timeSlotRepo;
    @Autowired
    private DoctorProfileRepository doctorRepo;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ReviewRepository reviewRepo;
    @Autowired
    private NotificationRepository notificationRepo;
    @Autowired
    private DoctorService doctorService;

    @Transactional
    public ApiResponse.AppointmentInfo book(String email, AppointmentRequest.Book req) {
        User patient = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        // Pessimistic lock on the time slot to prevent double-booking
        TimeSlot slot = timeSlotRepo.findByIdForUpdate(req.getTimeSlotId())
            .orElseThrow(() -> new RuntimeException("Time slot not found"));

        if (slot.getIsBooked()) {
            throw new RuntimeException("Time slot is already booked");
        }

        DoctorProfile doctor = slot.getDoctor();

        slot.setIsBooked(true);
        timeSlotRepo.save(slot);

        Appointment appointment = Appointment.builder()
            .patient(patient)
            .doctor(doctor)
            .timeSlot(slot)
            .reason(req.getReason())
            .amount(doctor.getConsultationFee())
            .build();

        appointment = appointmentRepo.save(appointment);

        // Notify doctor
        createNotification(doctor.getUser(),
            "New Appointment Booked",
            patient.getFullName() + " has booked an appointment on "
                + slot.getSlotDate() + " at " + slot.getStartTime(),
            "APPOINTMENT_BOOKED");

        return toAppointmentInfo(appointment);
    }

    public ApiResponse.PagedResult<ApiResponse.AppointmentInfo> getMyAppointments(
            String email, int page, int size) {
        User patient = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        Page<Appointment> apptPage = appointmentRepo.findByPatientIdOrderByCreatedAtDesc(
            patient.getId(), PageRequest.of(page, size));

        return toPagedResult(apptPage);
    }

    public ApiResponse.PagedResult<ApiResponse.AppointmentInfo> getDoctorAppointments(
            String email, int page, int size) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        DoctorProfile doctor = doctorRepo.findByUserId(user.getId())
            .orElseThrow(() -> new RuntimeException("Doctor profile not found"));

        Page<Appointment> apptPage = appointmentRepo.findByDoctorIdOrderByCreatedAtDesc(
            doctor.getId(), PageRequest.of(page, size));

        return toPagedResult(apptPage);
    }

    public ApiResponse.AppointmentInfo getById(String email, UUID appointmentId) {
        Appointment appt = appointmentRepo.findById(appointmentId)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));
        return toAppointmentInfo(appt);
    }

    @Transactional
    public ApiResponse.AppointmentInfo updateNotes(String email, UUID id,
            AppointmentRequest.UpdateNotes req) {
        Appointment appt = appointmentRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));

        if (req.getNotes() != null)        appt.setNotes(req.getNotes());
        if (req.getPrescription() != null) appt.setPrescription(req.getPrescription());
        if (req.getDiagnosis() != null)    appt.setDiagnosis(req.getDiagnosis());

        return toAppointmentInfo(appointmentRepo.save(appt));
    }

    @Transactional
    public ApiResponse.AppointmentInfo confirm(String email, UUID id) {
        Appointment appt = getAndValidate(id, Appointment.Status.PENDING);
        appt.setStatus(Appointment.Status.CONFIRMED);
        appt = appointmentRepo.save(appt);

        createNotification(appt.getPatient(),
            "Appointment Confirmed",
            "Your appointment on " + appt.getTimeSlot().getSlotDate() + " has been confirmed.",
            "APPOINTMENT_CONFIRMED");

        return toAppointmentInfo(appt);
    }

    @Transactional
    public ApiResponse.AppointmentInfo cancel(String email, UUID id) {
        Appointment appt = appointmentRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));

        if (appt.getStatus() == Appointment.Status.COMPLETED) {
            throw new RuntimeException("Cannot cancel a completed appointment");
        }

        appt.setStatus(Appointment.Status.CANCELLED);

        // Free the time slot
        TimeSlot slot = appt.getTimeSlot();
        slot.setIsBooked(false);
        timeSlotRepo.save(slot);

        appt = appointmentRepo.save(appt);

        createNotification(appt.getPatient(),
            "Appointment Cancelled",
            "Your appointment on " + appt.getTimeSlot().getSlotDate() + " has been cancelled.",
            "APPOINTMENT_CANCELLED");

        return toAppointmentInfo(appt);
    }

    @Transactional
    public ApiResponse.AppointmentInfo complete(String email, UUID id) {
        Appointment appt = getAndValidate(id, Appointment.Status.CONFIRMED);
        appt.setStatus(Appointment.Status.COMPLETED);
        appt = appointmentRepo.save(appt);

        createNotification(appt.getPatient(),
            "Appointment Completed",
            "Your appointment has been marked complete. Please leave a review!",
            "APPOINTMENT_COMPLETED");

        return toAppointmentInfo(appt);
    }

    @Transactional
    public ApiResponse.ReviewInfo submitReview(String email, UUID appointmentId,
            AppointmentRequest.Review req) {
        User patient = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found"));

        Appointment appt = appointmentRepo.findById(appointmentId)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));

        if (appt.getStatus() != Appointment.Status.COMPLETED) {
            throw new RuntimeException("Can only review completed appointments");
        }
        if (!appt.getPatient().getId().equals(patient.getId())) {
            throw new RuntimeException("Not your appointment");
        }
        if (reviewRepo.existsByAppointmentId(appointmentId)) {
            throw new RuntimeException("Review already submitted");
        }

        Review review = Review.builder()
            .appointment(appt)
            .patient(patient)
            .doctor(appt.getDoctor())
            .rating(req.getRating())
            .comment(req.getComment())
            .build();

        review = reviewRepo.save(review);

        // Update doctor's average rating
        updateDoctorRating(appt.getDoctor());

        return ApiResponse.ReviewInfo.builder()
            .id(review.getId())
            .appointmentId(appointmentId)
            .patient(AuthService.toUserInfo(patient))
            .rating(review.getRating())
            .comment(review.getComment())
            .createdAt(review.getCreatedAt())
            .build();
    }

    private Appointment getAndValidate(UUID id, Appointment.Status requiredStatus) {
        Appointment appt = appointmentRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));
        if (appt.getStatus() != requiredStatus) {
            throw new RuntimeException(
                "Appointment must be " + requiredStatus + " but is " + appt.getStatus());
        }
        return appt;
    }

    private void updateDoctorRating(DoctorProfile doctor) {
        Double avg = reviewRepo.findAverageRatingByDoctorId(doctor.getId());
        long count = reviewRepo.countByDoctorId(doctor.getId());

        if (avg != null) {
            doctor.setRating(BigDecimal.valueOf(avg)
                .setScale(2, RoundingMode.HALF_UP));
        }
        doctor.setTotalReviews((int) count);
        doctorRepo.save(doctor);
    }

    private void createNotification(User user, String title, String message, String type) {
        notificationRepo.save(Notification.builder()
            .user(user)
            .title(title)
            .message(message)
            .type(type)
            .build());
    }

    private ApiResponse.AppointmentInfo toAppointmentInfo(Appointment a) {
        return ApiResponse.AppointmentInfo.builder()
            .id(a.getId())
            .patient(AuthService.toUserInfo(a.getPatient()))
            .doctor(doctorService.toDetail(a.getDoctor()))
            .timeSlot(doctorService.toSlotInfo(a.getTimeSlot()))
            .status(a.getStatus())
            .reason(a.getReason())
            .notes(a.getNotes())
            .prescription(a.getPrescription())
            .diagnosis(a.getDiagnosis())
            .amount(a.getAmount())
            .createdAt(a.getCreatedAt())
            .updatedAt(a.getUpdatedAt())
            .build();
    }

    private ApiResponse.PagedResult<ApiResponse.AppointmentInfo> toPagedResult(
            Page<Appointment> page) {
        return ApiResponse.PagedResult.<ApiResponse.AppointmentInfo>builder()
            .content(page.getContent().stream().map(this::toAppointmentInfo).toList())
            .page(page.getNumber())
            .size(page.getSize())
            .totalElements(page.getTotalElements())
            .totalPages(page.getTotalPages())
            .last(page.isLast())
            .build();
    }
}
