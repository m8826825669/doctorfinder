package com.doctorfinder.service;

import com.doctorfinder.dto.request.DoctorRequest;
import com.doctorfinder.entity.DoctorProfile;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class DoctorSpecification {

    public static Specification<DoctorProfile> build(DoctorRequest.Search req) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            // Always show verified doctors first (optional: can be query param)
            // Free text search on name and bio
            if (req.getQ() != null && !req.getQ().isBlank()) {
                String pattern = "%" + req.getQ().toLowerCase() + "%";
                Join<Object, Object> userJoin = root.join("user", JoinType.LEFT);
                predicates.add(cb.or(
                    cb.like(cb.lower(userJoin.get("fullName")), pattern),
                    cb.like(cb.lower(root.get("bio")), pattern),
                    cb.like(cb.lower(root.get("qualification")), pattern)
                ));
            }

            if (req.getSpecializationId() != null) {
                predicates.add(cb.equal(
                    root.get("specialization").get("id"), req.getSpecializationId()));
            }

            if (req.getCity() != null && !req.getCity().isBlank()) {
                predicates.add(cb.like(
                    cb.lower(root.get("city")),
                    "%" + req.getCity().toLowerCase() + "%"));
            }

            if (req.getMinFee() != null) {
                predicates.add(cb.greaterThanOrEqualTo(
                    root.get("consultationFee"), req.getMinFee()));
            }

            if (req.getMaxFee() != null) {
                predicates.add(cb.lessThanOrEqualTo(
                    root.get("consultationFee"), req.getMaxFee()));
            }

            if (req.getMinExperience() != null) {
                predicates.add(cb.greaterThanOrEqualTo(
                    root.get("experienceYears"), req.getMinExperience()));
            }

            if (req.getMinRating() != null) {
                predicates.add(cb.greaterThanOrEqualTo(
                    root.get("rating"), req.getMinRating()));
            }

            if (Boolean.TRUE.equals(req.getIsVerified())) {
                predicates.add(cb.isTrue(root.get("isVerified")));
            }

            if (Boolean.TRUE.equals(req.getIsFeatured())) {
                predicates.add(cb.isTrue(root.get("isFeatured")));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
