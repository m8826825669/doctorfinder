package com.doctorfinder.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.UUID;

public class AppointmentRequest {

    @Data
    public static class Book {
        @NotNull
        private UUID timeSlotId;

        private String reason;
    }

    @Data
    public static class UpdateNotes {
        private String notes;
        private String prescription;
        private String diagnosis;
    }

    @Data
    public static class Review {
        @NotNull @Min(1) @Max(5)
        private Integer rating;

        private String comment;
    }
}
