package com.doctorfinder.dto.response;

import com.doctorfinder.entity.Appointment;
import com.doctorfinder.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public class ApiResponse {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class Auth {
        private String accessToken;
        private String refreshToken;
        private long expiresIn;
        private UserInfo user;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class UserInfo {
        private UUID id;
        private String email;
        private String fullName;
        private User.Role role;
        private String phone;
        private OffsetDateTime createdAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class SpecializationInfo {
        private Integer id;
        private String name;
        private String description;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class DoctorDetail {
        private UUID id;
        private UUID userId;
        private String email;
        private String fullName;
        private String phone;
        private SpecializationInfo specialization;
        private String bio;
        private Integer experienceYears;
        private BigDecimal consultationFee;
        private String qualification;
        private String clinicName;
        private String clinicAddress;
        private String city;
        private String state;
        private Double latitude;
        private Double longitude;
        private List<String> languages;
        private Boolean isVerified;
        private Boolean isFeatured;
        private BigDecimal rating;
        private Integer totalReviews;
        private String profilePicture;
        private OffsetDateTime createdAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AvailabilityInfo {
        private UUID id;
        private Integer dayOfWeek;
        private String dayName;
        private LocalTime startTime;
        private LocalTime endTime;
        private Integer slotDuration;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class SlotInfo {
        private UUID id;
        private LocalDate slotDate;
        private LocalTime startTime;
        private LocalTime endTime;
        private Boolean isBooked;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AppointmentInfo {
        private UUID id;
        private UserInfo patient;
        private DoctorDetail doctor;
        private SlotInfo timeSlot;
        private Appointment.Status status;
        private String reason;
        private String notes;
        private String prescription;
        private String diagnosis;
        private BigDecimal amount;
        private OffsetDateTime createdAt;
        private OffsetDateTime updatedAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ReviewInfo {
        private UUID id;
        private UUID appointmentId;
        private UserInfo patient;
        private Integer rating;
        private String comment;
        private OffsetDateTime createdAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class NotificationInfo {
        private UUID id;
        private String title;
        private String message;
        private String type;
        private Boolean isRead;
        private OffsetDateTime createdAt;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class AdminStats {
        private long totalUsers;
        private long totalDoctors;
        private long verifiedDoctors;
        private long totalPatients;
        private long totalAppointments;
        private long pendingAppointments;
        private long completedAppointments;
        private long cancelledAppointments;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PagedResult<T> {
        private List<T> content;
        private int page;
        private int size;
        private long totalElements;
        private int totalPages;
        private boolean last;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class MessageResponse {
        private String message;
        private boolean success;
    }
}
