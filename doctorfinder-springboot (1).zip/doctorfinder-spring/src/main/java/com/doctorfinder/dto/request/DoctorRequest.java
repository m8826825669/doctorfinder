package com.doctorfinder.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

public class DoctorRequest {

    @Data
    public static class CreateProfile {
        @NotNull
        private Integer specializationId;

        private String bio;

        @Min(0)
        private Integer experienceYears;

        @DecimalMin("0.0")
        private BigDecimal consultationFee;

        private String qualification;
        private String clinicName;
        private String clinicAddress;
        private String city;
        private String state;
        private Double latitude;
        private Double longitude;
        private List<String> languages;
        private String profilePicture;
    }

    @Data
    public static class UpdateProfile {
        private Integer specializationId;
        private String bio;
        private Integer experienceYears;
        private BigDecimal consultationFee;
        private String qualification;
        private String clinicName;
        private String clinicAddress;
        private String city;
        private String state;
        private Double latitude;
        private Double longitude;
        private List<String> languages;
        private String profilePicture;
    }

    @Data
    public static class AddAvailability {
        @NotNull @Min(0) @Max(6)
        private Integer dayOfWeek;

        @NotNull
        private LocalTime startTime;

        @NotNull
        private LocalTime endTime;

        @Min(15)
        private Integer slotDuration = 30;
    }

    @Data
    public static class GenerateSlots {
        @NotNull
        private LocalDate fromDate;

        @NotNull
        private LocalDate toDate;
    }

    @Data
    public static class Search {
        private String q;
        private Integer specializationId;
        private String city;
        private Double lat;
        private Double lng;
        private Double radiusKm;
        private BigDecimal minFee;
        private BigDecimal maxFee;
        private Integer minExperience;
        private Double minRating;
        private Boolean isVerified;
        private Boolean isFeatured;
        private String language;
        private String sortBy = "rating";
        private String sortDir = "desc";
        private Integer page = 0;
        private Integer size = 10;
    }
}
