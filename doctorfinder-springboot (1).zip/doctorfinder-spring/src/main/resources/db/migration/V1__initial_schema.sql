-- V1__initial_schema.sql
-- DoctorFinder - Complete Database Schema

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- ─────────────────────────────────────────
-- USERS
-- ─────────────────────────────────────────
CREATE TABLE users (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email       VARCHAR(255) UNIQUE NOT NULL,
    full_name   VARCHAR(255) NOT NULL,
    password    VARCHAR(255) NOT NULL,
    role        VARCHAR(20) NOT NULL CHECK (role IN ('PATIENT','DOCTOR','ADMIN')),
    phone       VARCHAR(20),
    is_active   BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role  ON users(role);

-- ─────────────────────────────────────────
-- SPECIALIZATIONS
-- ─────────────────────────────────────────
CREATE TABLE specializations (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed common specializations
INSERT INTO specializations (name, description) VALUES
('General Medicine',   'Primary care and general health issues'),
('Cardiology',         'Heart and cardiovascular system'),
('Dermatology',        'Skin, hair and nail conditions'),
('Orthopedics',        'Bones, joints and muscles'),
('Pediatrics',         'Medical care for children'),
('Gynecology',         'Female reproductive health'),
('Neurology',          'Brain and nervous system'),
('Psychiatry',         'Mental health and behavioral disorders'),
('Ophthalmology',      'Eye care and vision'),
('ENT',                'Ear, nose and throat'),
('Dentistry',          'Oral and dental health'),
('Endocrinology',      'Hormones and metabolism'),
('Gastroenterology',   'Digestive system disorders'),
('Pulmonology',        'Lung and respiratory conditions'),
('Urology',            'Urinary tract and male reproductive system');

-- ─────────────────────────────────────────
-- DOCTOR PROFILES
-- ─────────────────────────────────────────
CREATE TABLE doctor_profiles (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    specialization_id   INT REFERENCES specializations(id),
    bio                 TEXT,
    experience_years    INT DEFAULT 0,
    consultation_fee    DECIMAL(10,2) DEFAULT 0,
    qualification       VARCHAR(500),
    clinic_name         VARCHAR(255),
    clinic_address      TEXT,
    city                VARCHAR(100),
    state               VARCHAR(100),
    latitude            DOUBLE PRECISION,
    longitude           DOUBLE PRECISION,
    languages           TEXT[],
    is_verified         BOOLEAN DEFAULT FALSE,
    is_featured         BOOLEAN DEFAULT FALSE,
    rating              DECIMAL(3,2) DEFAULT 0.0,
    total_reviews       INT DEFAULT 0,
    profile_picture     VARCHAR(500),
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_doctor_profiles_user_id         ON doctor_profiles(user_id);
CREATE INDEX idx_doctor_profiles_specialization  ON doctor_profiles(specialization_id);
CREATE INDEX idx_doctor_profiles_city            ON doctor_profiles(city);
CREATE INDEX idx_doctor_profiles_is_verified     ON doctor_profiles(is_verified);
CREATE INDEX idx_doctor_profiles_rating          ON doctor_profiles(rating DESC);

-- ─────────────────────────────────────────
-- AVAILABILITY (Weekly Schedule)
-- ─────────────────────────────────────────
CREATE TABLE availability (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    doctor_id       UUID NOT NULL REFERENCES doctor_profiles(id) ON DELETE CASCADE,
    day_of_week     INT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),  -- 0=Mon, 6=Sun
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    slot_duration   INT DEFAULT 30,   -- minutes
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_availability_doctor ON availability(doctor_id);

-- ─────────────────────────────────────────
-- TIME SLOTS (Generated from Availability)
-- ─────────────────────────────────────────
CREATE TABLE time_slots (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    doctor_id       UUID NOT NULL REFERENCES doctor_profiles(id) ON DELETE CASCADE,
    slot_date       DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    is_booked       BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_time_slots_unique  ON time_slots(doctor_id, slot_date, start_time);
CREATE INDEX        idx_time_slots_doctor  ON time_slots(doctor_id);
CREATE INDEX        idx_time_slots_date    ON time_slots(slot_date);
CREATE INDEX        idx_time_slots_booked  ON time_slots(is_booked);

-- ─────────────────────────────────────────
-- APPOINTMENTS
-- ─────────────────────────────────────────
CREATE TABLE appointments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES users(id),
    doctor_id       UUID NOT NULL REFERENCES doctor_profiles(id),
    time_slot_id    UUID NOT NULL REFERENCES time_slots(id),
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                    CHECK (status IN ('PENDING','CONFIRMED','COMPLETED','CANCELLED')),
    reason          TEXT,
    notes           TEXT,
    prescription    TEXT,
    diagnosis       TEXT,
    amount          DECIMAL(10,2),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_appointments_patient  ON appointments(patient_id);
CREATE INDEX idx_appointments_doctor   ON appointments(doctor_id);
CREATE INDEX idx_appointments_status   ON appointments(status);
CREATE INDEX idx_appointments_slot     ON appointments(time_slot_id);

-- ─────────────────────────────────────────
-- REVIEWS
-- ─────────────────────────────────────────
CREATE TABLE reviews (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    appointment_id  UUID UNIQUE NOT NULL REFERENCES appointments(id),
    patient_id      UUID NOT NULL REFERENCES users(id),
    doctor_id       UUID NOT NULL REFERENCES doctor_profiles(id),
    rating          INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment         TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_reviews_doctor   ON reviews(doctor_id);
CREATE INDEX idx_reviews_patient  ON reviews(patient_id);

-- ─────────────────────────────────────────
-- NOTIFICATIONS
-- ─────────────────────────────────────────
CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title           VARCHAR(255) NOT NULL,
    message         TEXT NOT NULL,
    type            VARCHAR(50) DEFAULT 'GENERAL',
    is_read         BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_notifications_user    ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_created ON notifications(created_at DESC);

-- ─────────────────────────────────────────
-- REFRESH TOKENS
-- ─────────────────────────────────────────
CREATE TABLE refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token       TEXT UNIQUE NOT NULL,
    expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_refresh_tokens_user  ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_token ON refresh_tokens(token);
