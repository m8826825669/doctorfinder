# DoctorFinder — Spring Boot Backend

Doctor Search & Appointment Booking Platform  
**Stack:** Spring Boot 3.2 · Java 21 · PostgreSQL · Elasticsearch 9 · Redis · JWT

---

## Prerequisites

| Tool | Version | Download |
|---|---|---|
| Java JDK | 21 (Temurin) | https://adoptium.net |
| Maven | 3.9+ | https://maven.apache.org/download.cgi |
| PostgreSQL | 15+ | Already running |
| Redis | 3+ | Already running |
| Elasticsearch | 9.3 | Already running |

### Add Java & Maven to Windows PATH

After installing, open System Properties → Environment Variables:
- Add `JAVA_HOME` = `C:\Program Files\Eclipse Adoptium\jdk-21...`
- Add to PATH: `%JAVA_HOME%\bin` and `C:\maven\bin`

Verify:
```
java -version   → openjdk 21...
mvn -version    → Apache Maven 3.9...
```

---

## Setup Steps

### 1. Set application.yml credentials

Edit `src/main/resources/application.yml`:

```yaml
spring:
  datasource:
    password: YOUR_POSTGRES_PASSWORD   # ← your postgres password

  elasticsearch:
    password: "DLMoTp=ZJrc6PL8XM9xS"  # ← quotes required (= sign)
```

### 2. Build

```powershell
cd D:\mywork\DoctorFinder\springboot

mvn clean install -DskipTests
```

### 3. Run

```powershell
mvn spring-boot:run
```

### 4. Verify

- Swagger UI  → http://localhost:8080/docs
- Health      → http://localhost:8080/health
- API Docs    → http://localhost:8080/api-docs

---

## API Endpoints (28 total)

### Auth `/api/v1/auth`
| Method | Endpoint | Auth |
|---|---|---|
| POST | /register | ❌ |
| POST | /login | ❌ |
| POST | /refresh | ❌ |
| GET | /me | ✅ |
| POST | /change-password | ✅ |

### Doctors `/api/v1/doctors`
| Method | Endpoint | Auth |
|---|---|---|
| GET | /specializations | ❌ |
| POST | /specializations | ADMIN |
| GET | /search | ❌ |
| POST | /profile | DOCTOR |
| GET | /{id} | ❌ |
| PUT | /profile | DOCTOR |
| GET | /{id}/reviews | ❌ |
| POST | /{id}/availability | DOCTOR |
| GET | /{id}/availability | ❌ |
| DELETE | /{id}/availability/{aid} | DOCTOR |
| POST | /{id}/slots/generate | DOCTOR |
| GET | /{id}/slots | ❌ |
| GET | /{id}/slots/range | ❌ |

### Appointments `/api/v1/appointments`
| Method | Endpoint | Auth |
|---|---|---|
| POST | / | ✅ |
| GET | /my | ✅ |
| GET | /doctor | DOCTOR |
| GET | /{id} | ✅ |
| PATCH | /{id} | DOCTOR |
| POST | /{id}/confirm | DOCTOR |
| POST | /{id}/cancel | ✅ |
| POST | /{id}/complete | DOCTOR |
| POST | /{id}/review | ✅ |

### Notifications `/api/v1/notifications`
| Method | Endpoint | Auth |
|---|---|---|
| GET | / | ✅ |
| POST | /{id}/read | ✅ |
| POST | /read-all | ✅ |

### Admin `/api/v1/admin`
| Method | Endpoint | Auth |
|---|---|---|
| GET | /stats | ADMIN |
| POST | /doctors/{id}/verify | ADMIN |
| POST | /doctors/{id}/feature | ADMIN |

---

## Common Errors & Fixes

| Error | Fix |
|---|---|
| `JAVA_HOME not set` | Set env variable, restart terminal |
| `Port 8080 in use` | Change `server.port: 8081` in yml |
| `Flyway migration failed` | `spring.flyway.baseline-on-migrate: true` (already set) |
| `Connection refused postgres` | Start PostgreSQL service |
| `ES AuthenticationException` | Check ES password has quotes in yml |
| `SSL handshake failed` | ElasticsearchConfig uses trust-all SSL (already handled) |

---

## Quick Test (after running)

```powershell
# Register admin
curl -X POST http://localhost:8080/api/v1/auth/register ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"admin@test.com\",\"password\":\"admin1234\",\"fullName\":\"Admin\",\"role\":\"ADMIN\"}"

# Login
curl -X POST http://localhost:8080/api/v1/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"admin@test.com\",\"password\":\"admin1234\"}"

# Search doctors
curl http://localhost:8080/api/v1/doctors/search
```
