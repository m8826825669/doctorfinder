// lib/api.ts
import axios from 'axios'
import Cookies from 'js-cookie'

const BASE = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api/v1'

export const api = axios.create({ baseURL: BASE })

// Attach token to every request
api.interceptors.request.use(cfg => {
  const token = Cookies.get('token')
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
})

// Auto-refresh on 401
api.interceptors.response.use(
  res => res,
  async err => {
    const original = err.config
    if (err.response?.status === 401 && !original._retry) {
      original._retry = true
      try {
        const refresh = Cookies.get('refreshToken')
        if (!refresh) throw new Error('No refresh token')
        const { data } = await axios.post(`${BASE}/auth/refresh`, { refreshToken: refresh })
        Cookies.set('token', data.accessToken, { expires: 1 })
        Cookies.set('refreshToken', data.refreshToken, { expires: 7 })
        original.headers.Authorization = `Bearer ${data.accessToken}`
        return api(original)
      } catch {
        Cookies.remove('token')
        Cookies.remove('refreshToken')
        Cookies.remove('user')
        window.location.href = '/auth/login'
      }
    }
    return Promise.reject(err)
  }
)

// ─── Auth ────────────────────────────────────────────────
export const authApi = {
  register: (data: { email: string; password: string; fullName: string; role: string; phone?: string }) => {
    // Strip empty/undefined fields — FastAPI 422s on empty string for optional fields
    // FastAPI (port 8000) uses snake_case + uppercase role enum
    const payload: Record<string, string> = {
      email:     data.email.trim(),
      password:  data.password,
      full_name: data.fullName.trim(),  // FastAPI Pydantic: full_name
      role:      data.role.toUpperCase(), // FastAPI enum: PATIENT/DOCTOR/ADMIN
    }
    if (data.phone && data.phone.trim()) payload.phone = data.phone.trim()
    return api.post('/auth/register', payload)
  },
  login: (email: string, password: string) =>
    api.post('/auth/login', { email: email.trim(), password }),
  me: () => api.get('/auth/me'),
  changePassword: (oldPassword: string, newPassword: string) =>
    api.post('/auth/change-password', { oldPassword, newPassword }),
}

// ─── Doctors ─────────────────────────────────────────────
export const doctorApi = {
  search: (params: Record<string, unknown>) =>
    api.get('/doctors/search', { params }),
  getById: (id: string) =>
    api.get(`/doctors/${id}`),
  getSpecializations: () =>
    api.get('/doctors/specializations'),
  createProfile: (data: Record<string, unknown>) =>
    api.post('/doctors/profile', data),
  updateProfile: (data: Record<string, unknown>) =>
    api.put('/doctors/profile', data),
  getReviews: (id: string, page = 0, size = 10) =>
    api.get(`/doctors/${id}/reviews`, { params: { page, size } }),
  addAvailability: (id: string, data: Record<string, unknown>) =>
    api.post(`/doctors/${id}/availability`, data),
  getAvailability: (id: string) =>
    api.get(`/doctors/${id}/availability`),
  deleteAvailability: (id: string, aid: string) =>
    api.delete(`/doctors/${id}/availability/${aid}`),
  generateSlots: (id: string, data: { fromDate: string; toDate: string }) =>
    api.post(`/doctors/${id}/slots/generate`, data),
  getSlots: (id: string, date: string) =>
    api.get(`/doctors/${id}/slots`, { params: { date } }),
  getSlotsRange: (id: string, from: string, to: string) =>
    api.get(`/doctors/${id}/slots/range`, { params: { from, to } }),
}

// ─── Appointments ─────────────────────────────────────────
export const appointmentApi = {
  book: (timeSlotId: string, reason?: string) =>
    api.post('/appointments', { timeSlotId, reason }),
  myAppointments: (page = 0, size = 10) =>
    api.get('/appointments/my', { params: { page, size } }),
  doctorAppointments: (page = 0, size = 10) =>
    api.get('/appointments/doctor', { params: { page, size } }),
  getById: (id: string) =>
    api.get(`/appointments/${id}`),
  updateNotes: (id: string, data: Record<string, string>) =>
    api.patch(`/appointments/${id}`, data),
  confirm: (id: string) => api.post(`/appointments/${id}/confirm`),
  cancel: (id: string) =>  api.post(`/appointments/${id}/cancel`),
  complete: (id: string) => api.post(`/appointments/${id}/complete`),
  review: (id: string, rating: number, comment?: string) =>
    api.post(`/appointments/${id}/review`, { rating, comment }),
}

// ─── Notifications ────────────────────────────────────────
export const notificationApi = {
  getAll: (page = 0, size = 20) =>
    api.get('/notifications', { params: { page, size } }),
  markRead: (id: string) =>
    api.post(`/notifications/${id}/read`),
  markAllRead: () =>
    api.post('/notifications/read-all'),
}

// ─── Admin ────────────────────────────────────────────────
export const adminApi = {
  getStats: () => api.get('/admin/stats'),
  verifyDoctor: (id: string) => api.post(`/admin/doctors/${id}/verify`),
  featureDoctor: (id: string, featured: boolean) =>
    api.post(`/admin/doctors/${id}/feature`, { featured }),
}
