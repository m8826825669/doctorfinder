// lib/auth.ts
import Cookies from 'js-cookie'
import { User } from '@/types'

export const getUser = (): User | null => {
  try {
    const u = Cookies.get('user')
    return u ? JSON.parse(u) : null
  } catch { return null }
}

export const getToken = (): string | null =>
  Cookies.get('token') || null

export const isLoggedIn = (): boolean => !!getToken()

export const saveAuth = (token: string, refreshToken: string, user: User) => {
  Cookies.set('token', token, { expires: 1 })
  Cookies.set('refreshToken', refreshToken, { expires: 7 })
  Cookies.set('user', JSON.stringify(user), { expires: 1 })
}

// Normalize FastAPI snake_case response → camelCase for frontend
// FastAPI returns: access_token, refresh_token, user.full_name
export const normalizeAuthResponse = (data: Record<string, unknown>) => {
  const raw = data as Record<string, unknown>
  const rawUser = (raw.user || {}) as Record<string, unknown>

  const token        = (raw.accessToken  || raw.access_token)  as string
  const refreshToken = (raw.refreshToken || raw.refresh_token) as string

  const user: User = {
    id:        (rawUser.id)                                    as string,
    email:     (rawUser.email)                                 as string,
    fullName:  (rawUser.fullName  || rawUser.full_name)        as string,
    role:      (rawUser.role)                                  as User['role'],
    phone:     (rawUser.phone)                                 as string | undefined,
    createdAt: (rawUser.createdAt || rawUser.created_at)       as string,
  }

  return { token, refreshToken, user }
}

export const logout = () => {
  Cookies.remove('token')
  Cookies.remove('refreshToken')
  Cookies.remove('user')
  window.location.href = '/auth/login'
}

export const getDashboardPath = (role: string): string => {
  switch (role) {
    case 'DOCTOR': return '/dashboard/doctor'
    case 'ADMIN':  return '/admin'
    default:       return '/dashboard/patient'
  }
}
