'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'
import { Bell, Menu, X, Stethoscope, ChevronDown, LogOut, User, LayoutDashboard } from 'lucide-react'
import { getUser, logout, isLoggedIn, getDashboardPath } from '@/lib/auth'
import { User as UserType } from '@/types'

export default function Navbar() {
  const router = useRouter()
  const [user, setUser] = useState<UserType | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [dropOpen, setDropOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    setUser(getUser())
    const onScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-white/95 backdrop-blur shadow-sm border-b border-slate-100' : 'bg-white'
    }`}>
      <div className="page-container">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 bg-primary-600 rounded-xl flex items-center justify-center shadow-glow group-hover:scale-105 transition-transform">
              <Stethoscope size={20} className="text-white" />
            </div>
            <span className="font-display font-bold text-xl text-slate-800">
              Doctor<span className="text-primary-600">Finder</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            <Link href="/" className="btn-ghost text-sm">Home</Link>
            <Link href="/?search=true" className="btn-ghost text-sm">Find Doctors</Link>
            {user && (
              <Link href={getDashboardPath(user.role)} className="btn-ghost text-sm">
                Dashboard
              </Link>
            )}
          </div>

          {/* Right Side */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setDropOpen(v => !v)}
                  className="flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-slate-50 transition-colors"
                >
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-primary-700 font-semibold text-sm">
                      {user.fullName[0]}
                    </span>
                  </div>
                  <span className="text-sm font-medium text-slate-700">{user.fullName.split(' ')[0]}</span>
                  <ChevronDown size={14} className={`text-slate-400 transition-transform ${dropOpen ? 'rotate-180' : ''}`} />
                </button>

                {dropOpen && (
                  <div className="absolute right-0 top-12 w-52 bg-white rounded-2xl shadow-card-hover border border-slate-100 py-2 animate-fade-in z-50">
                    <div className="px-4 py-2 border-b border-slate-50 mb-1">
                      <p className="text-xs text-slate-400">Signed in as</p>
                      <p className="text-sm font-semibold text-slate-700 truncate">{user.email}</p>
                      <span className="badge badge-green mt-1">{user.role}</span>
                    </div>
                    <Link
                      href={getDashboardPath(user.role)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50"
                      onClick={() => setDropOpen(false)}
                    >
                      <LayoutDashboard size={15} /> Dashboard
                    </Link>
                    <button
                      onClick={logout}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50"
                    >
                      <LogOut size={15} /> Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link href="/auth/login" className="btn-ghost text-sm">Sign In</Link>
                <Link href="/auth/register" className="btn-primary text-sm">Get Started</Link>
              </>
            )}
          </div>

          {/* Mobile menu toggle */}
          <button className="md:hidden p-2 rounded-xl hover:bg-slate-100" onClick={() => setMenuOpen(v => !v)}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden border-t border-slate-100 py-4 space-y-1 animate-fade-up">
            <Link href="/" className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl">Home</Link>
            <Link href="/?search=true" className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl">Find Doctors</Link>
            {user ? (
              <>
                <Link href={getDashboardPath(user.role)} className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl">Dashboard</Link>
                <button onClick={logout} className="w-full text-left px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 rounded-xl">Sign Out</button>
              </>
            ) : (
              <>
                <Link href="/auth/login" className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-xl">Sign In</Link>
                <Link href="/auth/register" className="block px-4 py-2.5 text-sm font-semibold text-primary-700 hover:bg-primary-50 rounded-xl">Get Started</Link>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  )
}
