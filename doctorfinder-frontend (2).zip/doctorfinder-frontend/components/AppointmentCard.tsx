'use client'
import { Calendar, Clock, User, Stethoscope, ChevronRight } from 'lucide-react'
import { AppointmentInfo, AppointmentStatus } from '@/types'
import { format } from 'date-fns'

interface Props {
  appointment: AppointmentInfo
  role: 'PATIENT' | 'DOCTOR' | 'ADMIN'
  onAction?: (action: string, id: string) => void
}

const statusConfig: Record<AppointmentStatus, { label: string; cls: string }> = {
  PENDING:   { label: 'Pending',   cls: 'badge-yellow' },
  CONFIRMED: { label: 'Confirmed', cls: 'badge-blue'   },
  COMPLETED: { label: 'Completed', cls: 'badge-green'  },
  CANCELLED: { label: 'Cancelled', cls: 'badge-red'    },
}

export default function AppointmentCard({ appointment, role, onAction }: Props) {
  const { status } = appointment
  const cfg = statusConfig[status]
  const slotDate = appointment.timeSlot?.slotDate

  return (
    <div className="card p-5 animate-fade-up">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex gap-3">
          {/* Icon */}
          <div className="w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center flex-shrink-0">
            <Stethoscope size={18} className="text-primary-600" />
          </div>
          <div>
            <p className="font-semibold text-slate-800">
              {role === 'PATIENT'
                ? `Dr. ${appointment.doctor?.fullName}`
                : appointment.patient?.fullName}
            </p>
            <p className="text-sm text-primary-600">
              {appointment.doctor?.specialization?.name || 'General'}
            </p>
          </div>
        </div>
        <span className={`badge ${cfg.cls}`}>{cfg.label}</span>
      </div>

      {/* Date/Time */}
      <div className="flex flex-wrap gap-4 mt-4">
        <span className="flex items-center gap-1.5 text-sm text-slate-500">
          <Calendar size={13} className="text-primary-400" />
          {slotDate ? format(new Date(slotDate), 'dd MMM yyyy') : '—'}
        </span>
        <span className="flex items-center gap-1.5 text-sm text-slate-500">
          <Clock size={13} className="text-primary-400" />
          {appointment.timeSlot?.startTime?.slice(0, 5)} – {appointment.timeSlot?.endTime?.slice(0, 5)}
        </span>
        {appointment.amount != null && (
          <span className="text-sm font-semibold text-slate-700">₹{appointment.amount}</span>
        )}
      </div>

      {appointment.reason && (
        <p className="mt-3 text-xs text-slate-500 bg-slate-50 rounded-xl px-3 py-2">
          <span className="font-medium">Reason:</span> {appointment.reason}
        </p>
      )}

      {/* Actions */}
      {onAction && (
        <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-slate-50">
          {status === 'PENDING' && role === 'DOCTOR' && (
            <button
              onClick={() => onAction('confirm', appointment.id)}
              className="btn-primary text-xs py-1.5 px-4"
            >
              Confirm
            </button>
          )}
          {status === 'CONFIRMED' && role === 'DOCTOR' && (
            <button
              onClick={() => onAction('complete', appointment.id)}
              className="btn-primary text-xs py-1.5 px-4"
            >
              Mark Complete
            </button>
          )}
          {(status === 'PENDING' || status === 'CONFIRMED') && (
            <button
              onClick={() => onAction('cancel', appointment.id)}
              className="text-xs py-1.5 px-4 rounded-xl border border-red-200 text-red-500 hover:bg-red-50 transition-colors"
            >
              Cancel
            </button>
          )}
          {status === 'COMPLETED' && role === 'PATIENT' && (
            <button
              onClick={() => onAction('review', appointment.id)}
              className="btn-outline text-xs py-1.5 px-4"
            >
              Leave Review
            </button>
          )}
        </div>
      )}
    </div>
  )
}
