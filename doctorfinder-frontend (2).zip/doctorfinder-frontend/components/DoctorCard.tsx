'use client'
import Link from 'next/link'
import { Star, MapPin, Clock, BadgeCheck, Stethoscope } from 'lucide-react'
import { DoctorDetail } from '@/types'

interface Props { doctor: DoctorDetail }

export default function DoctorCard({ doctor }: Props) {
  const stars = Array.from({ length: 5 }, (_, i) => i < Math.round(doctor.rating))

  return (
    <Link href={`/doctors/${doctor.id}`}>
      <div className="card p-5 group cursor-pointer animate-fade-up">
        <div className="flex gap-4">
          {/* Avatar */}
          <div className="flex-shrink-0">
            <div className="w-16 h-16 rounded-2xl bg-primary-50 flex items-center justify-center text-2xl font-display font-bold text-primary-600 group-hover:bg-primary-100 transition-colors">
              {doctor.profilePicture ? (
                <img src={doctor.profilePicture} alt={doctor.fullName}
                  className="w-16 h-16 rounded-2xl object-cover" />
              ) : (
                doctor.fullName[0]
              )}
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold text-slate-800 group-hover:text-primary-700 transition-colors truncate">
                  Dr. {doctor.fullName}
                </h3>
                <p className="text-sm text-primary-600 font-medium">
                  {doctor.specialization?.name || 'General Medicine'}
                </p>
              </div>
              <div className="flex flex-col items-end gap-1 flex-shrink-0">
                {doctor.isVerified && (
                  <span className="badge badge-green">
                    <BadgeCheck size={11} /> Verified
                  </span>
                )}
                {doctor.isFeatured && (
                  <span className="badge badge-yellow">⭐ Featured</span>
                )}
              </div>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-1.5 mt-2">
              <div className="flex">
                {stars.map((filled, i) => (
                  <Star key={i} size={12} className={filled ? 'star-filled fill-amber-400' : 'star-empty'} />
                ))}
              </div>
              <span className="text-xs font-semibold text-slate-600">
                {Number(doctor.rating).toFixed(1)}
              </span>
              <span className="text-xs text-slate-400">({doctor.totalReviews} reviews)</span>
            </div>

            {/* Meta */}
            <div className="flex flex-wrap items-center gap-3 mt-2.5">
              {doctor.city && (
                <span className="flex items-center gap-1 text-xs text-slate-500">
                  <MapPin size={11} /> {doctor.city}
                </span>
              )}
              <span className="flex items-center gap-1 text-xs text-slate-500">
                <Clock size={11} /> {doctor.experienceYears} yrs exp
              </span>
              <span className="text-xs font-semibold text-slate-700">
                ₹{doctor.consultationFee}
              </span>
            </div>

            {/* Languages */}
            {doctor.languages && doctor.languages.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {doctor.languages.slice(0, 3).map(lang => (
                  <span key={lang} className="badge badge-gray text-xs">{lang}</span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer CTA */}
        <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between">
          <p className="text-xs text-slate-400">
            {doctor.clinicName || 'Online & In-clinic'}
          </p>
          <span className="text-xs font-semibold text-primary-600 group-hover:underline">
            Book Appointment →
          </span>
        </div>
      </div>
    </Link>
  )
}
