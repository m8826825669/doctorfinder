# DoctorFinder — Next.js Frontend

Doctor Search & Appointment Booking Platform  
**Stack:** Next.js 14 · TypeScript · Tailwind CSS · Axios

---

## Prerequisites

- Node.js 18+ (https://nodejs.org)
- DoctorFinder FastAPI backend running on `http://127.0.0.1:8000`

---

## Setup & Run

```bash
# 1. Go to frontend folder
cd D:\mywork\DoctorFinder\frontend

# 2. Install dependencies
npm install

# 3. Start dev server
npm run dev

# 4. Open in browser
http://localhost:3000
```

---

## Pages

| URL | Description | Access |
|---|---|---|
| `/` | Home — Hero, Search, Specializations | Public |
| `/auth/login` | Login | Public |
| `/auth/register` | Register (Patient/Doctor) | Public |
| `/doctors/[id]` | Doctor detail + Slot booking | Public |
| `/dashboard/patient` | Patient appointments & notifications | Patient |
| `/dashboard/doctor` | Doctor appointments, availability, slots | Doctor |
| `/dashboard/doctor/setup` | Doctor profile creation | Doctor |
| `/admin` | Admin stats + Doctor management | Admin |

---

## Environment Variables

File: `.env.local`

```env
NEXT_PUBLIC_API_URL=http://127.0.0.1:8000/api/v1
```

Change this to your backend URL if deployed.

---

## Project Structure

```
app/
├── page.tsx                    → Home page
├── layout.tsx                  → Root layout
├── globals.css                 → Design tokens
├── auth/
│   ├── login/page.tsx
│   └── register/page.tsx
├── doctors/[id]/page.tsx       → Doctor detail + booking
├── dashboard/
│   ├── patient/page.tsx
│   └── doctor/
│       ├── page.tsx
│       └── setup/page.tsx
└── admin/page.tsx

components/
├── Navbar.tsx
├── DoctorCard.tsx
└── AppointmentCard.tsx

lib/
├── api.ts          → All API calls (axios)
└── auth.ts         → Auth helpers (cookies)

types/
└── index.ts        → TypeScript types
```

---

## Quick Test

1. Register as **Admin**: `admin@test.com` / `admin1234`
2. Register as **Doctor** → Go to `/dashboard/doctor/setup` to create profile
3. Register as **Patient** → Search doctors on home page → Book appointment
4. Admin → Go to `/admin` → Verify & feature doctors

---

## Flow

```
Patient:
  Register → Home → Search Doctor → View Profile → Select Slot → Book → Dashboard

Doctor:
  Register → Setup Profile → Dashboard → Add Availability → Generate Slots → Manage Appointments

Admin:
  Login → Admin Panel → View Stats → Verify Doctors → Feature Doctors
```
