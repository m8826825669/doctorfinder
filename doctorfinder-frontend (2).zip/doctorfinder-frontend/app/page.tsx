'use client'
import { useState, useEffect } from 'react'
import { Search, MapPin, Stethoscope, Star, Users, Shield, ChevronRight, Sparkles } from 'lucide-react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import DoctorCard from '@/components/DoctorCard'
import { doctorApi } from '@/lib/api'
import { DoctorDetail, Specialization, PagedResult } from '@/types'
import toast from 'react-hot-toast'

const SPECIALIZATIONS_ICONS: Record<string, string> = {
  'General Medicine': '🩺', 'Cardiology': '❤️', 'Dermatology': '✨',
  'Orthopedics': '🦴', 'Pediatrics': '👶', 'Gynecology': '🌸',
  'Neurology': '🧠', 'Psychiatry': '💭', 'ENT': '👂',
  'Ophthalmology': '👁️', 'Dentistry': '🦷', 'Gastroenterology': '🫁',
}

export default function HomePage() {
  const router = useRouter()
  const [query, setQuery]               = useState('')
  const [city, setCity]                 = useState('')
  const [specs, setSpecs]               = useState<Specialization[]>([])
  const [selectedSpec, setSelectedSpec] = useState<number | null>(null)
  const [doctors, setDoctors]           = useState<DoctorDetail[]>([])
  const [loading, setLoading]           = useState(false)
  const [searched, setSearched]         = useState(false)
  const [total, setTotal]               = useState(0)

  useEffect(() => {
    doctorApi.getSpecializations()
      .then(r => setSpecs(r.data))
      .catch(() => {})
  }, [])

  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault()
    setLoading(true)
    setSearched(true)
    try {
      const params: Record<string, unknown> = { page: 0, size: 12 }
      if (query) params.q = query
      if (city) params.city = city
      if (selectedSpec) params.specializationId = selectedSpec
      const r = await doctorApi.search(params)
      const data: PagedResult<DoctorDetail> = r.data
      setDoctors(data.content)
      setTotal(data.totalElements)
    } catch {
      toast.error('Search failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleSpecClick = (id: number) => {
    setSelectedSpec(prev => prev === id ? null : id)
  }

  return (
    <>
      <Navbar />
      <main className="pt-16">
        {/* ── Hero ──────────────────────────────────────── */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary-700 via-primary-600 to-primary-800 py-20 md:py-28">
          {/* Background decoration */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-20 w-72 h-72 rounded-full bg-white blur-3xl" />
            <div className="absolute bottom-0 right-20 w-96 h-96 rounded-full bg-primary-300 blur-3xl" />
          </div>
          <div className="absolute top-8 right-8 opacity-20">
            <Sparkles size={120} className="text-white" />
          </div>

          <div className="page-container relative z-10">
            <div className="max-w-2xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur text-white text-sm font-medium px-4 py-2 rounded-full mb-6 animate-fade-up">
                <Shield size={14} /> India's Trusted Doctor Booking Platform
              </div>
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-4 animate-fade-up animate-delay-100">
                Find the Right Doctor,{' '}
                <em className="not-italic text-primary-200">Right Now</em>
              </h1>
              <p className="text-primary-100 text-lg mb-10 animate-fade-up animate-delay-200">
                Search from 10,000+ verified specialists. Book instantly, no waiting.
              </p>

              {/* Search Box */}
              <form onSubmit={handleSearch}
                className="bg-white rounded-2xl shadow-xl p-2 flex flex-col sm:flex-row gap-2 animate-fade-up animate-delay-300">
                <div className="flex-1 flex items-center gap-2 px-3">
                  <Search size={16} className="text-slate-400 flex-shrink-0" />
                  <input
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    placeholder="Doctor name, specialization..."
                    className="flex-1 py-2.5 text-slate-700 placeholder-slate-400 text-sm outline-none bg-transparent"
                  />
                </div>
                <div className="flex items-center gap-2 px-3 sm:border-l border-slate-100">
                  <MapPin size={16} className="text-slate-400 flex-shrink-0" />
                  <input
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    placeholder="City"
                    className="w-28 py-2.5 text-slate-700 placeholder-slate-400 text-sm outline-none bg-transparent"
                  />
                </div>
                <button type="submit" className="btn-primary rounded-xl whitespace-nowrap">
                  Search Doctors
                </button>
              </form>
            </div>
          </div>
        </section>

        {/* ── Stats ─────────────────────────────────────── */}
        <section className="bg-white border-b border-slate-100">
          <div className="page-container py-6">
            <div className="grid grid-cols-3 gap-4 md:gap-8 max-w-lg mx-auto text-center">
              {[
                { icon: <Users size={18}/>, value: '10,000+', label: 'Doctors' },
                { icon: <Star size={18}/>, value: '4.8★',     label: 'Avg Rating' },
                { icon: <Shield size={18}/>, value: '100%',   label: 'Verified' },
              ].map((s, i) => (
                <div key={i} className="flex flex-col items-center gap-1">
                  <div className="text-primary-500">{s.icon}</div>
                  <span className="font-display font-bold text-xl text-slate-800">{s.value}</span>
                  <span className="text-xs text-slate-400">{s.label}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Specializations ───────────────────────────── */}
        <section className="py-12 page-container">
          <h2 className="section-title mb-2">Browse by Specialization</h2>
          <p className="text-slate-500 text-sm mb-6">Click to filter doctors</p>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {specs.slice(0, 12).map(s => (
              <button
                key={s.id}
                onClick={() => { handleSpecClick(s.id); handleSearch() }}
                className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 text-center transition-all duration-200 hover:border-primary-400 hover:shadow-md ${
                  selectedSpec === s.id
                    ? 'border-primary-500 bg-primary-50 shadow-glow'
                    : 'border-slate-100 bg-white'
                }`}
              >
                <span className="text-2xl">{SPECIALIZATIONS_ICONS[s.name] || '🏥'}</span>
                <span className="text-xs font-medium text-slate-600 leading-tight">{s.name}</span>
              </button>
            ))}
          </div>
        </section>

        {/* ── Results ───────────────────────────────────── */}
        <section className="py-8 page-container">
          {loading && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="card p-5 animate-pulse h-48">
                  <div className="flex gap-4">
                    <div className="w-16 h-16 bg-slate-100 rounded-2xl" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-slate-100 rounded w-3/4" />
                      <div className="h-3 bg-slate-100 rounded w-1/2" />
                      <div className="h-3 bg-slate-100 rounded w-1/3" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {!loading && searched && (
            <>
              <div className="flex items-center justify-between mb-4">
                <h2 className="section-title text-xl">
                  {total} Doctor{total !== 1 ? 's' : ''} Found
                </h2>
              </div>
              {doctors.length === 0 ? (
                <div className="text-center py-16">
                  <Stethoscope size={48} className="text-slate-200 mx-auto mb-4" />
                  <p className="text-slate-400">No doctors found. Try different filters.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {doctors.map(d => <DoctorCard key={d.id} doctor={d} />)}
                </div>
              )}
            </>
          )}

          {!searched && !loading && (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search size={32} className="text-primary-400" />
              </div>
              <h3 className="font-semibold text-slate-600 mb-2">Search for a Doctor</h3>
              <p className="text-slate-400 text-sm">Use the search bar above or browse by specialization</p>
              <button onClick={() => handleSearch()} className="btn-outline mt-6 text-sm">
                Show All Doctors
              </button>
            </div>
          )}
        </section>

        {/* ── Footer ────────────────────────────────────── */}
        <footer className="bg-slate-900 text-slate-400 mt-16 py-10">
          <div className="page-container text-center">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Stethoscope size={18} className="text-primary-400" />
              <span className="font-display font-bold text-white">DoctorFinder</span>
            </div>
            <p className="text-sm">© 2025 DoctorFinder. All rights reserved.</p>
          </div>
        </footer>
      </main>
    </>
  )
}
