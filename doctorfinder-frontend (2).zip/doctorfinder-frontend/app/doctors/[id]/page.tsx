'use client'
import { useEffect, useState, use } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { doctorApi, appointmentApi } from '@/lib/api'
import { DoctorDetail, SlotInfo, ReviewInfo, PagedResult } from '@/types'
import { getUser, isLoggedIn } from '@/lib/auth'
import {
  Star, MapPin, Clock, BadgeCheck, Calendar, ChevronLeft,
  Stethoscope, Phone, MessageSquare, X
} from 'lucide-react'
import { format, addDays } from 'date-fns'
import toast from 'react-hot-toast'

// Next.js 15 — params is a Promise
export default function DoctorDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)   // ✅ Next.js 15 way
  const router  = useRouter()
  const [doctor, setDoctor]   = useState<DoctorDetail | null>(null)
  const [slots, setSlots]     = useState<SlotInfo[]>([])
  const [reviews, setReviews] = useState<ReviewInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [selDate, setSelDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [selSlot, setSelSlot] = useState<SlotInfo | null>(null)
  const [reason, setReason]   = useState('')
  const [booking, setBooking] = useState(false)
  const [showModal, setShowModal] = useState(false)

  const dates = Array.from({ length: 7 }, (_, i) => format(addDays(new Date(), i), 'yyyy-MM-dd'))

  useEffect(() => {
    Promise.all([
      doctorApi.getById(id),
      doctorApi.getReviews(id),
    ]).then(([d, r]) => {
      setDoctor(d.data)
      setReviews((r.data as PagedResult<ReviewInfo>).content)
    }).catch(() => toast.error('Failed to load doctor'))
      .finally(() => setLoading(false))
  }, [id])

  useEffect(() => {
    if (!id || !selDate) return
    doctorApi.getSlots(id, selDate)
      .then(r => setSlots(r.data))
      .catch(() => setSlots([]))
  }, [id, selDate])

  const handleBook = async () => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    if (!selSlot) { toast.error('Please select a time slot'); return }
    setBooking(true)
    try {
      await appointmentApi.book(selSlot.id, reason)
      toast.success('Appointment booked successfully! 🎉')
      setShowModal(false)
      setSelSlot(null)
      setReason('')
      const r = await doctorApi.getSlots(id, selDate)
      setSlots(r.data)
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message
      toast.error(msg || 'Booking failed')
    } finally {
      setBooking(false)
    }
  }

  if (loading) return (
    <>
      <Navbar />
      <div className="pt-24 page-container">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-slate-100 rounded w-1/3" />
          <div className="h-48 bg-slate-100 rounded-2xl" />
        </div>
      </div>
    </>
  )

  if (!doctor) return null

  const stars = Array.from({ length: 5 }, (_, i) => i < Math.round(doctor.rating))

  return (
    <>
      <Navbar />
      <main className="pt-20 pb-16">
        <div className="page-container">
          <button onClick={() => router.back()}
            className="flex items-center gap-1 text-sm text-slate-500 hover:text-primary-600 mb-6 mt-4 transition-colors">
            <ChevronLeft size={16} /> Back to Search
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left — Profile */}
            <div className="lg:col-span-2 space-y-5">
              <div className="card p-6 animate-fade-up">
                <div className="flex gap-5">
                  <div className="w-24 h-24 rounded-2xl bg-primary-50 flex items-center justify-center text-4xl font-display font-bold text-primary-600 flex-shrink-0">
                    {doctor.profilePicture
                      ? <img src={doctor.profilePicture} className="w-24 h-24 rounded-2xl object-cover" alt="" />
                      : doctor.fullName[0]}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <h1 className="font-display text-2xl font-bold text-slate-800">Dr. {doctor.fullName}</h1>
                        <p className="text-primary-600 font-medium">{doctor.specialization?.name}</p>
                        {doctor.qualification && <p className="text-sm text-slate-500">{doctor.qualification}</p>}
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        {doctor.isVerified && <span className="badge badge-green"><BadgeCheck size={11}/> Verified</span>}
                        {doctor.isFeatured && <span className="badge badge-yellow">⭐ Featured</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-3">
                      <div className="flex">
                        {stars.map((f, i) => <Star key={i} size={14} className={f ? 'star-filled fill-amber-400' : 'star-empty'} />)}
                      </div>
                      <span className="font-semibold text-sm">{Number(doctor.rating).toFixed(1)}</span>
                      <span className="text-slate-400 text-sm">({doctor.totalReviews} reviews)</span>
                    </div>
                    <div className="flex flex-wrap gap-4 mt-3">
                      {doctor.city && (
                        <span className="flex items-center gap-1 text-sm text-slate-500">
                          <MapPin size={13}/> {doctor.city}, {doctor.state}
                        </span>
                      )}
                      <span className="flex items-center gap-1 text-sm text-slate-500">
                        <Clock size={13}/> {doctor.experienceYears} years experience
                      </span>
                      {doctor.phone && (
                        <span className="flex items-center gap-1 text-sm text-slate-500">
                          <Phone size={13}/> {doctor.phone}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-50">
                  {[
                    { label: 'Consultation Fee', value: `₹${doctor.consultationFee}` },
                    { label: 'Experience',       value: `${doctor.experienceYears} Years` },
                    { label: 'Reviews',          value: String(doctor.totalReviews) },
                  ].map(s => (
                    <div key={s.label} className="text-center p-3 bg-slate-50 rounded-xl">
                      <p className="font-bold text-lg text-slate-800">{s.value}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {doctor.bio && (
                <div className="card p-6 animate-fade-up animate-delay-100">
                  <h2 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <MessageSquare size={16} className="text-primary-500"/> About
                  </h2>
                  <p className="text-slate-600 text-sm leading-relaxed">{doctor.bio}</p>
                </div>
              )}

              {doctor.clinicName && (
                <div className="card p-6 animate-fade-up animate-delay-200">
                  <h2 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <Stethoscope size={16} className="text-primary-500"/> Clinic
                  </h2>
                  <p className="font-medium text-slate-700">{doctor.clinicName}</p>
                  {doctor.clinicAddress && <p className="text-sm text-slate-500 mt-1">{doctor.clinicAddress}</p>}
                </div>
              )}

              {reviews.length > 0 && (
                <div className="card p-6 animate-fade-up animate-delay-300">
                  <h2 className="font-semibold text-slate-800 mb-4">Patient Reviews</h2>
                  <div className="space-y-4">
                    {reviews.map(r => (
                      <div key={r.id} className="border-b border-slate-50 pb-4 last:border-0 last:pb-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-slate-700">{r.patient?.fullName || 'Anonymous'}</span>
                          <div className="flex">
                            {Array.from({ length: 5 }, (_, i) => (
                              <Star key={i} size={12} className={i < r.rating ? 'star-filled fill-amber-400' : 'star-empty'} />
                            ))}
                          </div>
                        </div>
                        {r.comment && <p className="text-sm text-slate-500">{r.comment}</p>}
                        <p className="text-xs text-slate-300 mt-1">{format(new Date(r.createdAt), 'dd MMM yyyy')}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right — Booking */}
            <div>
              <div className="card p-5 sticky top-24 animate-fade-up animate-delay-100">
                <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Calendar size={16} className="text-primary-500"/> Book Appointment
                </h2>

                <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
                  {dates.map(d => {
                    const dateObj = new Date(d)
                    return (
                      <button key={d} onClick={() => { setSelDate(d); setSelSlot(null) }}
                        className={`flex-shrink-0 flex flex-col items-center px-3 py-2 rounded-xl border text-xs transition-all ${
                          selDate === d
                            ? 'bg-primary-600 border-primary-600 text-white'
                            : 'border-slate-200 text-slate-600 hover:border-primary-300'
                        }`}>
                        <span>{format(dateObj, 'EEE')}</span>
                        <span className="font-bold text-sm">{format(dateObj, 'd')}</span>
                        <span>{format(dateObj, 'MMM')}</span>
                      </button>
                    )
                  })}
                </div>

                <p className="text-xs font-medium text-slate-500 mb-2">Available Slots</p>
                {slots.length === 0 ? (
                  <p className="text-sm text-slate-400 text-center py-4">No slots available</p>
                ) : (
                  <div className="grid grid-cols-3 gap-2">
                    {slots.map(s => (
                      <button key={s.id} onClick={() => setSelSlot(s)}
                        className={`text-xs py-2 px-1 rounded-xl border text-center transition-all ${
                          selSlot?.id === s.id
                            ? 'bg-primary-600 border-primary-600 text-white font-semibold'
                            : 'border-slate-200 text-slate-600 hover:border-primary-400'
                        }`}>
                        {s.startTime.slice(0, 5)}
                      </button>
                    ))}
                  </div>
                )}

                {selSlot && (
                  <div className="mt-4 p-3 bg-primary-50 rounded-xl border border-primary-100">
                    <p className="text-xs text-primary-700 font-medium">Selected Slot</p>
                    <p className="text-sm font-semibold text-primary-800">
                      {format(new Date(selDate), 'dd MMM yyyy')} at {selSlot.startTime.slice(0, 5)}
                    </p>
                    <p className="text-xs text-primary-600 mt-0.5">Fee: ₹{doctor.consultationFee}</p>
                  </div>
                )}

                <button
                  onClick={() => {
                    if (!isLoggedIn()) { router.push('/auth/login'); return }
                    if (!selSlot) { toast.error('Select a time slot first'); return }
                    setShowModal(true)
                  }}
                  disabled={!selSlot}
                  className="btn-primary w-full justify-center mt-4 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Book Appointment
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {showModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 animate-fade-up">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-800">Confirm Appointment</h3>
              <button onClick={() => setShowModal(false)}><X size={20} className="text-slate-400"/></button>
            </div>
            <div className="bg-slate-50 rounded-xl p-4 mb-4 text-sm space-y-1">
              <p><span className="text-slate-400">Doctor:</span> <span className="font-medium">Dr. {doctor.fullName}</span></p>
              <p><span className="text-slate-400">Date:</span> <span className="font-medium">{format(new Date(selDate), 'dd MMM yyyy')}</span></p>
              <p><span className="text-slate-400">Time:</span> <span className="font-medium">{selSlot?.startTime.slice(0, 5)}</span></p>
              <p><span className="text-slate-400">Fee:</span> <span className="font-semibold text-primary-700">₹{doctor.consultationFee}</span></p>
            </div>
            <div className="mb-4">
              <label className="label">Reason for Visit (optional)</label>
              <textarea className="input resize-none" rows={3}
                placeholder="Describe your symptoms..."
                value={reason} onChange={e => setReason(e.target.value)}/>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowModal(false)} className="btn-ghost flex-1">Cancel</button>
              <button onClick={handleBook} disabled={booking}
                className="btn-primary flex-1 justify-center flex items-center gap-2">
                {booking && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>}
                {booking ? 'Booking...' : 'Confirm Booking'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
