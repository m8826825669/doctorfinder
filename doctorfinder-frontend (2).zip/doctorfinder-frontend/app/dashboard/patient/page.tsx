'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import AppointmentCard from '@/components/AppointmentCard'
import { appointmentApi, notificationApi } from '@/lib/api'
import { getUser, isLoggedIn } from '@/lib/auth'
import { AppointmentInfo, NotificationInfo, PagedResult, User } from '@/types'
import {
  Calendar, Bell, User as UserIcon, Clock,
  CheckCircle, XCircle, AlertCircle, Star, X
} from 'lucide-react'
import toast from 'react-hot-toast'

type Tab = 'appointments' | 'notifications'

export default function PatientDashboard() {
  const router = useRouter()
  const [user, setUser]                   = useState<User | null>(null)
  const [tab, setTab]                     = useState<Tab>('appointments')
  const [appointments, setAppointments]   = useState<AppointmentInfo[]>([])
  const [notifications, setNotifications] = useState<NotificationInfo[]>([])
  const [loading, setLoading]             = useState(true)
  const [unread, setUnread]               = useState(0)
  const [reviewModal, setReviewModal]     = useState<{ open: boolean; appointmentId: string }>({ open: false, appointmentId: '' })
  const [rating, setRating]               = useState(5)
  const [comment, setComment]             = useState('')
  const [submitting, setSubmitting]       = useState(false)

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (u?.role !== 'PATIENT') { router.push('/'); return }
    setUser(u)
    fetchAll()
  }, [])

  const fetchAll = async () => {
    setLoading(true)
    try {
      const [appts, notifs] = await Promise.all([
        appointmentApi.myAppointments(0, 20),
        notificationApi.getAll(0, 20),
      ])
      setAppointments((appts.data as PagedResult<AppointmentInfo>).content)
      const notifList = (notifs.data as PagedResult<NotificationInfo>).content
      setNotifications(notifList)
      setUnread(notifList.filter(n => !n.isRead).length)
    } catch {
      toast.error('Failed to load data')
    } finally {
      setLoading(false)
    }
  }

  const handleAction = async (action: string, id: string) => {
    try {
      if (action === 'cancel') {
        await appointmentApi.cancel(id)
        toast.success('Appointment cancelled')
        fetchAll()
      } else if (action === 'review') {
        setReviewModal({ open: true, appointmentId: id })
      }
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Action failed')
    }
  }

  const submitReview = async () => {
    setSubmitting(true)
    try {
      await appointmentApi.review(reviewModal.appointmentId, rating, comment)
      toast.success('Review submitted! Thank you 🌟')
      setReviewModal({ open: false, appointmentId: '' })
      setRating(5); setComment('')
      fetchAll()
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Review failed')
    } finally {
      setSubmitting(false)
    }
  }

  const markAllRead = async () => {
    await notificationApi.markAllRead()
    setUnread(0)
    setNotifications(n => n.map(x => ({ ...x, isRead: true })))
    toast.success('All notifications marked as read')
  }

  // Stats
  const stats = {
    total:     appointments.length,
    upcoming:  appointments.filter(a => a.status === 'CONFIRMED').length,
    completed: appointments.filter(a => a.status === 'COMPLETED').length,
    cancelled: appointments.filter(a => a.status === 'CANCELLED').length,
  }

  return (
    <>
      <Navbar />
      <main className="pt-20 pb-16 min-h-screen bg-slate-50">
        <div className="page-container">

          {/* Header */}
          <div className="py-6 animate-fade-up">
            <h1 className="section-title">
              Welcome back, {user?.fullName.split(' ')[0]} 👋
            </h1>
            <p className="text-slate-500 text-sm mt-1">Manage your appointments and health records</p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {[
              { label: 'Total',     value: stats.total,     icon: <Calendar size={18}/>,    color: 'bg-blue-50 text-blue-600' },
              { label: 'Upcoming',  value: stats.upcoming,  icon: <Clock size={18}/>,       color: 'bg-primary-50 text-primary-600' },
              { label: 'Completed', value: stats.completed, icon: <CheckCircle size={18}/>, color: 'bg-green-50 text-green-600' },
              { label: 'Cancelled', value: stats.cancelled, icon: <XCircle size={18}/>,     color: 'bg-red-50 text-red-500' },
            ].map((s, i) => (
              <div key={i} className={`card p-4 animate-fade-up animate-delay-${i}00`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-400 font-medium">{s.label}</span>
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${s.color}`}>
                    {s.icon}
                  </div>
                </div>
                <p className="text-2xl font-bold text-slate-800">{s.value}</p>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-white rounded-2xl p-1 border border-slate-100 w-fit mb-6 shadow-sm">
            {([
              { id: 'appointments',  label: 'Appointments', icon: <Calendar size={14}/> },
              { id: 'notifications', label: `Notifications${unread > 0 ? ` (${unread})` : ''}`, icon: <Bell size={14}/> },
            ] as { id: Tab; label: string; icon: React.ReactNode }[]).map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  tab === t.id
                    ? 'bg-primary-600 text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                {t.icon} {t.label}
              </button>
            ))}
          </div>

          {/* Content */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1,2,3,4].map(i => (
                <div key={i} className="card p-5 animate-pulse h-40">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 bg-slate-100 rounded-xl"/>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-slate-100 rounded w-3/4"/>
                      <div className="h-3 bg-slate-100 rounded w-1/2"/>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : tab === 'appointments' ? (
            appointments.length === 0 ? (
              <div className="text-center py-20 card">
                <Calendar size={48} className="text-slate-200 mx-auto mb-4"/>
                <p className="font-semibold text-slate-500">No appointments yet</p>
                <p className="text-sm text-slate-400 mb-4">Book your first appointment with a doctor</p>
                <button onClick={() => router.push('/')} className="btn-primary text-sm">Find Doctors</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {appointments.map(a => (
                  <AppointmentCard key={a.id} appointment={a} role="PATIENT" onAction={handleAction} />
                ))}
              </div>
            )
          ) : (
            <div className="space-y-3">
              {unread > 0 && (
                <div className="flex justify-end">
                  <button onClick={markAllRead} className="text-sm text-primary-600 hover:underline">
                    Mark all as read
                  </button>
                </div>
              )}
              {notifications.length === 0 ? (
                <div className="text-center py-20 card">
                  <Bell size={48} className="text-slate-200 mx-auto mb-4"/>
                  <p className="text-slate-400">No notifications yet</p>
                </div>
              ) : (
                notifications.map(n => (
                  <div key={n.id} className={`card p-4 flex gap-3 transition-colors ${!n.isRead ? 'border-l-4 border-l-primary-500' : ''}`}>
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      n.type.includes('CONFIRMED') ? 'bg-blue-50 text-blue-500' :
                      n.type.includes('CANCELLED') ? 'bg-red-50 text-red-500' :
                      n.type.includes('COMPLETED') ? 'bg-green-50 text-green-500' :
                      'bg-primary-50 text-primary-500'
                    }`}>
                      <Bell size={14}/>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-slate-700">{n.title}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{n.message}</p>
                    </div>
                    {!n.isRead && <div className="w-2 h-2 bg-primary-500 rounded-full mt-1.5 flex-shrink-0"/>}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </main>

      {/* Review Modal */}
      {reviewModal.open && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 animate-fade-up">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold text-slate-800">Leave a Review</h3>
              <button onClick={() => setReviewModal({ open: false, appointmentId: '' })}>
                <X size={20} className="text-slate-400"/>
              </button>
            </div>

            {/* Star Rating */}
            <div className="text-center mb-5">
              <p className="text-sm text-slate-500 mb-3">How would you rate your experience?</p>
              <div className="flex justify-center gap-2">
                {[1,2,3,4,5].map(s => (
                  <button key={s} onClick={() => setRating(s)}>
                    <Star size={32} className={s <= rating ? 'star-filled fill-amber-400' : 'star-empty text-slate-200'} />
                  </button>
                ))}
              </div>
              <p className="text-sm font-semibold text-primary-600 mt-2">
                {['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'][rating]}
              </p>
            </div>

            <div className="mb-4">
              <label className="label">Comment (optional)</label>
              <textarea className="input resize-none" rows={3}
                placeholder="Share your experience..."
                value={comment} onChange={e => setComment(e.target.value)} />
            </div>

            <div className="flex gap-3">
              <button onClick={() => setReviewModal({ open: false, appointmentId: '' })} className="btn-ghost flex-1">
                Cancel
              </button>
              <button onClick={submitReview} disabled={submitting}
                className="btn-primary flex-1 justify-center flex items-center gap-2">
                {submitting && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>}
                Submit Review
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
