'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import AppointmentCard from '@/components/AppointmentCard'
import { appointmentApi, doctorApi } from '@/lib/api'
import { getUser, isLoggedIn } from '@/lib/auth'
import { AppointmentInfo, AvailabilityInfo, User, PagedResult } from '@/types'
import {
  Calendar, Clock, Plus, Trash2, Settings,
  CheckCircle, XCircle, Users, Layers, X
} from 'lucide-react'
import toast from 'react-hot-toast'
import { format, addDays } from 'date-fns'

type Tab = 'appointments' | 'availability' | 'slots'
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']

export default function DoctorDashboard() {
  const router = useRouter()
  const [user, setUser]               = useState<User | null>(null)
  const [tab, setTab]                 = useState<Tab>('appointments')
  const [appointments, setAppts]      = useState<AppointmentInfo[]>([])
  const [availability, setAvailability] = useState<AvailabilityInfo[]>([])
  const [loading, setLoading]         = useState(true)
  const [doctorId, setDoctorId]       = useState<string>('')

  // Availability form
  const [avForm, setAvForm] = useState({
    dayOfWeek: 0, startTime: '09:00', endTime: '17:00', slotDuration: 30
  })
  const [savingAv, setSavingAv] = useState(false)

  // Slot generation form
  const [slotForm, setSlotForm] = useState({
    fromDate: format(new Date(), 'yyyy-MM-dd'),
    toDate:   format(addDays(new Date(), 6), 'yyyy-MM-dd'),
  })
  const [generatingSlots, setGeneratingSlots] = useState(false)

  // Notes modal
  const [notesModal, setNotesModal] = useState<{ open: boolean; id: string }>({ open: false, id: '' })
  const [notes, setNotes]       = useState('')
  const [prescription, setPrescription] = useState('')
  const [diagnosis, setDiagnosis] = useState('')
  const [savingNotes, setSavingNotes] = useState(false)

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (u?.role !== 'DOCTOR') { router.push('/'); return }
    setUser(u)
    fetchData(u)
  }, [])

  const fetchData = async (u: User) => {
    setLoading(true)
    try {
      const appts = await appointmentApi.doctorAppointments(0, 50)
      setAppts((appts.data as PagedResult<AppointmentInfo>).content)
      // Get doctor profile to get doctor id
      const me = await import('@/lib/api').then(m => m.authApi.me())
      // Fetch availability using user id as doctor id — we get from appointments
      const apptList = (appts.data as PagedResult<AppointmentInfo>).content
      if (apptList.length > 0) {
        const did = apptList[0].doctor?.id
        if (did) {
          setDoctorId(did)
          const av = await doctorApi.getAvailability(did)
          setAvailability(av.data)
        }
      }
    } catch {
      toast.error('Failed to load dashboard')
    } finally {
      setLoading(false)
    }
  }

  const handleAction = async (action: string, id: string) => {
    try {
      if (action === 'confirm')   { await appointmentApi.confirm(id);   toast.success('Appointment confirmed') }
      if (action === 'complete')  { await appointmentApi.complete(id);  toast.success('Marked as complete') }
      if (action === 'cancel')    { await appointmentApi.cancel(id);    toast.success('Appointment cancelled') }
      if (action === 'notes')     { setNotesModal({ open: true, id }) }
      const a = await appointmentApi.doctorAppointments(0, 50)
      setAppts((a.data as PagedResult<AppointmentInfo>).content)
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Action failed')
    }
  }

  const saveNotes = async () => {
    setSavingNotes(true)
    try {
      await appointmentApi.updateNotes(notesModal.id, { notes, prescription, diagnosis })
      toast.success('Notes saved!')
      setNotesModal({ open: false, id: '' })
      setNotes(''); setPrescription(''); setDiagnosis('')
    } catch { toast.error('Failed to save notes') }
    finally { setSavingNotes(false) }
  }

  const addAvailability = async () => {
    if (!doctorId) { toast.error('Doctor profile not found'); return }
    setSavingAv(true)
    try {
      await doctorApi.addAvailability(doctorId, {
        ...avForm,
        startTime: avForm.startTime + ':00',
        endTime:   avForm.endTime   + ':00',
      })
      toast.success('Availability added!')
      const av = await doctorApi.getAvailability(doctorId)
      setAvailability(av.data)
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to add availability')
    } finally { setSavingAv(false) }
  }

  const deleteAvailability = async (aid: string) => {
    if (!doctorId) return
    try {
      await doctorApi.deleteAvailability(doctorId, aid)
      toast.success('Availability removed')
      setAvailability(a => a.filter(x => x.id !== aid))
    } catch { toast.error('Failed to delete') }
  }

  const generateSlots = async () => {
    if (!doctorId) { toast.error('Doctor profile not found'); return }
    setGeneratingSlots(true)
    try {
      const res = await doctorApi.generateSlots(doctorId, slotForm)
      toast.success(res.data.message)
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to generate slots')
    } finally { setGeneratingSlots(false) }
  }

  const stats = {
    total:    appointments.length,
    pending:  appointments.filter(a => a.status === 'PENDING').length,
    today:    appointments.filter(a => a.timeSlot?.slotDate === format(new Date(), 'yyyy-MM-dd')).length,
    completed:appointments.filter(a => a.status === 'COMPLETED').length,
  }

  return (
    <>
      <Navbar />
      <main className="pt-20 pb-16 min-h-screen bg-slate-50">
        <div className="page-container">

          {/* Header */}
          <div className="py-6 animate-fade-up">
            <h1 className="section-title">Doctor Dashboard</h1>
            <p className="text-slate-500 text-sm mt-1">Manage your appointments, schedule, and availability</p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {[
              { label: 'Total',     value: stats.total,     icon: <Calendar size={18}/>, color: 'bg-blue-50 text-blue-600' },
              { label: "Today's",   value: stats.today,     icon: <Clock size={18}/>,    color: 'bg-amber-50 text-amber-600' },
              { label: 'Pending',   value: stats.pending,   icon: <Users size={18}/>,    color: 'bg-primary-50 text-primary-600' },
              { label: 'Completed', value: stats.completed, icon: <CheckCircle size={18}/>, color: 'bg-green-50 text-green-600' },
            ].map((s, i) => (
              <div key={i} className={`card p-4 animate-fade-up animate-delay-${i}00`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-400 font-medium">{s.label}</span>
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${s.color}`}>
                    {s.icon}
                  </div>
                </div>
                <p className="text-2xl font-bold text-slate-800">{s.value}</p>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-white rounded-2xl p-1 border border-slate-100 w-fit mb-6 shadow-sm flex-wrap">
            {([
              { id: 'appointments', label: 'Appointments', icon: <Calendar size={14}/> },
              { id: 'availability', label: 'Availability',  icon: <Clock size={14}/> },
              { id: 'slots',        label: 'Generate Slots', icon: <Layers size={14}/> },
            ] as { id: Tab; label: string; icon: React.ReactNode }[]).map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  tab === t.id ? 'bg-primary-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}>
                {t.icon} {t.label}
              </button>
            ))}
          </div>

          {/* ── Appointments Tab ── */}
          {tab === 'appointments' && (
            loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[1,2,3,4].map(i => (
                  <div key={i} className="card p-5 animate-pulse h-40">
                    <div className="flex gap-3">
                      <div className="w-10 h-10 bg-slate-100 rounded-xl"/>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-slate-100 rounded w-3/4"/>
                        <div className="h-3 bg-slate-100 rounded w-1/2"/>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : appointments.length === 0 ? (
              <div className="text-center py-20 card">
                <Calendar size={48} className="text-slate-200 mx-auto mb-4"/>
                <p className="text-slate-400">No appointments yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {appointments.map(a => (
                  <div key={a.id}>
                    <AppointmentCard appointment={a} role="DOCTOR" onAction={handleAction}/>
                    {/* Notes button */}
                    <button
                      onClick={() => { setNotesModal({ open: true, id: a.id }) }}
                      className="w-full mt-1 text-xs text-center text-slate-400 hover:text-primary-600 py-1"
                    >
                      + Add Notes / Prescription
                    </button>
                  </div>
                ))}
              </div>
            )
          )}

          {/* ── Availability Tab ── */}
          {tab === 'availability' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Add Form */}
              <div className="card p-6 animate-fade-up">
                <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Plus size={16} className="text-primary-500"/> Add Weekly Schedule
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="label">Day of Week</label>
                    <select
                      className="input"
                      value={avForm.dayOfWeek}
                      onChange={e => setAvForm(f => ({ ...f, dayOfWeek: +e.target.value }))}
                    >
                      {DAYS.map((d, i) => <option key={i} value={i}>{d}</option>)}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="label">Start Time</label>
                      <input type="time" className="input"
                        value={avForm.startTime}
                        onChange={e => setAvForm(f => ({ ...f, startTime: e.target.value }))}/>
                    </div>
                    <div>
                      <label className="label">End Time</label>
                      <input type="time" className="input"
                        value={avForm.endTime}
                        onChange={e => setAvForm(f => ({ ...f, endTime: e.target.value }))}/>
                    </div>
                  </div>
                  <div>
                    <label className="label">Slot Duration (minutes)</label>
                    <select className="input"
                      value={avForm.slotDuration}
                      onChange={e => setAvForm(f => ({ ...f, slotDuration: +e.target.value }))}>
                      {[15,20,30,45,60].map(d => <option key={d} value={d}>{d} minutes</option>)}
                    </select>
                  </div>
                  <button onClick={addAvailability} disabled={savingAv}
                    className="btn-primary w-full justify-center flex items-center gap-2">
                    {savingAv && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>}
                    Add Schedule
                  </button>
                </div>
              </div>

              {/* Existing */}
              <div className="card p-6 animate-fade-up animate-delay-100">
                <h3 className="font-semibold text-slate-800 mb-4">Current Schedule</h3>
                {availability.length === 0 ? (
                  <p className="text-slate-400 text-sm text-center py-8">No schedule set yet</p>
                ) : (
                  <div className="space-y-3">
                    {availability.map(av => (
                      <div key={av.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                        <div>
                          <p className="font-medium text-slate-700 text-sm">{av.dayName}</p>
                          <p className="text-xs text-slate-400">
                            {av.startTime?.slice(0,5)} – {av.endTime?.slice(0,5)} · {av.slotDuration}min slots
                          </p>
                        </div>
                        <button onClick={() => deleteAvailability(av.id)}
                          className="w-8 h-8 flex items-center justify-center text-red-400 hover:bg-red-50 rounded-xl transition-colors">
                          <Trash2 size={14}/>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── Generate Slots Tab ── */}
          {tab === 'slots' && (
            <div className="max-w-lg animate-fade-up">
              <div className="card p-6">
                <h3 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
                  <Layers size={16} className="text-primary-500"/> Generate Time Slots
                </h3>
                <p className="text-sm text-slate-400 mb-5">
                  Slots will be generated based on your weekly schedule. First set your availability, then generate slots.
                </p>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="label">From Date</label>
                      <input type="date" className="input"
                        value={slotForm.fromDate}
                        min={format(new Date(), 'yyyy-MM-dd')}
                        onChange={e => setSlotForm(f => ({ ...f, fromDate: e.target.value }))}/>
                    </div>
                    <div>
                      <label className="label">To Date</label>
                      <input type="date" className="input"
                        value={slotForm.toDate}
                        min={slotForm.fromDate}
                        onChange={e => setSlotForm(f => ({ ...f, toDate: e.target.value }))}/>
                    </div>
                  </div>

                  <div className="p-4 bg-primary-50 border border-primary-100 rounded-xl text-sm text-primary-700">
                    <p className="font-medium mb-1">ℹ️ How it works</p>
                    <ul className="list-disc list-inside text-xs space-y-1 text-primary-600">
                      <li>Slots are auto-generated from your weekly schedule</li>
                      <li>Already-booked slots are not affected</li>
                      <li>Duplicate slots are skipped automatically</li>
                    </ul>
                  </div>

                  <button onClick={generateSlots} disabled={generatingSlots}
                    className="btn-primary w-full justify-center flex items-center gap-2">
                    {generatingSlots && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>}
                    {generatingSlots ? 'Generating...' : 'Generate Slots'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Notes Modal */}
      {notesModal.open && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6 animate-fade-up">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold text-slate-800">Add Clinical Notes</h3>
              <button onClick={() => setNotesModal({ open: false, id: '' })}><X size={20} className="text-slate-400"/></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="label">Notes</label>
                <textarea className="input resize-none" rows={3}
                  placeholder="Clinical observations..." value={notes} onChange={e => setNotes(e.target.value)}/>
              </div>
              <div>
                <label className="label">Prescription</label>
                <textarea className="input resize-none" rows={3}
                  placeholder="Prescribed medications..." value={prescription} onChange={e => setPrescription(e.target.value)}/>
              </div>
              <div>
                <label className="label">Diagnosis</label>
                <textarea className="input resize-none" rows={2}
                  placeholder="Diagnosis..." value={diagnosis} onChange={e => setDiagnosis(e.target.value)}/>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setNotesModal({ open: false, id: '' })} className="btn-ghost flex-1">Cancel</button>
              <button onClick={saveNotes} disabled={savingNotes}
                className="btn-primary flex-1 justify-center flex items-center gap-2">
                {savingNotes && <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>}
                Save Notes
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
