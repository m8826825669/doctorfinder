'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import { doctorApi } from '@/lib/api'
import { getUser, isLoggedIn } from '@/lib/auth'
import { Specialization } from '@/types'
import { Stethoscope, Save } from 'lucide-react'
import toast from 'react-hot-toast'

export default function DoctorProfileSetup() {
  const router = useRouter()
  const [specs, setSpecs]     = useState<Specialization[]>([])
  const [loading, setLoading] = useState(false)
  const [form, setForm]       = useState({
    specializationId: '',
    bio: '',
    experienceYears: '',
    consultationFee: '',
    qualification: '',
    clinicName: '',
    clinicAddress: '',
    city: '',
    state: '',
    languages: '',
  })

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (u?.role !== 'DOCTOR') { router.push('/'); return }
    doctorApi.getSpecializations().then(r => setSpecs(r.data)).catch(() => {})
  }, [])

  const up = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await doctorApi.createProfile({
        specializationId: form.specializationId ? +form.specializationId : null,
        bio:              form.bio || null,
        experienceYears:  form.experienceYears ? +form.experienceYears : 0,
        consultationFee:  form.consultationFee ? +form.consultationFee : 0,
        qualification:    form.qualification || null,
        clinicName:       form.clinicName || null,
        clinicAddress:    form.clinicAddress || null,
        city:             form.city || null,
        state:            form.state || null,
        languages:        form.languages ? form.languages.split(',').map(l => l.trim()) : [],
      })
      toast.success('Profile created successfully!')
      router.push('/dashboard/doctor')
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Failed to create profile')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Navbar />
      <main className="pt-24 pb-16 min-h-screen bg-slate-50">
        <div className="page-container max-w-2xl">
          <div className="text-center mb-8 animate-fade-up">
            <div className="w-14 h-14 bg-primary-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Stethoscope size={28} className="text-primary-600"/>
            </div>
            <h1 className="section-title">Complete Your Doctor Profile</h1>
            <p className="text-slate-500 text-sm mt-2">
              Set up your profile so patients can find and book you
            </p>
          </div>

          <div className="card p-8 animate-fade-up animate-delay-100">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Specialization</label>
                  <select className="input" value={form.specializationId}
                    onChange={e => up('specializationId', e.target.value)}>
                    <option value="">Select specialization</option>
                    {specs.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Qualification</label>
                  <input className="input" placeholder="MBBS, MD..." value={form.qualification}
                    onChange={e => up('qualification', e.target.value)}/>
                </div>
              </div>

              <div>
                <label className="label">About / Bio</label>
                <textarea className="input resize-none" rows={3}
                  placeholder="Tell patients about yourself, your experience, and approach..."
                  value={form.bio} onChange={e => up('bio', e.target.value)}/>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Experience (years)</label>
                  <input type="number" className="input" min="0" placeholder="10"
                    value={form.experienceYears} onChange={e => up('experienceYears', e.target.value)}/>
                </div>
                <div>
                  <label className="label">Consultation Fee (₹)</label>
                  <input type="number" className="input" min="0" placeholder="500"
                    value={form.consultationFee} onChange={e => up('consultationFee', e.target.value)}/>
                </div>
              </div>

              <div>
                <label className="label">Clinic Name</label>
                <input className="input" placeholder="Apollo Clinic" value={form.clinicName}
                  onChange={e => up('clinicName', e.target.value)}/>
              </div>

              <div>
                <label className="label">Clinic Address</label>
                <input className="input" placeholder="123 MG Road..." value={form.clinicAddress}
                  onChange={e => up('clinicAddress', e.target.value)}/>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">City</label>
                  <input className="input" placeholder="Delhi" value={form.city}
                    onChange={e => up('city', e.target.value)}/>
                </div>
                <div>
                  <label className="label">State</label>
                  <input className="input" placeholder="Delhi" value={form.state}
                    onChange={e => up('state', e.target.value)}/>
                </div>
              </div>

              <div>
                <label className="label">Languages Spoken (comma separated)</label>
                <input className="input" placeholder="Hindi, English, Punjabi"
                  value={form.languages} onChange={e => up('languages', e.target.value)}/>
              </div>

              <button type="submit" disabled={loading}
                className="btn-primary w-full justify-center flex items-center gap-2 mt-2">
                {loading
                  ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>
                  : <Save size={16}/>}
                {loading ? 'Saving...' : 'Save Profile & Continue'}
              </button>
            </form>
          </div>
        </div>
      </main>
    </>
  )
}
