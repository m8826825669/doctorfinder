import type { Metadata } from 'next'
import './globals.css'
import { Toaster } from 'react-hot-toast'

export const metadata: Metadata = {
  title: 'DoctorFinder — Find & Book Doctors Instantly',
  description: 'Search verified doctors, check availability, and book appointments online.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    // suppressHydrationWarning — fixes mismatch caused by browser extensions
    // (e.g. QuickBooks, Grammarly, LastPass) that inject attributes into <html>
    <html lang="en" suppressHydrationWarning>
      <body suppressHydrationWarning>
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              fontFamily: 'Sora, sans-serif',
              fontSize: '14px',
              borderRadius: '12px',
              border: '1px solid #e2e8f0',
            },
            success: { iconTheme: { primary: '#1a9e73', secondary: '#fff' } },
          }}
        />
      </body>
    </html>
  )
}
