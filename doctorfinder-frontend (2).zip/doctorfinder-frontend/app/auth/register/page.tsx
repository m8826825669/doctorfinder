'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Stethoscope, Eye, EyeOff, UserPlus, Shield } from 'lucide-react'
import { authApi } from '@/lib/api'
import { saveAuth, normalizeAuthResponse, getDashboardPath } from '@/lib/auth'
import toast from 'react-hot-toast'

type Role = 'PATIENT' | 'DOCTOR' | 'ADMIN'

// Change this secret code as needed
const ADMIN_SECRET = 'DOCFINDER@ADMIN2025'

export default function RegisterPage() {
  const router = useRouter()
  const [form, setForm] = useState({
    fullName: '', email: '', password: '', phone: '',
    role: 'PATIENT' as Role,
  })
  const [showPw, setShowPw]         = useState(false)
  const [loading, setLoading]       = useState(false)
  const [showAdmin, setShowAdmin]   = useState(false)
  const [adminCode, setAdminCode]   = useState('')
  const [adminUnlocked, setAdminUnlocked] = useState(false)

  const update = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const verifyAdminCode = () => {
    if (adminCode === ADMIN_SECRET) {
      setAdminUnlocked(true)
      update('role', 'ADMIN')
      toast.success('Admin access granted ✅')
    } else {
      toast.error('Invalid admin secret code')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (form.password.length < 6) {
      toast.error('Password must be at least 6 characters')
      return
    }
    if (form.role === 'ADMIN' && !adminUnlocked) {
      toast.error('Admin secret code required')
      return
    }
    setLoading(true)
    try {
      // Only send phone if it has a value — empty string causes FastAPI 422
      const payload = {
        fullName: form.fullName.trim(),
        email:    form.email.trim(),
        password: form.password,
        role:     form.role,
        ...(form.phone.trim() ? { phone: form.phone.trim() } : {}),
      }
      const { data } = await authApi.register(payload)
      const { token, refreshToken, user } = normalizeAuthResponse(data)
      saveAuth(token, refreshToken, user)
      toast.success(`Account created! Welcome ${user.fullName?.split(' ')[0] || 'User'} 🎉`)
      router.push(getDashboardPath(user.role))
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })
        ?.response?.data?.message
      toast.error(msg || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  const roleConfig: { id: Role; label: string; icon: string; desc: string }[] = [
    { id: 'PATIENT', label: 'Patient', icon: '🧑',   desc: 'Book appointments' },
    { id: 'DOCTOR',  label: 'Doctor',  icon: '👨‍⚕️', desc: 'Manage patients' },
    { id: 'ADMIN',   label: 'Admin',   icon: '🛡️',  desc: 'Platform management' },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">

        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2.5">
            <div className="w-12 h-12 bg-primary-600 rounded-2xl flex items-center justify-center shadow-glow">
              <Stethoscope size={24} className="text-white" />
            </div>
            <span className="font-display font-bold text-2xl text-slate-800">
              Doctor<span className="text-primary-600">Finder</span>
            </span>
          </Link>
          <h2 className="mt-6 text-2xl font-bold text-slate-800">Create your account</h2>
          <p className="text-slate-500 text-sm mt-1">Join as Patient, Doctor, or Admin</p>
        </div>

        <div className="card p-8 animate-fade-up">

          {/* Role Selector */}
          <div className="mb-6">
            <p className="label mb-2">Select Account Type</p>
            <div className="grid grid-cols-3 gap-2">
              {roleConfig.map(r => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => {
                    if (r.id === 'ADMIN' && !adminUnlocked) {
                      setShowAdmin(true)
                      return
                    }
                    update('role', r.id)
                  }}
                  className={`flex flex-col items-center gap-1 py-3 px-2 rounded-xl border-2 text-center transition-all ${
                    form.role === r.id
                      ? 'border-primary-500 bg-primary-50 shadow-sm'
                      : 'border-slate-200 hover:border-primary-300 bg-white'
                  }`}
                >
                  <span className="text-xl">{r.icon}</span>
                  <span className={`text-xs font-semibold ${
                    form.role === r.id ? 'text-primary-700' : 'text-slate-600'
                  }`}>{r.label}</span>
                  <span className="text-xs text-slate-400 leading-tight">{r.desc}</span>
                  {r.id === 'ADMIN' && !adminUnlocked && (
                    <span className="text-xs text-amber-500 font-medium">🔒 Locked</span>
                  )}
                  {r.id === 'ADMIN' && adminUnlocked && (
                    <span className="text-xs text-green-500 font-medium">🔓 Unlocked</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Admin Secret Code Panel */}
          {showAdmin && !adminUnlocked && (
            <div className="mb-5 p-4 bg-amber-50 border border-amber-200 rounded-xl animate-fade-up">
              <div className="flex items-center gap-2 mb-2">
                <Shield size={15} className="text-amber-600" />
                <p className="text-sm font-semibold text-amber-800">Admin Access Required</p>
              </div>
              <p className="text-xs text-amber-600 mb-3">
                Enter the admin secret code to unlock admin registration.
              </p>
              <div className="flex gap-2">
                <input
                  type="password"
                  className="input flex-1 text-sm py-2"
                  placeholder="Enter secret code..."
                  value={adminCode}
                  onChange={e => setAdminCode(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && verifyAdminCode()}
                />
                <button
                  type="button"
                  onClick={verifyAdminCode}
                  className="btn-primary py-2 px-4 text-sm"
                >
                  Verify
                </button>
              </div>
              <button
                type="button"
                onClick={() => { setShowAdmin(false); setAdminCode('') }}
                className="text-xs text-slate-400 hover:text-slate-600 mt-2"
              >
                Cancel
              </button>
            </div>
          )}

          {/* Role Badge */}
          {form.role && (
            <div className={`mb-4 px-3 py-2 rounded-xl text-xs font-medium flex items-center gap-2 ${
              form.role === 'ADMIN'  ? 'bg-violet-50 text-violet-700 border border-violet-100' :
              form.role === 'DOCTOR' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
              'bg-primary-50 text-primary-700 border border-primary-100'
            }`}>
              <span>
                {form.role === 'ADMIN' ? '🛡️' : form.role === 'DOCTOR' ? '👨‍⚕️' : '🧑'}
              </span>
              Registering as: <strong>{form.role}</strong>
              {form.role === 'DOCTOR' && (
                <span className="ml-auto text-blue-500">
                  You can set up your profile after registration
                </span>
              )}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Full Name</label>
              <input className="input"
                placeholder={form.role === 'DOCTOR' ? 'Dr. Rahul Sharma' : 'Rahul Sharma'}
                value={form.fullName}
                onChange={e => update('fullName', e.target.value)}
                required />
            </div>

            <div>
              <label className="label">Email Address</label>
              <input type="email" className="input" placeholder="you@example.com"
                value={form.email} onChange={e => update('email', e.target.value)} required />
            </div>

            <div>
              <label className="label">Phone <span className="text-slate-400 font-normal">(optional)</span></label>
              <input className="input" placeholder="+91 98765 43210"
                value={form.phone} onChange={e => update('phone', e.target.value)} />
            </div>

            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  className="input pr-11"
                  placeholder="Min. 6 characters"
                  value={form.password}
                  onChange={e => update('password', e.target.value)}
                  required
                />
                <button type="button" onClick={() => setShowPw(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="btn-primary w-full justify-center flex items-center gap-2 disabled:opacity-60 mt-2">
              {loading
                ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                : <UserPlus size={16} />}
              {loading ? 'Creating account...' : `Create ${form.role} Account`}
            </button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-6">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-primary-600 font-semibold hover:underline">
              Sign in
            </Link>
          </p>
        </div>

        {/* Info box */}
        <div className="mt-4 card p-4 bg-slate-50 border-slate-100 text-xs text-slate-500 space-y-1">
          <p className="font-semibold text-slate-600">Account Types</p>
          <p>🧑 <strong>Patient</strong> — Search doctors, book & manage appointments</p>
          <p>👨‍⚕️ <strong>Doctor</strong> — Manage schedule, appointments & patient notes</p>
          <p>🛡️ <strong>Admin</strong> — Platform oversight, verify & feature doctors</p>
        </div>
      </div>
    </div>
  )
}
