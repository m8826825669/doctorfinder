'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import DoctorCard from '@/components/DoctorCard'
import { adminApi, doctorApi } from '@/lib/api'
import { getUser, isLoggedIn } from '@/lib/auth'
import { AdminStats, DoctorDetail, PagedResult } from '@/types'
import {
  Users, Stethoscope, Calendar, CheckCircle,
  XCircle, Clock, Search, BadgeCheck, Star, RefreshCw
} from 'lucide-react'
import toast from 'react-hot-toast'

type Tab = 'overview' | 'doctors'

export default function AdminPanel() {
  const router = useRouter()
  const [tab, setTab]         = useState<Tab>('overview')
  const [stats, setStats]     = useState<AdminStats | null>(null)
  const [doctors, setDoctors] = useState<DoctorDetail[]>([])
  const [loading, setLoading] = useState(true)
  const [docLoading, setDocLoading] = useState(false)
  const [searchQ, setSearchQ] = useState('')
  const [verifiedOnly, setVerifiedOnly] = useState(false)

  useEffect(() => {
    if (!isLoggedIn()) { router.push('/auth/login'); return }
    const u = getUser()
    if (u?.role !== 'ADMIN') { router.push('/'); return }
    fetchStats()
  }, [])

  const fetchStats = async () => {
    setLoading(true)
    try {
      const r = await adminApi.getStats()
      setStats(r.data)
    } catch { toast.error('Failed to load stats') }
    finally { setLoading(false) }
  }

  const fetchDoctors = async () => {
    setDocLoading(true)
    try {
      const params: Record<string, unknown> = { page: 0, size: 20 }
      if (searchQ) params.q = searchQ
      if (verifiedOnly) params.isVerified = true
      const r = await doctorApi.search(params)
      setDoctors((r.data as PagedResult<DoctorDetail>).content)
    } catch { toast.error('Failed to load doctors') }
    finally { setDocLoading(false) }
  }

  useEffect(() => {
    if (tab === 'doctors') fetchDoctors()
  }, [tab])

  const verifyDoctor = async (id: string) => {
    try {
      await adminApi.verifyDoctor(id)
      toast.success('Doctor verified ✅')
      setDoctors(d => d.map(x => x.id === id ? { ...x, isVerified: true } : x))
    } catch { toast.error('Failed to verify doctor') }
  }

  const featureDoctor = async (id: string, featured: boolean) => {
    try {
      await adminApi.featureDoctor(id, featured)
      toast.success(featured ? 'Doctor featured ⭐' : 'Removed from featured')
      setDoctors(d => d.map(x => x.id === id ? { ...x, isFeatured: featured } : x))
    } catch { toast.error('Failed to update feature status') }
  }

  const statCards = stats ? [
    { label: 'Total Users',         value: stats.totalUsers,          icon: <Users size={20}/>,       color: 'bg-blue-50 text-blue-600',    border: 'border-blue-100' },
    { label: 'Total Doctors',        value: stats.totalDoctors,        icon: <Stethoscope size={20}/>, color: 'bg-primary-50 text-primary-600', border: 'border-primary-100' },
    { label: 'Verified Doctors',     value: stats.verifiedDoctors,     icon: <CheckCircle size={20}/>, color: 'bg-green-50 text-green-600',  border: 'border-green-100' },
    { label: 'Total Patients',       value: stats.totalPatients,       icon: <Users size={20}/>,       color: 'bg-violet-50 text-violet-600', border: 'border-violet-100' },
    { label: 'Total Appointments',   value: stats.totalAppointments,   icon: <Calendar size={20}/>,    color: 'bg-amber-50 text-amber-600',  border: 'border-amber-100' },
    { label: 'Pending',              value: stats.pendingAppointments, icon: <Clock size={20}/>,       color: 'bg-orange-50 text-orange-600', border: 'border-orange-100' },
    { label: 'Completed',            value: stats.completedAppointments, icon: <CheckCircle size={20}/>, color: 'bg-teal-50 text-teal-600', border: 'border-teal-100' },
    { label: 'Cancelled',            value: stats.cancelledAppointments, icon: <XCircle size={20}/>,   color: 'bg-red-50 text-red-500',      border: 'border-red-100' },
  ] : []

  return (
    <>
      <Navbar />
      <main className="pt-20 pb-16 min-h-screen bg-slate-50">
        <div className="page-container">

          {/* Header */}
          <div className="py-6 flex items-center justify-between animate-fade-up">
            <div>
              <h1 className="section-title">Admin Panel</h1>
              <p className="text-slate-500 text-sm mt-1">Platform management and oversight</p>
            </div>
            <button onClick={fetchStats} className="btn-ghost flex items-center gap-2 text-sm">
              <RefreshCw size={14}/> Refresh
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-white rounded-2xl p-1 border border-slate-100 w-fit mb-6 shadow-sm">
            {([
              { id: 'overview', label: 'Overview'     },
              { id: 'doctors',  label: 'Manage Doctors' },
            ] as { id: Tab; label: string }[]).map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`px-6 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  tab === t.id ? 'bg-primary-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* ── Overview Tab ── */}
          {tab === 'overview' && (
            loading ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1,2,3,4,5,6,7,8].map(i => (
                  <div key={i} className="card p-5 animate-pulse h-28">
                    <div className="h-4 bg-slate-100 rounded w-3/4 mb-3"/>
                    <div className="h-8 bg-slate-100 rounded w-1/2"/>
                  </div>
                ))}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  {statCards.map((s, i) => (
                    <div key={i} className={`card p-5 border ${s.border} animate-fade-up animate-delay-${Math.min(i,4)}00`}>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-medium text-slate-400">{s.label}</span>
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${s.color}`}>
                          {s.icon}
                        </div>
                      </div>
                      <p className="text-3xl font-bold text-slate-800">{s.value?.toLocaleString()}</p>
                    </div>
                  ))}
                </div>

                {/* Appointment breakdown chart */}
                {stats && (
                  <div className="card p-6 animate-fade-up">
                    <h3 className="font-semibold text-slate-800 mb-4">Appointment Status Breakdown</h3>
                    <div className="space-y-3">
                      {[
                        { label: 'Pending',   value: stats.pendingAppointments,   total: stats.totalAppointments, color: 'bg-amber-400' },
                        { label: 'Completed', value: stats.completedAppointments, total: stats.totalAppointments, color: 'bg-primary-500' },
                        { label: 'Cancelled', value: stats.cancelledAppointments, total: stats.totalAppointments, color: 'bg-red-400' },
                      ].map(b => {
                        const pct = b.total > 0 ? Math.round((b.value / b.total) * 100) : 0
                        return (
                          <div key={b.label}>
                            <div className="flex justify-between text-sm mb-1">
                              <span className="text-slate-600">{b.label}</span>
                              <span className="font-semibold text-slate-700">{b.value} ({pct}%)</span>
                            </div>
                            <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                              <div className={`h-full ${b.color} rounded-full transition-all duration-500`}
                                style={{ width: `${pct}%` }}/>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </>
            )
          )}

          {/* ── Doctors Tab ── */}
          {tab === 'doctors' && (
            <>
              {/* Filters */}
              <div className="flex gap-3 mb-5 flex-wrap">
                <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 flex-1 max-w-sm">
                  <Search size={14} className="text-slate-400"/>
                  <input
                    className="flex-1 text-sm outline-none text-slate-700 placeholder-slate-400"
                    placeholder="Search doctors..."
                    value={searchQ}
                    onChange={e => setSearchQ(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && fetchDoctors()}
                  />
                </div>
                <label className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 cursor-pointer text-sm text-slate-600">
                  <input type="checkbox" checked={verifiedOnly}
                    onChange={e => setVerifiedOnly(e.target.checked)}
                    className="accent-primary-600"/>
                  Verified only
                </label>
                <button onClick={fetchDoctors} className="btn-primary text-sm py-2">Search</button>
              </div>

              {docLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="card p-5 animate-pulse h-40">
                      <div className="flex gap-4">
                        <div className="w-16 h-16 bg-slate-100 rounded-2xl"/>
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-slate-100 rounded w-3/4"/>
                          <div className="h-3 bg-slate-100 rounded w-1/2"/>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : doctors.length === 0 ? (
                <div className="text-center py-20 card">
                  <Stethoscope size={48} className="text-slate-200 mx-auto mb-4"/>
                  <p className="text-slate-400">No doctors found</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {doctors.map(d => (
                    <div key={d.id} className="space-y-2">
                      <DoctorCard doctor={d}/>
                      {/* Admin Actions */}
                      <div className="flex gap-2 px-1">
                        {!d.isVerified && (
                          <button
                            onClick={() => verifyDoctor(d.id)}
                            className="flex items-center gap-1.5 text-xs px-3 py-1.5 bg-green-50 text-green-700 border border-green-200 rounded-xl hover:bg-green-100 transition-colors font-medium"
                          >
                            <BadgeCheck size={12}/> Verify Doctor
                          </button>
                        )}
                        <button
                          onClick={() => featureDoctor(d.id, !d.isFeatured)}
                          className={`flex items-center gap-1.5 text-xs px-3 py-1.5 border rounded-xl transition-colors font-medium ${
                            d.isFeatured
                              ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                              : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <Star size={12}/> {d.isFeatured ? 'Remove Featured' : 'Mark Featured'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>
    </>
  )
}
