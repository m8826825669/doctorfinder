/**
 * Type definitions matching backend DTO contracts.
 * Keep in sync with com.schoolerp.* DTOs.
 */

/** Standard API envelope from backend (com.schoolerp.common.dto.ApiResponse) */
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: ApiError[];
  timestamp: string;
}

export interface ApiError {
  code: string;
  field?: string;
  message: string;
}

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
}

export interface PageParams {
  page?: number;
  size?: number;
  sort?: string;
  search?: string;
}

// ---- Auth ---------------------------------------------------------------

export interface LoginRequest {
  email: string;
  password: string;
  subdomain?: string;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  user: AuthUser;
  school: School;
}

export interface AuthUser {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  roles: UserRole[];
  schoolId: number;
}

export type UserRole =
  | "SUPER_ADMIN"
  | "SCHOOL_ADMIN"
  | "PRINCIPAL"
  | "TEACHER"
  | "ACCOUNTANT"
  | "PARENT"
  | "STUDENT";

// ---- School / Tenant ----------------------------------------------------

export interface School {
  id: number;
  name: string;
  subdomain: string;
  udiseCode?: string;
  board?: BoardType;
  primaryLanguage?: string;
  city?: string;
  state?: string;
  pinCode?: string;
  email?: string;
  phone?: string;
  gstin?: string;
  status: SchoolStatus;
  createdAt: string;
}

export type BoardType = "CBSE" | "ICSE" | "STATE" | "IB" | "CAMBRIDGE" | "OTHER";
export type SchoolStatus = "TRIAL" | "ACTIVE" | "SUSPENDED" | "INACTIVE";

export interface RegisterSchoolRequest {
  schoolName: string;
  subdomain: string;
  board: BoardType;
  city: string;
  state: string;
  adminFirstName: string;
  adminLastName: string;
  adminEmail: string;
  adminPhone: string;
  password: string;
}

// ---- Students -----------------------------------------------------------

export interface Student {
  id: number;
  admissionNumber: string;
  firstName: string;
  lastName: string;
  fullName: string;
  dateOfBirth: string; // ISO date
  gender: Gender;
  classId: number;
  className: string;
  sectionId: number;
  sectionName: string;
  rollNumber: string;
  email?: string;
  phone?: string;
  bloodGroup?: BloodGroup;
  address?: string;
  city?: string;
  state?: string;
  pinCode?: string;
  fatherName?: string;
  motherName?: string;
  guardianPhone?: string;
  status: StudentStatus;
  admissionDate: string;
  photoUrl?: string;
}

export type Gender = "MALE" | "FEMALE" | "OTHER";
export type BloodGroup =
  | "A_POS" | "A_NEG"
  | "B_POS" | "B_NEG"
  | "AB_POS" | "AB_NEG"
  | "O_POS" | "O_NEG";
export type StudentStatus = "ACTIVE" | "INACTIVE" | "GRADUATED" | "TRANSFERRED" | "DROPPED";

export interface CreateStudentRequest {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: Gender;
  classId: number;
  sectionId: number;
  rollNumber: string;
  email?: string;
  phone?: string;
  bloodGroup?: BloodGroup;
  address?: string;
  fatherName?: string;
  motherName?: string;
  guardianPhone?: string;
}

// ---- Classes & Sections -------------------------------------------------

export interface SchoolClass {
  id: number;
  name: string; // e.g. "Class 10", "Nursery"
  level: number; // e.g. 10
  sections: Section[];
  studentCount: number;
}

export interface Section {
  id: number;
  classId: number;
  name: string; // "A", "B", etc.
  capacity: number;
  studentCount: number;
  classTeacherName?: string;
}

// ---- Attendance ---------------------------------------------------------

export interface AttendanceEntry {
  studentId: number;
  studentName: string;
  rollNumber: string;
  status: AttendanceStatus;
  remarks?: string;
}

export type AttendanceStatus = "PRESENT" | "ABSENT" | "LATE" | "LEAVE" | "HALF_DAY";

export interface AttendanceSession {
  date: string;
  classId: number;
  sectionId: number;
  className: string;
  sectionName: string;
  totalStudents: number;
  present: number;
  absent: number;
  entries: AttendanceEntry[];
}

// ---- Fees ---------------------------------------------------------------

export interface FeeStructure {
  id: number;
  name: string;
  classId?: number;
  className?: string;
  academicYear: string;
  components: FeeComponent[];
  totalAmount: number;
}

export interface FeeComponent {
  name: string;
  amount: number;
  frequency: "MONTHLY" | "QUARTERLY" | "ANNUAL" | "ONE_TIME";
}

export interface Invoice {
  id: number;
  invoiceNumber: string;
  studentId: number;
  studentName: string;
  className: string;
  amount: number;
  paidAmount: number;
  dueDate: string;
  status: InvoiceStatus;
  createdAt: string;
}

export type InvoiceStatus = "PENDING" | "PARTIAL" | "PAID" | "OVERDUE" | "CANCELLED";

// ---- Dashboard ----------------------------------------------------------

export interface DashboardStats {
  totalStudents: number;
  studentsTrend: number; // % vs last month
  attendanceToday: number; // %
  attendanceTrend: number;
  feesPending: number; // ₹
  feesCollected: number; // ₹ this month
  totalTeachers: number;
  upcomingExams: number;
}
