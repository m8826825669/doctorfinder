import type { Metadata } from "next";
import { Inter, Instrument_Serif } from "next/font/google";
import { Toaster } from "sonner";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const instrumentSerif = Instrument_Serif({
  subsets: ["latin"],
  weight: ["400"],
  style: ["normal", "italic"],
  variable: "--font-instrument-serif",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "School ERP",
    template: "%s · School ERP",
  },
  description: "Multi-tenant school management platform for Indian schools",
  icons: { icon: "/favicon.ico" },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${instrumentSerif.variable}`}>
      <body className="min-h-screen bg-stone-50 font-sans text-stone-900 antialiased">
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            classNames: {
              toast:
                "rounded-lg border border-stone-200 bg-white shadow-pop text-sm font-sans",
              title: "text-stone-900 font-medium",
              description: "text-stone-600",
              success: "!border-brand-200 !bg-brand-50",
              error: "!border-red-200 !bg-red-50",
            },
          }}
        />
      </body>
    </html>
  );
}
