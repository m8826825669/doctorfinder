"use client";

import { useEffect, useState } from "react";
import {
  Users,
  CalendarCheck,
  Banknote,
  Wallet,
  GraduationCap,
  ArrowUpRight,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import Link from "next/link";

import { PageHeader } from "@/components/ui/PageHeader";
import { StatsCard } from "@/components/dashboard/StatsCard";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardDescription,
  Avatar,
  Badge,
} from "@/components/ui/Primitives";
import { dashboardApi } from "@/lib/api/dashboard";
import { useAuthStore } from "@/lib/auth/store";
import { formatCurrency, formatNumber, getInitials } from "@/lib/utils/format";
import type { DashboardStats } from "@/types";

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardApi
      .getStats()
      .then(setStats)
      .finally(() => setLoading(false));
  }, []);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
  })();

  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <>
      <PageHeader
        title={`${greeting}, ${user?.firstName ?? "there"}`}
        description={`${today}. Here's what's happening at your school today.`}
      />

      {/* Stats grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          label="Total students"
          value={stats ? formatNumber(stats.totalStudents) : "—"}
          trend={stats?.studentsTrend}
          hint="vs last month"
          icon={Users}
          loading={loading}
          accent="brand"
        />
        <StatsCard
          label="Attendance today"
          value={stats ? `${stats.attendanceToday.toFixed(1)}%` : "—"}
          trend={stats?.attendanceTrend}
          hint="vs avg"
          icon={CalendarCheck}
          loading={loading}
          accent="indigo"
        />
        <StatsCard
          label="Fees collected"
          value={stats ? formatCurrency(stats.feesCollected, { compact: true }) : "—"}
          hint="this month"
          icon={Wallet}
          loading={loading}
          accent="amber"
        />
        <StatsCard
          label="Fees pending"
          value={stats ? formatCurrency(stats.feesPending, { compact: true }) : "—"}
          hint="due"
          icon={Banknote}
          loading={loading}
          accent="rose"
        />
      </div>

      {/* Two-column section */}
      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Recent activity */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent activity</CardTitle>
              <CardDescription>Latest events across your school</CardDescription>
            </div>
            <Link
              href="#"
              className="inline-flex items-center gap-1 text-xs font-medium text-brand-700 hover:text-brand-800"
            >
              View all
              <ArrowUpRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <ul className="divide-y divide-stone-100">
            {RECENT_ACTIVITY.map((a) => (
              <li
                key={a.id}
                className="flex items-start gap-3 px-5 py-4 transition-colors hover:bg-stone-50/50"
              >
                <Avatar initials={getInitials(a.actor)} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-stone-800">
                    <span className="font-medium">{a.actor}</span> {a.verb}{" "}
                    <span className="font-medium text-stone-900">{a.object}</span>
                  </p>
                  <div className="mt-1 flex items-center gap-2 text-xs text-stone-500">
                    <Clock className="h-3 w-3" />
                    {a.time}
                    {a.tag && (
                      <>
                        <span className="text-stone-300">·</span>
                        <Badge tone={a.tone}>{a.tag}</Badge>
                      </>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Card>

        {/* Quick actions + Today */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Today&apos;s schedule</CardTitle>
              <CardDescription>
                {stats?.upcomingExams ?? 0} exams scheduled this week
              </CardDescription>
            </CardHeader>
            <ul className="divide-y divide-stone-100">
              {SCHEDULE.map((s) => (
                <li
                  key={s.id}
                  className="flex items-center gap-3 px-5 py-3 text-sm"
                >
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-brand-50 text-brand-700">
                    <s.icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-stone-800">{s.title}</p>
                    <p className="text-xs text-stone-500">{s.time}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-stone-400" />
                </li>
              ))}
            </ul>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick actions</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-2">
              {QUICK_ACTIONS.map((a) => (
                <Link
                  key={a.label}
                  href={a.href}
                  className="group flex flex-col items-start rounded-md border border-stone-200 bg-white p-3 transition-all hover:border-brand-300 hover:bg-brand-50/40"
                >
                  <a.icon className="h-5 w-5 text-brand-700" />
                  <p className="mt-2 text-xs font-medium text-stone-700 group-hover:text-stone-900">
                    {a.label}
                  </p>
                </Link>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

const RECENT_ACTIVITY: Array<{
  id: number;
  actor: string;
  verb: string;
  object: string;
  time: string;
  tag?: string;
  tone?: "neutral" | "brand" | "success" | "warning" | "danger";
}> = [
  {
    id: 1,
    actor: "Aarav Sharma",
    verb: "submitted assignment for",
    object: "Class 10 Mathematics",
    time: "12 minutes ago",
    tag: "Submitted",
    tone: "success",
  },
  {
    id: 2,
    actor: "Priya Verma",
    verb: "marked attendance for",
    object: "Class 8-A",
    time: "1 hour ago",
    tag: "92% present",
    tone: "brand",
  },
  {
    id: 3,
    actor: "Mr. Khanna",
    verb: "uploaded marks for",
    object: "Mid-Term Science",
    time: "2 hours ago",
  },
  {
    id: 4,
    actor: "Anika Singh",
    verb: "fee invoice generated · ",
    object: "₹12,500",
    time: "3 hours ago",
    tag: "Pending",
    tone: "warning",
  },
  {
    id: 5,
    actor: "Vikram Mehta",
    verb: "registered as parent for",
    object: "Reyansh Mehta",
    time: "Yesterday",
  },
];

const SCHEDULE = [
  {
    id: 1,
    title: "Class 10 Pre-Board Exam",
    time: "9:00 AM · Hall 2",
    icon: GraduationCap,
  },
  {
    id: 2,
    title: "Parent-Teacher Meeting",
    time: "2:00 PM · Auditorium",
    icon: Users,
  },
  {
    id: 3,
    title: "Fee submission deadline",
    time: "5:00 PM · Office",
    icon: AlertCircle,
  },
];

const QUICK_ACTIONS = [
  { label: "Add student", href: "/students/new", icon: Users },
  { label: "Take attendance", href: "/attendance", icon: CheckCircle2 },
  { label: "Generate invoice", href: "/fees", icon: Banknote },
  { label: "Manage classes", href: "/classes", icon: GraduationCap },
];
