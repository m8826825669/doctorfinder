"use client";

import { useState } from "react";
import {
  Plus,
  Receipt,
  Wallet,
  AlertTriangle,
  CheckCircle2,
  Search,
  Download,
  FileText,
} from "lucide-react";

import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  Avatar,
  Badge,
} from "@/components/ui/Primitives";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { formatCurrency, formatDate, getInitials } from "@/lib/utils/format";
import { cn } from "@/lib/utils/cn";
import type { Invoice, InvoiceStatus } from "@/types";

// ---- Mock data (frontend-only until backend module ships) ---------------
const MOCK_INVOICES: Invoice[] = [
  {
    id: 1,
    invoiceNumber: "INV-2026-0142",
    studentId: 12,
    studentName: "Aarav Sharma",
    className: "Class 10 · A",
    amount: 24500,
    paidAmount: 24500,
    dueDate: "2026-04-10",
    status: "PAID",
    createdAt: "2026-04-01",
  },
  {
    id: 2,
    invoiceNumber: "INV-2026-0143",
    studentId: 18,
    studentName: "Saanvi Verma",
    className: "Class 8 · B",
    amount: 22000,
    paidAmount: 0,
    dueDate: "2026-04-30",
    status: "PENDING",
    createdAt: "2026-04-01",
  },
  {
    id: 3,
    invoiceNumber: "INV-2026-0144",
    studentId: 24,
    studentName: "Vihaan Gupta",
    className: "Class 5 · A",
    amount: 18500,
    paidAmount: 10000,
    dueDate: "2026-04-20",
    status: "PARTIAL",
    createdAt: "2026-04-01",
  },
  {
    id: 4,
    invoiceNumber: "INV-2026-0117",
    studentId: 7,
    studentName: "Diya Patel",
    className: "Class 12 · C",
    amount: 28500,
    paidAmount: 0,
    dueDate: "2026-03-15",
    status: "OVERDUE",
    createdAt: "2026-03-01",
  },
  {
    id: 5,
    invoiceNumber: "INV-2026-0145",
    studentId: 31,
    studentName: "Reyansh Mehta",
    className: "Class 2 · A",
    amount: 16000,
    paidAmount: 16000,
    dueDate: "2026-04-12",
    status: "PAID",
    createdAt: "2026-04-01",
  },
  {
    id: 6,
    invoiceNumber: "INV-2026-0146",
    studentId: 42,
    studentName: "Anika Singh",
    className: "Class 10 · B",
    amount: 24500,
    paidAmount: 0,
    dueDate: "2026-04-30",
    status: "PENDING",
    createdAt: "2026-04-01",
  },
];

const STATUS_TONE: Record<InvoiceStatus, "success" | "warning" | "danger" | "neutral" | "info"> = {
  PAID: "success",
  PENDING: "warning",
  PARTIAL: "info",
  OVERDUE: "danger",
  CANCELLED: "neutral",
};

const TABS: Array<{ id: "all" | InvoiceStatus; label: string }> = [
  { id: "all", label: "All" },
  { id: "PENDING", label: "Pending" },
  { id: "PARTIAL", label: "Partial" },
  { id: "OVERDUE", label: "Overdue" },
  { id: "PAID", label: "Paid" },
];

export default function FeesPage() {
  const [tab, setTab] = useState<"all" | InvoiceStatus>("all");
  const [search, setSearch] = useState("");

  const filtered = MOCK_INVOICES.filter((i) => {
    if (tab !== "all" && i.status !== tab) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        i.studentName.toLowerCase().includes(q) ||
        i.invoiceNumber.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Headline numbers
  const totalCollected = MOCK_INVOICES.reduce((s, i) => s + i.paidAmount, 0);
  const totalOutstanding = MOCK_INVOICES.reduce(
    (s, i) => s + (i.amount - i.paidAmount),
    0,
  );
  const overdueCount = MOCK_INVOICES.filter((i) => i.status === "OVERDUE").length;
  const paidCount = MOCK_INVOICES.filter((i) => i.status === "PAID").length;

  const columns: Column<Invoice>[] = [
    {
      key: "invoice",
      header: "Invoice",
      cell: (i) => (
        <div>
          <p className="font-mono text-xs font-medium text-stone-900">
            {i.invoiceNumber}
          </p>
          <p className="text-xs text-stone-500">{formatDate(i.createdAt)}</p>
        </div>
      ),
    },
    {
      key: "student",
      header: "Student",
      cell: (i) => (
        <div className="flex items-center gap-3">
          <Avatar initials={getInitials(i.studentName)} size="sm" />
          <div>
            <p className="font-medium text-stone-900">{i.studentName}</p>
            <p className="text-xs text-stone-500">{i.className}</p>
          </div>
        </div>
      ),
    },
    {
      key: "amount",
      header: "Amount",
      align: "right",
      cell: (i) => (
        <div className="text-right">
          <p className="font-medium tabular-nums text-stone-900">
            {formatCurrency(i.amount)}
          </p>
          {i.paidAmount > 0 && i.paidAmount < i.amount && (
            <p className="text-xs tabular-nums text-emerald-600">
              {formatCurrency(i.paidAmount)} paid
            </p>
          )}
        </div>
      ),
    },
    {
      key: "due",
      header: "Due date",
      cell: (i) => (
        <span
          className={cn(
            "tabular-nums",
            i.status === "OVERDUE" ? "font-medium text-red-600" : "text-stone-700",
          )}
        >
          {formatDate(i.dueDate)}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      cell: (i) => (
        <Badge dot tone={STATUS_TONE[i.status]}>
          {i.status.charAt(0) + i.status.slice(1).toLowerCase()}
        </Badge>
      ),
    },
    {
      key: "actions",
      header: "",
      align: "right",
      cell: () => (
        <button
          type="button"
          className="inline-flex h-8 w-8 items-center justify-center rounded-md text-stone-400 hover:bg-stone-100 hover:text-stone-700"
          aria-label="Download invoice"
        >
          <Download className="h-4 w-4" />
        </button>
      ),
    },
  ];

  return (
    <>
      <PageHeader
        title="Fees"
        description="Track invoices, collections, and outstanding dues across your school."
        actions={
          <>
            <Button variant="outline" leadingIcon={<FileText className="h-4 w-4" />}>
              Fee structures
            </Button>
            <Button leadingIcon={<Plus className="h-4 w-4" />}>
              Generate invoice
            </Button>
          </>
        }
      />

      {/* Headline cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <SummaryCard
          label="Collected this month"
          value={formatCurrency(totalCollected, { compact: true })}
          icon={Wallet}
          tone="bg-emerald-50 text-emerald-700"
          hint={`${paidCount} invoices paid`}
        />
        <SummaryCard
          label="Outstanding"
          value={formatCurrency(totalOutstanding, { compact: true })}
          icon={Receipt}
          tone="bg-amber-50 text-amber-700"
          hint={`${MOCK_INVOICES.length - paidCount} pending`}
        />
        <SummaryCard
          label="Overdue"
          value={String(overdueCount)}
          icon={AlertTriangle}
          tone="bg-red-50 text-red-700"
          hint="Requires follow-up"
        />
        <SummaryCard
          label="Collection rate"
          value={`${Math.round(
            (totalCollected / (totalCollected + totalOutstanding)) * 100,
          )}%`}
          icon={CheckCircle2}
          tone="bg-brand-50 text-brand-700"
          hint="of due amount"
        />
      </div>

      <Card className="overflow-hidden">
        <CardHeader className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle>Invoices</CardTitle>
            <CardDescription>
              {filtered.length} invoice{filtered.length === 1 ? "" : "s"}
            </CardDescription>
          </div>
          <div className="w-full sm:w-72">
            <Input
              placeholder="Search invoices…"
              leadingIcon={<Search className="h-4 w-4" />}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </CardHeader>

        {/* Tabs */}
        <div className="flex gap-1 overflow-x-auto border-b border-stone-200 px-3 pt-2">
          {TABS.map((t) => {
            const count =
              t.id === "all"
                ? MOCK_INVOICES.length
                : MOCK_INVOICES.filter((i) => i.status === t.id).length;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={cn(
                  "relative whitespace-nowrap px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "text-stone-900"
                    : "text-stone-500 hover:text-stone-700",
                )}
              >
                {t.label}
                <span
                  className={cn(
                    "ml-1.5 rounded-full px-1.5 py-0.5 text-xs",
                    active
                      ? "bg-stone-900 text-white"
                      : "bg-stone-100 text-stone-500",
                  )}
                >
                  {count}
                </span>
                {active && (
                  <span className="absolute inset-x-0 bottom-0 h-0.5 bg-brand-600" />
                )}
              </button>
            );
          })}
        </div>

        <DataTable<Invoice>
          columns={columns}
          rows={filtered}
          emptyState={
            <div className="px-4 py-16 text-center text-sm text-stone-500">
              No invoices match the current filter.
            </div>
          }
        />
      </Card>
    </>
  );
}

function SummaryCard({
  label,
  value,
  icon: Icon,
  tone,
  hint,
}: {
  label: string;
  value: string;
  icon: typeof Receipt;
  tone: string;
  hint: string;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-stone-500">
            {label}
          </p>
          <p className="mt-1.5 display text-2xl leading-tight text-stone-900">
            {value}
          </p>
          <p className="mt-1 text-xs text-stone-500">{hint}</p>
        </div>
        <span
          className={cn(
            "flex h-8 w-8 shrink-0 items-center justify-center rounded-md",
            tone,
          )}
        >
          <Icon className="h-4 w-4" />
        </span>
      </div>
    </Card>
  );
}
