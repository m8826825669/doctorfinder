"use client";

import Link from "next/link";
import { Plus, Users, GraduationCap, Settings2 } from "lucide-react";

import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  Badge,
} from "@/components/ui/Primitives";
import { mockClasses } from "@/lib/mock/students";
import { cn } from "@/lib/utils/cn";

const SECTIONS = ["A", "B", "C"];
const CAPACITY = 40;

export default function ClassesPage() {
  // Build a synthetic structure since real backend is pending
  const classData = mockClasses.map((c) => ({
    ...c,
    sections: SECTIONS.map((name, idx) => ({
      id: c.id * 10 + idx,
      name,
      capacity: CAPACITY,
      enrolled: 28 + ((c.id * 7 + idx * 3) % 12),
      classTeacherName: TEACHERS[(c.id + idx) % TEACHERS.length],
    })),
  }));

  return (
    <>
      <PageHeader
        title="Classes & sections"
        description="Manage class structure, sections, and class teacher assignments."
        actions={
          <Button leadingIcon={<Plus className="h-4 w-4" />}>Add class</Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {classData.map((cls) => {
          const total = cls.sections.reduce((sum, s) => sum + s.enrolled, 0);
          const capacity = cls.sections.reduce((sum, s) => sum + s.capacity, 0);
          const fill = Math.round((total / capacity) * 100);

          return (
            <Card key={cls.id} className="overflow-hidden">
              <CardHeader className="flex flex-row items-start justify-between gap-3">
                <div>
                  <CardTitle className="display text-2xl">{cls.name}</CardTitle>
                  <CardDescription className="mt-0.5">
                    Level {cls.level} · {cls.sections.length} sections
                  </CardDescription>
                </div>
                <span className="flex h-10 w-10 items-center justify-center rounded-md bg-brand-50 text-brand-700">
                  <GraduationCap className="h-5 w-5" />
                </span>
              </CardHeader>

              {/* Capacity meter */}
              <div className="px-5 pt-3">
                <div className="flex items-baseline justify-between text-xs">
                  <span className="font-medium text-stone-700">
                    {total}{" "}
                    <span className="font-normal text-stone-500">
                      / {capacity} students
                    </span>
                  </span>
                  <span
                    className={cn(
                      "font-medium",
                      fill > 90
                        ? "text-red-600"
                        : fill > 75
                          ? "text-amber-600"
                          : "text-emerald-600",
                    )}
                  >
                    {fill}% full
                  </span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-stone-100">
                  <div
                    className={cn(
                      "h-full transition-all",
                      fill > 90
                        ? "bg-red-500"
                        : fill > 75
                          ? "bg-amber-500"
                          : "bg-emerald-500",
                    )}
                    style={{ width: `${fill}%` }}
                  />
                </div>
              </div>

              <CardContent className="space-y-2 pt-4">
                {cls.sections.map((s) => (
                  <div
                    key={s.id}
                    className="flex items-center justify-between rounded-md border border-stone-200 bg-stone-50/40 px-3 py-2.5 transition-colors hover:bg-stone-50"
                  >
                    <div>
                      <p className="text-sm font-medium text-stone-800">
                        Section {s.name}
                      </p>
                      <p className="mt-0.5 text-xs text-stone-500">
                        {s.classTeacherName}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge tone="neutral">
                        <Users className="h-3 w-3" />
                        {s.enrolled}/{s.capacity}
                      </Badge>
                      <Link
                        href={`/students?classId=${cls.id}`}
                        className="text-xs font-medium text-brand-700 hover:text-brand-800"
                      >
                        View
                      </Link>
                    </div>
                  </div>
                ))}
              </CardContent>

              <div className="border-t border-stone-100 bg-stone-50/40 px-5 py-2.5">
                <button
                  type="button"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-600 hover:text-stone-800"
                >
                  <Settings2 className="h-3.5 w-3.5" />
                  Configure
                </button>
              </div>
            </Card>
          );
        })}
      </div>
    </>
  );
}

const TEACHERS = [
  "Mrs. Anita Khanna",
  "Mr. Rajesh Kumar",
  "Mrs. Pooja Verma",
  "Mr. Sanjay Iyer",
  "Mrs. Sneha Reddy",
  "Mr. Amit Joshi",
  "Mrs. Kavya Menon",
  "Mr. Vikram Mehta",
];
