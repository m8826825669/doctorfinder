"use client";

import {
  Building2,
  Users,
  Mail,
  CreditCard,
  Shield,
  Bell,
  Globe,
  ChevronRight,
} from "lucide-react";
import Link from "next/link";

import { PageHeader } from "@/components/ui/PageHeader";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  Badge,
} from "@/components/ui/Primitives";
import { Input, Field } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useAuthStore } from "@/lib/auth/store";

const SETTINGS_GROUPS: Array<{
  title: string;
  items: Array<{
    icon: typeof Building2;
    label: string;
    description: string;
    href: string;
    badge?: string;
  }>;
}> = [
  {
    title: "School",
    items: [
      {
        icon: Building2,
        label: "School profile",
        description: "Name, address, board, UDISE+ code, GSTIN",
        href: "#school-profile",
      },
      {
        icon: Globe,
        label: "Academic year",
        description: "Configure terms, working days, holidays",
        href: "#academic-year",
        badge: "2026-27",
      },
    ],
  },
  {
    title: "Team",
    items: [
      {
        icon: Users,
        label: "Users & roles",
        description: "Invite teachers, admins, and accountants",
        href: "#users",
      },
      {
        icon: Shield,
        label: "Permissions",
        description: "Customise role-based access",
        href: "#permissions",
      },
    ],
  },
  {
    title: "Communication",
    items: [
      {
        icon: Bell,
        label: "Notifications",
        description: "Email, SMS, WhatsApp templates and triggers",
        href: "#notifications",
      },
      {
        icon: Mail,
        label: "Email & SMS providers",
        description: "Configure MSG91, WATI, SES",
        href: "#providers",
      },
    ],
  },
  {
    title: "Billing",
    items: [
      {
        icon: CreditCard,
        label: "Subscription",
        description: "Plan, payment methods, invoices",
        href: "#subscription",
      },
    ],
  },
];

export default function SettingsPage() {
  const school = useAuthStore((s) => s.school);

  return (
    <>
      <PageHeader
        title="Settings"
        description="Manage your school's configuration, users, and integrations."
      />

      {/* School quick edit */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>School profile</CardTitle>
          <CardDescription>
            Quick access to the most-edited fields. Full editor coming soon.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="School name">
            <Input defaultValue={school?.name ?? ""} disabled />
          </Field>
          <Field label="Subdomain">
            <Input
              defaultValue={school?.subdomain ?? ""}
              disabled
              trailingAddon={<span className="font-mono">.schoolerp.in</span>}
            />
          </Field>
          <Field label="Board">
            <Input defaultValue={school?.board ?? ""} disabled />
          </Field>
          <Field label="UDISE+ code">
            <Input defaultValue={school?.udiseCode ?? ""} disabled />
          </Field>
          <Field label="City">
            <Input defaultValue={school?.city ?? ""} disabled />
          </Field>
          <Field label="State">
            <Input defaultValue={school?.state ?? ""} disabled />
          </Field>
        </CardContent>
        <div className="border-t border-stone-200 bg-stone-50/40 px-5 py-3">
          <Button variant="outline" disabled>
            Edit profile
          </Button>
          <span className="ml-3 text-xs text-stone-500">
            Editing will be available once the school management endpoints are wired.
          </span>
        </div>
      </Card>

      {/* Grouped settings list */}
      <div className="space-y-6">
        {SETTINGS_GROUPS.map((group) => (
          <div key={group.title}>
            <h3 className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-stone-500">
              {group.title}
            </h3>
            <Card className="divide-y divide-stone-100">
              {group.items.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className="flex items-center gap-4 px-5 py-4 transition-colors hover:bg-stone-50/40"
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-stone-100 text-stone-600">
                    <item.icon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-stone-900">
                        {item.label}
                      </p>
                      {item.badge && <Badge tone="brand">{item.badge}</Badge>}
                    </div>
                    <p className="mt-0.5 text-xs text-stone-500">
                      {item.description}
                    </p>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-stone-400" />
                </Link>
              ))}
            </Card>
          </div>
        ))}
      </div>
    </>
  );
}
