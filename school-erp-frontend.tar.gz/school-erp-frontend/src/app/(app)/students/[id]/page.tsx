"use client";

import { useEffect, useState, use } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Calendar,
  User,
  Heart,
  Edit2,
  Trash2,
  CalendarCheck,
  Receipt,
  GraduationCap,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Avatar,
  Badge,
  Skeleton,
} from "@/components/ui/Primitives";
import { studentsApi } from "@/lib/api/students";
import { extractErrorMessage } from "@/lib/api/client";
import {
  calculateAge,
  formatBloodGroup,
  formatDate,
  formatPhone,
  getInitials,
  humanizeEnum,
} from "@/lib/utils/format";
import { cn } from "@/lib/utils/cn";
import type { Student } from "@/types";

export default function StudentDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const router = useRouter();
  const [student, setStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"profile" | "attendance" | "fees" | "academics">("profile");

  useEffect(() => {
    studentsApi
      .getById(Number(id))
      .then(setStudent)
      .catch((err) => {
        toast.error(extractErrorMessage(err));
        router.push("/students");
      })
      .finally(() => setLoading(false));
  }, [id, router]);

  const handleDelete = async () => {
    if (!student) return;
    if (!confirm(`Remove ${student.fullName}? This action cannot be undone.`)) return;
    try {
      await studentsApi.delete(student.id);
      toast.success("Student removed");
      router.push("/students");
    } catch (err) {
      toast.error(extractErrorMessage(err));
    }
  };

  if (loading || !student) {
    return (
      <>
        <Skeleton className="mb-6 h-9 w-64" />
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-64 lg:col-span-1" />
          <Skeleton className="h-64 lg:col-span-2" />
        </div>
      </>
    );
  }

  const tabs = [
    { id: "profile" as const, label: "Profile", icon: User },
    { id: "attendance" as const, label: "Attendance", icon: CalendarCheck },
    { id: "fees" as const, label: "Fees", icon: Receipt },
    { id: "academics" as const, label: "Academics", icon: GraduationCap },
  ];

  return (
    <>
      <PageHeader
        title={student.fullName}
        description={`${student.className} · Section ${student.sectionName} · Roll #${student.rollNumber}`}
        breadcrumbs={
          <Link
            href="/students"
            className="inline-flex items-center gap-1.5 hover:text-stone-700"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Students
          </Link>
        }
        actions={
          <>
            <Button variant="outline" leadingIcon={<Edit2 className="h-4 w-4" />}>
              Edit
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={handleDelete}
              className="text-red-600 hover:bg-red-50 hover:text-red-700"
              aria-label="Delete student"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Sidebar card */}
        <Card className="lg:col-span-1">
          <CardContent className="text-center">
            <Avatar
              initials={getInitials(student.fullName)}
              size="lg"
              className="mx-auto h-20 w-20 text-xl"
            />
            <h2 className="mt-4 display text-2xl text-stone-900">
              {student.fullName}
            </h2>
            <p className="mt-0.5 font-mono text-xs text-stone-500">
              {student.admissionNumber}
            </p>
            <div className="mt-3 flex justify-center">
              <Badge
                dot
                tone={student.status === "ACTIVE" ? "success" : "neutral"}
              >
                {humanizeEnum(student.status)}
              </Badge>
            </div>
          </CardContent>

          <div className="border-t border-stone-100">
            <dl className="divide-y divide-stone-100">
              <DetailRow
                icon={<User className="h-4 w-4" />}
                label="Age"
                value={`${calculateAge(student.dateOfBirth)} years`}
              />
              <DetailRow
                icon={<Calendar className="h-4 w-4" />}
                label="Born"
                value={formatDate(student.dateOfBirth)}
              />
              <DetailRow
                icon={<User className="h-4 w-4" />}
                label="Gender"
                value={humanizeEnum(student.gender)}
              />
              {student.bloodGroup && (
                <DetailRow
                  icon={<Heart className="h-4 w-4" />}
                  label="Blood group"
                  value={formatBloodGroup(student.bloodGroup)}
                />
              )}
              <DetailRow
                icon={<Calendar className="h-4 w-4" />}
                label="Admitted"
                value={formatDate(student.admissionDate)}
              />
            </dl>
          </div>
        </Card>

        {/* Main content */}
        <div className="lg:col-span-2">
          {/* Tabs */}
          <div className="mb-4 flex gap-1 rounded-lg border border-stone-200 bg-white p-1 shadow-card">
            {tabs.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTab(t.id)}
                className={cn(
                  "flex flex-1 items-center justify-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  activeTab === t.id
                    ? "bg-stone-100 text-stone-900"
                    : "text-stone-500 hover:text-stone-700",
                )}
              >
                <t.icon className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{t.label}</span>
              </button>
            ))}
          </div>

          {activeTab === "profile" && (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Contact</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <ContactItem
                    icon={<Phone className="h-4 w-4" />}
                    label="Student phone"
                    value={student.phone ? formatPhone(student.phone) : "—"}
                  />
                  <ContactItem
                    icon={<Mail className="h-4 w-4" />}
                    label="Student email"
                    value={student.email ?? "—"}
                  />
                  <ContactItem
                    icon={<MapPin className="h-4 w-4" />}
                    label="Address"
                    value={
                      student.address
                        ? `${student.address}${student.pinCode ? ` · ${student.pinCode}` : ""}`
                        : "—"
                    }
                    span
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Family</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <ContactItem
                    icon={<User className="h-4 w-4" />}
                    label="Father"
                    value={student.fatherName ?? "—"}
                  />
                  <ContactItem
                    icon={<User className="h-4 w-4" />}
                    label="Mother"
                    value={student.motherName ?? "—"}
                  />
                  <ContactItem
                    icon={<Phone className="h-4 w-4" />}
                    label="Guardian phone"
                    value={
                      student.guardianPhone
                        ? formatPhone(student.guardianPhone)
                        : "—"
                    }
                  />
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab !== "profile" && (
            <Card>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <p className="text-sm font-medium text-stone-700">
                    {tabs.find((t) => t.id === activeTab)?.label} module
                  </p>
                  <p className="mt-1 text-xs text-stone-500">
                    Coming in the next backend phase. The UI is ready — wires up to{" "}
                    <code className="rounded bg-stone-100 px-1.5 py-0.5 font-mono text-[11px]">
                      /api/v1/students/{student.id}/{activeTab}
                    </code>
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}

function DetailRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 px-5 py-3 text-sm">
      <dt className="flex items-center gap-2 text-stone-500">
        <span className="text-stone-400">{icon}</span>
        {label}
      </dt>
      <dd className="font-medium text-stone-900">{value}</dd>
    </div>
  );
}

function ContactItem({
  icon,
  label,
  value,
  span,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  span?: boolean;
}) {
  return (
    <div className={cn(span && "sm:col-span-2")}>
      <p className="flex items-center gap-1.5 text-xs font-medium text-stone-500">
        <span className="text-stone-400">{icon}</span>
        {label}
      </p>
      <p className="mt-1 text-sm text-stone-900">{value}</p>
    </div>
  );
}
