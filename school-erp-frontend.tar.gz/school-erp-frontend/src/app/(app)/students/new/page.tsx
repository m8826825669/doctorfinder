"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Input, Field, Label } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { Card, CardContent } from "@/components/ui/Primitives";
import { studentsApi } from "@/lib/api/students";
import { mockClasses } from "@/lib/mock/students";
import { studentSchema, type StudentInput } from "@/lib/utils/validators";
import { extractErrorMessage } from "@/lib/api/client";

const GENDERS = [
  { value: "MALE", label: "Male" },
  { value: "FEMALE", label: "Female" },
  { value: "OTHER", label: "Other" },
];

const BLOOD_GROUPS = [
  { value: "A_POS", label: "A+" },
  { value: "A_NEG", label: "A−" },
  { value: "B_POS", label: "B+" },
  { value: "B_NEG", label: "B−" },
  { value: "AB_POS", label: "AB+" },
  { value: "AB_NEG", label: "AB−" },
  { value: "O_POS", label: "O+" },
  { value: "O_NEG", label: "O−" },
];

export default function NewStudentPage() {
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<StudentInput>({
    resolver: zodResolver(studentSchema),
  });

  const onSubmit = async (values: StudentInput) => {
    try {
      const created = await studentsApi.create({
        ...values,
        email: values.email || undefined,
        phone: values.phone || undefined,
        guardianPhone: values.guardianPhone || undefined,
      });
      toast.success(`${created.fullName} added successfully`);
      router.push(`/students/${created.id}`);
    } catch (err) {
      toast.error(extractErrorMessage(err));
    }
  };

  const classOptions = [
    ...mockClasses.map((c) => ({ value: c.id, label: c.name })),
  ];

  const sectionOptions = [
    { value: 1, label: "Section A" },
    { value: 2, label: "Section B" },
    { value: 3, label: "Section C" },
  ];

  return (
    <>
      <PageHeader
        title="New student"
        description="Admit a student into your school. Required fields are marked with *"
        breadcrumbs={
          <Link
            href="/students"
            className="inline-flex items-center gap-1.5 hover:text-stone-700"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Students
          </Link>
        }
      />

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Personal */}
        <Card>
          <div className="border-b border-stone-200 px-5 pt-5 pb-4">
            <h3 className="text-sm font-semibold text-stone-900">
              Personal information
            </h3>
            <p className="mt-0.5 text-xs text-stone-500">
              Basic identification details for the student.
            </p>
          </div>
          <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="First name" required error={errors.firstName?.message}>
              <Input placeholder="Aarav" {...register("firstName")} error={errors.firstName?.message} />
            </Field>
            <Field label="Last name" required error={errors.lastName?.message}>
              <Input placeholder="Sharma" {...register("lastName")} error={errors.lastName?.message} />
            </Field>
            <Field label="Date of birth" required error={errors.dateOfBirth?.message}>
              <Input type="date" {...register("dateOfBirth")} error={errors.dateOfBirth?.message} />
            </Field>
            <Field label="Gender" required error={errors.gender?.message}>
              <Select
                placeholder="Select gender"
                options={GENDERS}
                defaultValue=""
                {...register("gender")}
                error={errors.gender?.message}
              />
            </Field>
            <Field label="Blood group" error={errors.bloodGroup?.message}>
              <Select
                placeholder="Optional"
                options={BLOOD_GROUPS}
                defaultValue=""
                {...register("bloodGroup")}
                error={errors.bloodGroup?.message}
              />
            </Field>
          </CardContent>
        </Card>

        {/* Academic */}
        <Card>
          <div className="border-b border-stone-200 px-5 pt-5 pb-4">
            <h3 className="text-sm font-semibold text-stone-900">Academic</h3>
            <p className="mt-0.5 text-xs text-stone-500">
              Class assignment for the current academic year.
            </p>
          </div>
          <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Field label="Class" required error={errors.classId?.message}>
              <Select
                placeholder="Select class"
                options={classOptions}
                defaultValue=""
                {...register("classId")}
                error={errors.classId?.message}
              />
            </Field>
            <Field label="Section" required error={errors.sectionId?.message}>
              <Select
                placeholder="Select section"
                options={sectionOptions}
                defaultValue=""
                {...register("sectionId")}
                error={errors.sectionId?.message}
              />
            </Field>
            <Field label="Roll number" required error={errors.rollNumber?.message}>
              <Input placeholder="e.g. 23" {...register("rollNumber")} error={errors.rollNumber?.message} />
            </Field>
          </CardContent>
        </Card>

        {/* Contact */}
        <Card>
          <div className="border-b border-stone-200 px-5 pt-5 pb-4">
            <h3 className="text-sm font-semibold text-stone-900">
              Contact & guardian
            </h3>
            <p className="mt-0.5 text-xs text-stone-500">
              Optional but recommended — used for fee reminders, attendance alerts, and emergency contact.
            </p>
          </div>
          <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Father's name" error={errors.fatherName?.message}>
              <Input placeholder="Rajesh Sharma" {...register("fatherName")} error={errors.fatherName?.message} />
            </Field>
            <Field label="Mother's name" error={errors.motherName?.message}>
              <Input placeholder="Sunita Sharma" {...register("motherName")} error={errors.motherName?.message} />
            </Field>
            <Field label="Guardian mobile" error={errors.guardianPhone?.message}>
              <Input
                inputMode="numeric"
                placeholder="9876543210"
                {...register("guardianPhone")}
                error={errors.guardianPhone?.message}
              />
            </Field>
            <Field label="Student email" error={errors.email?.message}>
              <Input
                type="email"
                placeholder="aarav@school.edu.in"
                {...register("email")}
                error={errors.email?.message}
              />
            </Field>
            <Field label="Student phone" error={errors.phone?.message}>
              <Input
                inputMode="numeric"
                placeholder="Optional"
                {...register("phone")}
                error={errors.phone?.message}
              />
            </Field>
            <div className="sm:col-span-2">
              <Label>Address</Label>
              <textarea
                rows={2}
                placeholder="Street, locality, city, PIN"
                className="block w-full rounded-md border border-stone-300 bg-white px-3 py-2 text-sm placeholder:text-stone-400 focus-visible:border-brand-600 focus-visible:ring-brand-600"
                {...register("address")}
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex items-center justify-end gap-2 pt-2">
          <Link href="/students">
            <Button type="button" variant="outline">
              Cancel
            </Button>
          </Link>
          <Button
            type="submit"
            loading={isSubmitting}
            leadingIcon={<Save className="h-4 w-4" />}
          >
            Save student
          </Button>
        </div>
      </form>
    </>
  );
}
