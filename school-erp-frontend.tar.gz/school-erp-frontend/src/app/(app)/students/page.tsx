"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Plus, Search, Users, Filter, Download } from "lucide-react";

import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import {
  Avatar,
  Badge,
  EmptyState,
} from "@/components/ui/Primitives";
import { DataTable, type Column, Pagination } from "@/components/ui/DataTable";
import { studentsApi, type StudentFilters } from "@/lib/api/students";
import { mockClasses } from "@/lib/mock/students";
import { formatPhone, getInitials, humanizeEnum } from "@/lib/utils/format";
import type { PageResponse, Student } from "@/types";

const PAGE_SIZE = 20;

export default function StudentsPage() {
  const router = useRouter();
  const [data, setData] = useState<PageResponse<Student> | null>(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<StudentFilters>({
    page: 0,
    size: PAGE_SIZE,
  });
  const [search, setSearch] = useState("");

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => {
      setFilters((f) => ({ ...f, search: search || undefined, page: 0 }));
    }, 300);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    setLoading(true);
    studentsApi
      .list(filters)
      .then(setData)
      .finally(() => setLoading(false));
  }, [filters]);

  const columns: Column<Student>[] = [
    {
      key: "student",
      header: "Student",
      cell: (s) => (
        <div className="flex items-center gap-3">
          <Avatar initials={getInitials(s.fullName)} size="sm" />
          <div>
            <p className="font-medium text-stone-900">{s.fullName}</p>
            <p className="font-mono text-xs text-stone-500">{s.admissionNumber}</p>
          </div>
        </div>
      ),
    },
    {
      key: "class",
      header: "Class · Section",
      cell: (s) => (
        <div>
          <p className="font-medium text-stone-800">{s.className}</p>
          <p className="text-xs text-stone-500">
            Section {s.sectionName} · Roll #{s.rollNumber}
          </p>
        </div>
      ),
    },
    {
      key: "guardian",
      header: "Guardian",
      cell: (s) => (
        <div>
          <p className="text-stone-800">{s.fatherName ?? "—"}</p>
          {s.guardianPhone && (
            <p className="font-mono text-xs text-stone-500">
              {formatPhone(s.guardianPhone)}
            </p>
          )}
        </div>
      ),
    },
    {
      key: "gender",
      header: "Gender",
      cell: (s) => (
        <span className="text-stone-700">{humanizeEnum(s.gender)}</span>
      ),
    },
    {
      key: "status",
      header: "Status",
      cell: (s) => (
        <Badge
          dot
          tone={
            s.status === "ACTIVE"
              ? "success"
              : s.status === "INACTIVE"
                ? "neutral"
                : "warning"
          }
        >
          {humanizeEnum(s.status)}
        </Badge>
      ),
    },
  ];

  const classOptions = [
    { value: "", label: "All classes" },
    ...mockClasses.map((c) => ({ value: c.id, label: c.name })),
  ];

  const statusOptions = [
    { value: "", label: "All statuses" },
    { value: "ACTIVE", label: "Active" },
    { value: "INACTIVE", label: "Inactive" },
    { value: "GRADUATED", label: "Graduated" },
    { value: "TRANSFERRED", label: "Transferred" },
  ];

  return (
    <>
      <PageHeader
        title="Students"
        description={
          data
            ? `${data.totalElements} student${data.totalElements === 1 ? "" : "s"} across all classes`
            : "Manage your student database"
        }
        actions={
          <>
            <Button variant="outline" leadingIcon={<Download className="h-4 w-4" />}>
              Export
            </Button>
            <Link href="/students/new">
              <Button leadingIcon={<Plus className="h-4 w-4" />}>Add student</Button>
            </Link>
          </>
        }
      />

      {/* Filter bar */}
      <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center">
        <div className="flex-1">
          <Input
            placeholder="Search by name, admission number, roll #…"
            leadingIcon={<Search className="h-4 w-4" />}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select
            className="w-40"
            options={classOptions}
            value={filters.classId ?? ""}
            onChange={(e) =>
              setFilters((f) => ({
                ...f,
                classId: e.target.value ? Number(e.target.value) : undefined,
                page: 0,
              }))
            }
          />
          <Select
            className="w-40"
            options={statusOptions}
            value={filters.status ?? ""}
            onChange={(e) =>
              setFilters((f) => ({
                ...f,
                status: e.target.value || undefined,
                page: 0,
              }))
            }
          />
          <Button
            variant="outline"
            size="icon"
            aria-label="More filters"
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <DataTable
        columns={columns}
        rows={data?.content ?? []}
        loading={loading}
        onRowClick={(s) => router.push(`/students/${s.id}`)}
        emptyState={
          <EmptyState
            icon={<Users className="h-5 w-5" />}
            title="No students found"
            description={
              search
                ? `No matches for "${search}". Try a different query.`
                : "Get started by adding your first student."
            }
            action={
              !search && (
                <Link href="/students/new">
                  <Button leadingIcon={<Plus className="h-4 w-4" />}>
                    Add student
                  </Button>
                </Link>
              )
            }
          />
        }
      />

      {data && data.totalPages > 1 && (
        <div className="mt-3 overflow-hidden rounded-lg border border-stone-200 bg-white">
          <Pagination
            page={data.page}
            totalPages={data.totalPages}
            totalElements={data.totalElements}
            pageSize={data.size}
            onPageChange={(p) => setFilters((f) => ({ ...f, page: p }))}
          />
        </div>
      )}
    </>
  );
}
