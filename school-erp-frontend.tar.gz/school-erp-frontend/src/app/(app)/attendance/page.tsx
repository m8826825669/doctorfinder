"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Check,
  X,
  Clock,
  Plane,
  Save,
  Calendar as CalendarIcon,
  Users,
  TrendingUp,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/Button";
import { Select } from "@/components/ui/Select";
import {
  Card,
  CardContent,
  Avatar,
  Skeleton,
  EmptyState,
} from "@/components/ui/Primitives";
import { studentsApi } from "@/lib/api/students";
import { mockClasses } from "@/lib/mock/students";
import { cn } from "@/lib/utils/cn";
import { getInitials } from "@/lib/utils/format";
import type { AttendanceStatus, Student } from "@/types";

const STATUS_CONFIG: Array<{
  value: AttendanceStatus;
  label: string;
  icon: typeof Check;
  classes: string;
}> = [
  {
    value: "PRESENT",
    label: "Present",
    icon: Check,
    classes: "bg-emerald-50 text-emerald-700 ring-emerald-300 hover:bg-emerald-100",
  },
  {
    value: "ABSENT",
    label: "Absent",
    icon: X,
    classes: "bg-red-50 text-red-700 ring-red-300 hover:bg-red-100",
  },
  {
    value: "LATE",
    label: "Late",
    icon: Clock,
    classes: "bg-amber-50 text-amber-700 ring-amber-300 hover:bg-amber-100",
  },
  {
    value: "LEAVE",
    label: "On leave",
    icon: Plane,
    classes: "bg-sky-50 text-sky-700 ring-sky-300 hover:bg-sky-100",
  },
];

export default function AttendancePage() {
  const today = new Date().toISOString().slice(0, 10);
  const [classId, setClassId] = useState<number>(mockClasses[0].id);
  const [section, setSection] = useState<string>("A");
  const [date, setDate] = useState<string>(today);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [statuses, setStatuses] = useState<Record<number, AttendanceStatus>>({});
  const [saving, setSaving] = useState(false);

  // Load students for selected class
  useEffect(() => {
    setLoading(true);
    studentsApi
      .list({ classId, size: 100 })
      .then((res) => {
        const inSection = res.content.filter((s) => s.sectionName === section);
        setStudents(inSection);
        // Default everyone to PRESENT — fastest workflow
        const defaults: Record<number, AttendanceStatus> = {};
        inSection.forEach((s) => (defaults[s.id] = "PRESENT"));
        setStatuses(defaults);
      })
      .finally(() => setLoading(false));
  }, [classId, section]);

  const stats = useMemo(() => {
    const counts: Record<AttendanceStatus, number> = {
      PRESENT: 0,
      ABSENT: 0,
      LATE: 0,
      LEAVE: 0,
      HALF_DAY: 0,
    };
    Object.values(statuses).forEach((s) => (counts[s] = (counts[s] ?? 0) + 1));
    const total = students.length;
    const presentRate = total ? Math.round(((counts.PRESENT + counts.LATE) / total) * 100) : 0;
    return { ...counts, total, presentRate };
  }, [statuses, students.length]);

  const setStatus = (studentId: number, status: AttendanceStatus) => {
    setStatuses((s) => ({ ...s, [studentId]: status }));
  };

  const markAll = (status: AttendanceStatus) => {
    const next: Record<number, AttendanceStatus> = {};
    students.forEach((s) => (next[s.id] = status));
    setStatuses(next);
  };

  const handleSubmit = async () => {
    setSaving(true);
    // Mock save — real wire up: POST /api/v1/attendance with { classId, sectionId, date, entries }
    await new Promise((r) => setTimeout(r, 800));
    setSaving(false);
    toast.success(
      `Attendance saved · ${stats.PRESENT + stats.LATE} present, ${stats.ABSENT} absent`,
    );
  };

  const classOptions = mockClasses.map((c) => ({ value: c.id, label: c.name }));
  const sectionOptions = [
    { value: "A", label: "Section A" },
    { value: "B", label: "Section B" },
    { value: "C", label: "Section C" },
  ];

  return (
    <>
      <PageHeader
        title="Attendance"
        description="Mark and track daily student attendance, section by section."
      />

      {/* Filter bar */}
      <Card className="mb-4">
        <div className="flex flex-col gap-3 p-4 lg:flex-row lg:items-center">
          <div className="flex flex-1 flex-col gap-3 sm:flex-row">
            <div className="flex-1">
              <label className="mb-1 block text-[10px] font-semibold uppercase tracking-wider text-stone-500">
                Class
              </label>
              <Select
                options={classOptions}
                value={classId}
                onChange={(e) => setClassId(Number(e.target.value))}
              />
            </div>
            <div className="flex-1">
              <label className="mb-1 block text-[10px] font-semibold uppercase tracking-wider text-stone-500">
                Section
              </label>
              <Select
                options={sectionOptions}
                value={section}
                onChange={(e) => setSection(e.target.value)}
              />
            </div>
            <div className="flex-1">
              <label className="mb-1 block text-[10px] font-semibold uppercase tracking-wider text-stone-500">
                Date
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={date}
                  max={today}
                  onChange={(e) => setDate(e.target.value)}
                  className="block h-10 w-full rounded-md border border-stone-300 bg-white px-3 text-sm focus-visible:border-brand-600 focus-visible:ring-brand-600"
                />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats strip */}
      {!loading && students.length > 0 && (
        <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
          <StatChip
            label="Total"
            value={stats.total}
            icon={Users}
            tone="bg-stone-100 text-stone-700"
          />
          <StatChip
            label="Present"
            value={stats.PRESENT}
            icon={Check}
            tone="bg-emerald-50 text-emerald-700"
          />
          <StatChip
            label="Absent"
            value={stats.ABSENT}
            icon={X}
            tone="bg-red-50 text-red-700"
          />
          <StatChip
            label="Late"
            value={stats.LATE}
            icon={Clock}
            tone="bg-amber-50 text-amber-700"
          />
          <StatChip
            label="Rate"
            value={`${stats.presentRate}%`}
            icon={TrendingUp}
            tone="bg-brand-50 text-brand-700"
          />
        </div>
      )}

      {/* Quick actions */}
      {!loading && students.length > 0 && (
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-stone-500">Mark all:</span>
          {STATUS_CONFIG.map((s) => (
            <button
              key={s.value}
              type="button"
              onClick={() => markAll(s.value)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ring-1 transition-colors",
                s.classes,
              )}
            >
              <s.icon className="h-3 w-3" />
              {s.label}
            </button>
          ))}
        </div>
      )}

      {/* Student list */}
      {loading ? (
        <Card>
          <div className="space-y-px">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="flex items-center gap-3 border-b border-stone-100 px-4 py-3 last:border-0"
              >
                <Skeleton className="h-9 w-9 rounded-full" />
                <Skeleton className="h-5 w-48" />
                <div className="flex-1" />
                <Skeleton className="h-8 w-72" />
              </div>
            ))}
          </div>
        </Card>
      ) : students.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Users className="h-5 w-5" />}
            title={`No students in ${mockClasses.find((c) => c.id === classId)?.name} · Section ${section}`}
            description="Try a different class or section."
          />
        </Card>
      ) : (
        <Card>
          <ul className="divide-y divide-stone-100">
            {students.map((student) => {
              const current = statuses[student.id];
              return (
                <li
                  key={student.id}
                  className="flex flex-col gap-3 px-4 py-3 transition-colors hover:bg-stone-50/40 sm:flex-row sm:items-center"
                >
                  <div className="flex flex-1 items-center gap-3">
                    <Avatar initials={getInitials(student.fullName)} size="sm" />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-stone-900">
                        {student.fullName}
                      </p>
                      <p className="text-xs text-stone-500">
                        Roll #{student.rollNumber} · {student.admissionNumber}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {STATUS_CONFIG.map((s) => {
                      const active = current === s.value;
                      return (
                        <button
                          key={s.value}
                          type="button"
                          onClick={() => setStatus(student.id, s.value)}
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium ring-1 transition-all",
                            active
                              ? s.classes + " ring-current"
                              : "bg-white text-stone-500 ring-stone-200 hover:text-stone-700 hover:ring-stone-300",
                          )}
                        >
                          <s.icon className="h-3 w-3" />
                          {s.label}
                        </button>
                      );
                    })}
                  </div>
                </li>
              );
            })}
          </ul>
          <div className="flex items-center justify-between border-t border-stone-200 bg-stone-50/40 px-4 py-3">
            <p className="text-xs text-stone-500">
              <CalendarIcon className="-mt-0.5 mr-1 inline h-3 w-3" />
              {new Date(date).toLocaleDateString("en-IN", {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </p>
            <Button
              onClick={handleSubmit}
              loading={saving}
              leadingIcon={<Save className="h-4 w-4" />}
            >
              Save attendance
            </Button>
          </div>
        </Card>
      )}
    </>
  );
}

function StatChip({
  label,
  value,
  icon: Icon,
  tone,
}: {
  label: string;
  value: number | string;
  icon: typeof Check;
  tone: string;
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-md border border-stone-200 bg-white p-3 shadow-card">
      <span className={cn("flex h-8 w-8 items-center justify-center rounded-md", tone)}>
        <Icon className="h-4 w-4" />
      </span>
      <div>
        <p className="text-[10px] font-semibold uppercase tracking-wider text-stone-500">
          {label}
        </p>
        <p className="display text-lg leading-tight text-stone-900">{value}</p>
      </div>
    </div>
  );
}
