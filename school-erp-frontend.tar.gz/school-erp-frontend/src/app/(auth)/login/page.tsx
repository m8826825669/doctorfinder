"use client";

import { Suspense, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Eye, EyeOff, Mail, Lock, ArrowRight } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/Button";
import { Input, Field } from "@/components/ui/Input";
import { authApi } from "@/lib/api/auth";
import { useAuthStore } from "@/lib/auth/store";
import { loginSchema, type LoginInput } from "@/lib/utils/validators";
import { extractErrorMessage } from "@/lib/api/client";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const setSession = useAuthStore((s) => s.setSession);
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "admin@dpssec45.edu.in", password: "demo1234" },
  });

  const onSubmit = async (values: LoginInput) => {
    try {
      const res = await authApi.login(values);
      setSession(res);
      toast.success(`Welcome back, ${res.user.firstName}`);
      router.replace(params.get("from") || "/dashboard");
    } catch (err) {
      toast.error(extractErrorMessage(err));
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="display text-4xl text-stone-900">Welcome back</h1>
        <p className="mt-2 text-sm text-stone-600">
          Sign in to your school&apos;s dashboard.
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <Field label="Email address" required error={errors.email?.message}>
          <Input
            type="email"
            autoComplete="email"
            placeholder="you@school.edu.in"
            leadingIcon={<Mail className="h-4 w-4" />}
            error={errors.email?.message}
            {...register("email")}
          />
        </Field>

        <Field label="Password" required error={errors.password?.message}>
          <Input
            type={showPassword ? "text" : "password"}
            autoComplete="current-password"
            placeholder="Enter your password"
            leadingIcon={<Lock className="h-4 w-4" />}
            error={errors.password?.message}
            trailingAddon={
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="pointer-events-auto text-stone-500 hover:text-stone-700"
                tabIndex={-1}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            }
            {...register("password")}
          />
        </Field>

        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 text-stone-600">
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-stone-300 text-brand-600 focus:ring-brand-500"
            />
            Remember me
          </label>
          <Link
            href="/forgot-password"
            className="font-medium text-brand-700 hover:text-brand-800"
          >
            Forgot password?
          </Link>
        </div>

        <Button
          type="submit"
          size="lg"
          loading={isSubmitting}
          className="w-full"
          trailingIcon={!isSubmitting && <ArrowRight className="h-4 w-4" />}
        >
          Sign in
        </Button>
      </form>

      <div className="mt-8 border-t border-stone-200 pt-6 text-center text-sm text-stone-600">
        New school onboarding?{" "}
        <Link
          href="/register"
          className="font-medium text-brand-700 hover:text-brand-800"
        >
          Create an account
        </Link>
      </div>

      <p className="mt-6 rounded-md bg-amber-50 px-3 py-2 text-center text-xs text-amber-800 ring-1 ring-amber-200">
        <strong>Demo mode:</strong> any password ≥ 4 chars works. Backend integration is wired but mocks are on by default.
      </p>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-[400px] items-center justify-center">
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-stone-300 border-t-brand-700" />
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
