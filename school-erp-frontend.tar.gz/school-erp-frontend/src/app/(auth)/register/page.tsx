"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowRight, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";

import { Button } from "@/components/ui/Button";
import { Input, Field } from "@/components/ui/Input";
import { Select } from "@/components/ui/Select";
import { authApi } from "@/lib/api/auth";
import { useAuthStore } from "@/lib/auth/store";
import { registerSchema, type RegisterInput } from "@/lib/utils/validators";
import { extractErrorMessage } from "@/lib/api/client";

const BOARDS = [
  { value: "CBSE", label: "CBSE" },
  { value: "ICSE", label: "ICSE" },
  { value: "STATE", label: "State Board" },
  { value: "IB", label: "International Baccalaureate" },
  { value: "CAMBRIDGE", label: "Cambridge (IGCSE/A-levels)" },
  { value: "OTHER", label: "Other" },
];

export default function RegisterPage() {
  const router = useRouter();
  const setSession = useAuthStore((s) => s.setSession);
  const [step, setStep] = useState<1 | 2>(1);

  const {
    register,
    handleSubmit,
    trigger,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    mode: "onTouched",
  });

  const subdomain = watch("subdomain");

  const goToStep2 = async () => {
    const ok = await trigger(["schoolName", "subdomain", "board", "city", "state"]);
    if (ok) setStep(2);
  };

  const onSubmit = async (values: RegisterInput) => {
    try {
      const res = await authApi.register(values);
      setSession(res);
      toast.success("School created! Welcome aboard.");
      router.replace("/dashboard");
    } catch (err) {
      toast.error(extractErrorMessage(err));
    }
  };

  return (
    <div>
      <div className="mb-7">
        <p className="mb-2 text-xs font-medium uppercase tracking-wider text-brand-700">
          Step {step} of 2
        </p>
        <h1 className="display text-4xl text-stone-900">
          {step === 1 ? "About your school" : "Your admin account"}
        </h1>
        <p className="mt-2 text-sm text-stone-600">
          {step === 1
            ? "Set up your tenant. You can edit any of this later in Settings."
            : "Create the principal/owner account. This will have full access."}
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {step === 1 && (
          <>
            <Field
              label="School name"
              required
              error={errors.schoolName?.message}
            >
              <Input
                placeholder="Delhi Public School, Sector 45"
                error={errors.schoolName?.message}
                {...register("schoolName")}
              />
            </Field>

            <Field
              label="Subdomain"
              required
              error={errors.subdomain?.message}
              hint={
                subdomain ? (
                  <span className="font-mono text-stone-700">
                    {subdomain}.schoolerp.in
                  </span>
                ) : (
                  "lowercase, numbers, hyphens only"
                )
              }
            >
              <Input
                placeholder="dpssec45"
                error={errors.subdomain?.message}
                {...register("subdomain")}
              />
            </Field>

            <Field label="Board" required error={errors.board?.message}>
              <Select
                placeholder="Select your board"
                options={BOARDS}
                defaultValue=""
                error={errors.board?.message}
                {...register("board")}
              />
            </Field>

            <div className="grid grid-cols-2 gap-3">
              <Field label="City" required error={errors.city?.message}>
                <Input
                  placeholder="Gurugram"
                  error={errors.city?.message}
                  {...register("city")}
                />
              </Field>
              <Field label="State" required error={errors.state?.message}>
                <Input
                  placeholder="Haryana"
                  error={errors.state?.message}
                  {...register("state")}
                />
              </Field>
            </div>

            <Button
              type="button"
              size="lg"
              className="w-full"
              onClick={goToStep2}
              trailingIcon={<ArrowRight className="h-4 w-4" />}
            >
              Continue
            </Button>
          </>
        )}

        {step === 2 && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Field
                label="First name"
                required
                error={errors.adminFirstName?.message}
              >
                <Input
                  placeholder="Priya"
                  error={errors.adminFirstName?.message}
                  {...register("adminFirstName")}
                />
              </Field>
              <Field
                label="Last name"
                required
                error={errors.adminLastName?.message}
              >
                <Input
                  placeholder="Sharma"
                  error={errors.adminLastName?.message}
                  {...register("adminLastName")}
                />
              </Field>
            </div>

            <Field
              label="Work email"
              required
              error={errors.adminEmail?.message}
            >
              <Input
                type="email"
                placeholder="principal@school.edu.in"
                error={errors.adminEmail?.message}
                {...register("adminEmail")}
              />
            </Field>

            <Field
              label="Mobile (10-digit)"
              required
              error={errors.adminPhone?.message}
            >
              <Input
                inputMode="numeric"
                placeholder="9876543210"
                error={errors.adminPhone?.message}
                {...register("adminPhone")}
              />
            </Field>

            <Field
              label="Password"
              required
              error={errors.password?.message}
              hint="Min 8 chars, with uppercase + number"
            >
              <Input
                type="password"
                placeholder="••••••••"
                error={errors.password?.message}
                {...register("password")}
              />
            </Field>

            <div className="flex gap-2 pt-1">
              <Button
                type="button"
                variant="outline"
                size="lg"
                onClick={() => setStep(1)}
                leadingIcon={<ArrowLeft className="h-4 w-4" />}
              >
                Back
              </Button>
              <Button
                type="submit"
                size="lg"
                loading={isSubmitting}
                className="flex-1"
                trailingIcon={!isSubmitting && <ArrowRight className="h-4 w-4" />}
              >
                Create school
              </Button>
            </div>
          </>
        )}
      </form>

      <div className="mt-8 border-t border-stone-200 pt-6 text-center text-sm text-stone-600">
        Already have an account?{" "}
        <Link
          href="/login"
          className="font-medium text-brand-700 hover:text-brand-800"
        >
          Sign in
        </Link>
      </div>
    </div>
  );
}
