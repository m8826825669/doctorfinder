import type { ReactNode } from "react";
import Link from "next/link";
import { GraduationCap, Quote } from "lucide-react";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Form side */}
      <div className="relative flex flex-col bg-stone-50 bg-dot-grid">
        <div className="flex items-center gap-2.5 px-8 pt-8 sm:px-12">
          <Link
            href="/"
            className="flex items-center gap-2.5 text-stone-900 transition-opacity hover:opacity-80"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-md bg-brand-700 text-white">
              <GraduationCap className="h-4 w-4" strokeWidth={2.25} />
            </span>
            <span className="text-sm font-semibold tracking-tight">School ERP</span>
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-center px-6 py-10 sm:px-12">
          <div className="w-full max-w-md animate-slide-up">{children}</div>
        </div>
        <p className="px-8 pb-6 text-center text-xs text-stone-500 sm:px-12">
          © {new Date().getFullYear()} School ERP · Built for Indian schools
        </p>
      </div>

      {/* Visual side */}
      <div className="relative hidden overflow-hidden lg:block">
        <div className="absolute inset-0 bg-mesh" />
        <div className="absolute inset-0 bg-gradient-to-tr from-stone-950/40 via-transparent to-transparent" />
        <div className="relative flex h-full flex-col justify-between p-12 text-white">
          <div className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-white/60">
            <span className="h-px w-8 bg-white/40" />
            <span>Phase 1 · Multi-tenant SaaS</span>
          </div>
          <div className="max-w-lg">
            <Quote className="h-8 w-8 text-white/40" strokeWidth={1.5} />
            <p className="mt-6 display text-3xl leading-tight">
              From admissions to attendance, fees to faculty — one platform built for the rhythm of Indian schools.
            </p>
            <div className="mt-8 flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-white/15 ring-1 ring-white/20" />
              <div>
                <p className="text-sm font-medium">Designed for CBSE, ICSE, IB</p>
                <p className="text-xs text-white/60">UDISE+ · GST-aware · Vernacular ready</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-6 border-t border-white/15 pt-8">
            {[
              { v: "1,200+", l: "Students per school" },
              { v: "8 hr", l: "Avg setup time" },
              { v: "₹0", l: "Hidden fees" },
            ].map((s) => (
              <div key={s.l}>
                <p className="display text-2xl text-white">{s.v}</p>
                <p className="mt-0.5 text-[11px] uppercase tracking-wider text-white/60">
                  {s.l}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
