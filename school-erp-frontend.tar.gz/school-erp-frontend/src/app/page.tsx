import { redirect } from "next/navigation";

export default function HomePage() {
  // Auth state is client-side (localStorage), so we send everyone to /dashboard
  // and let the (app) layout bounce unauthenticated users to /login.
  redirect("/dashboard");
}
