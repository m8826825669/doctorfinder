"use client";

import { TrendingUp, TrendingDown, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Skeleton } from "@/components/ui/Primitives";

export function StatsCard({
  label,
  value,
  trend,
  icon: Icon,
  loading,
  hint,
  accent = "brand",
}: {
  label: string;
  value: string;
  trend?: number;
  icon: LucideIcon;
  loading?: boolean;
  hint?: string;
  accent?: "brand" | "amber" | "indigo" | "rose";
}) {
  const accentClasses = {
    brand: "bg-brand-50 text-brand-700",
    amber: "bg-amber-50 text-amber-700",
    indigo: "bg-indigo-50 text-indigo-700",
    rose: "bg-rose-50 text-rose-700",
  };

  return (
    <div className="group relative overflow-hidden rounded-lg border border-stone-200 bg-white p-5 shadow-card transition-shadow hover:shadow-card-hover">
      <div className="flex items-start justify-between">
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium uppercase tracking-wide text-stone-500">
            {label}
          </p>
          {loading ? (
            <Skeleton className="mt-2 h-9 w-32" />
          ) : (
            <p className="mt-1.5 display text-3xl text-stone-900">{value}</p>
          )}
          {!loading && trend !== undefined && (
            <div className="mt-2 flex items-center gap-1.5">
              <span
                className={cn(
                  "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-xs font-medium",
                  trend >= 0
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-red-50 text-red-700",
                )}
              >
                {trend >= 0 ? (
                  <TrendingUp className="h-3 w-3" />
                ) : (
                  <TrendingDown className="h-3 w-3" />
                )}
                {trend >= 0 ? "+" : ""}
                {trend.toFixed(1)}%
              </span>
              {hint && <span className="text-xs text-stone-500">{hint}</span>}
            </div>
          )}
        </div>
        <span
          className={cn(
            "flex h-9 w-9 shrink-0 items-center justify-center rounded-md",
            accentClasses[accent],
          )}
        >
          <Icon className="h-4.5 w-4.5" strokeWidth={2} />
        </span>
      </div>
    </div>
  );
}
