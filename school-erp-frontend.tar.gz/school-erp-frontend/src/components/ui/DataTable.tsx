"use client";

import { type ReactNode } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Button } from "./Button";
import { Skeleton } from "./Primitives";

export interface Column<T> {
  key: string;
  header: ReactNode;
  cell: (row: T) => ReactNode;
  className?: string;
  align?: "left" | "right" | "center";
  width?: string; // e.g. "w-32"
}

export function DataTable<T extends { id: number | string }>({
  columns,
  rows,
  loading,
  emptyState,
  onRowClick,
  getRowKey,
  caption,
}: {
  columns: Column<T>[];
  rows: T[];
  loading?: boolean;
  emptyState?: ReactNode;
  onRowClick?: (row: T) => void;
  getRowKey?: (row: T) => string | number;
  caption?: string;
}) {
  if (loading) {
    return (
      <div className="overflow-hidden rounded-lg border border-stone-200 bg-white">
        <div className="space-y-px">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex gap-4 border-b border-stone-100 p-4 last:border-0">
              {columns.map((c) => (
                <Skeleton key={c.key} className={cn("h-5 flex-1", c.width)} />
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="overflow-hidden rounded-lg border border-stone-200 bg-white">
        {emptyState}
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-stone-200 bg-white shadow-card">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-stone-200 text-sm">
          {caption && <caption className="sr-only">{caption}</caption>}
          <thead className="bg-stone-50/80">
            <tr>
              {columns.map((c) => (
                <th
                  key={c.key}
                  scope="col"
                  className={cn(
                    "px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-stone-500",
                    c.align === "right" && "text-right",
                    c.align === "center" && "text-center",
                    c.width,
                  )}
                >
                  {c.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100 bg-white">
            {rows.map((row) => (
              <tr
                key={getRowKey ? getRowKey(row) : row.id}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                className={cn(
                  "transition-colors",
                  onRowClick && "cursor-pointer hover:bg-stone-50",
                )}
              >
                {columns.map((c) => (
                  <td
                    key={c.key}
                    className={cn(
                      "whitespace-nowrap px-4 py-3 text-stone-700",
                      c.align === "right" && "text-right",
                      c.align === "center" && "text-center",
                      c.className,
                    )}
                  >
                    {c.cell(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function Pagination({
  page,
  totalPages,
  totalElements,
  pageSize,
  onPageChange,
}: {
  page: number; // 0-based
  totalPages: number;
  totalElements: number;
  pageSize: number;
  onPageChange: (page: number) => void;
}) {
  const start = page * pageSize + 1;
  const end = Math.min((page + 1) * pageSize, totalElements);

  return (
    <div className="flex flex-col items-center justify-between gap-3 border-t border-stone-200 bg-white px-4 py-3 sm:flex-row">
      <p className="text-xs text-stone-500">
        Showing <span className="font-medium text-stone-700">{start}</span>–
        <span className="font-medium text-stone-700">{end}</span> of{" "}
        <span className="font-medium text-stone-700">{totalElements}</span>
      </p>
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          disabled={page === 0}
          onClick={() => onPageChange(page - 1)}
          leadingIcon={<ChevronLeft className="h-4 w-4" />}
        >
          Previous
        </Button>
        <span className="px-2 text-xs tabular-nums text-stone-500">
          Page {page + 1} of {totalPages}
        </span>
        <Button
          variant="outline"
          size="sm"
          disabled={page >= totalPages - 1}
          onClick={() => onPageChange(page + 1)}
          trailingIcon={<ChevronRight className="h-4 w-4" />}
        >
          Next
        </Button>
      </div>
    </div>
  );
}
