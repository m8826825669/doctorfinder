"use client";

import { forwardRef, type SelectHTMLAttributes } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils/cn";

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  error?: string;
  placeholder?: string;
  options: Array<{ value: string | number; label: string }>;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ className, error, options, placeholder, ...props }, ref) => {
    return (
      <div className="relative">
        <select
          ref={ref}
          aria-invalid={Boolean(error)}
          className={cn(
            "block w-full appearance-none rounded-md border bg-white text-sm text-stone-900",
            "h-10 pl-3 pr-9",
            error
              ? "border-red-400 focus-visible:ring-red-500"
              : "border-stone-300 focus-visible:border-brand-600 focus-visible:ring-brand-600",
            "transition-colors disabled:bg-stone-50 disabled:text-stone-500",
            !props.value && "text-stone-400",
            className,
          )}
          {...props}
        >
          {placeholder && (
            <option value="" disabled>
              {placeholder}
            </option>
          )}
          {options.map((opt) => (
            <option key={opt.value} value={opt.value} className="text-stone-900">
              {opt.label}
            </option>
          ))}
        </select>
        <ChevronDown
          className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400"
          aria-hidden
        />
      </div>
    );
  },
);
Select.displayName = "Select";
