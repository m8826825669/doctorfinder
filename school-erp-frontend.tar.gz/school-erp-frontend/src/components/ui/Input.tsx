"use client";

import { forwardRef, type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils/cn";

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: string;
  leadingIcon?: ReactNode;
  trailingAddon?: ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, error, leadingIcon, trailingAddon, type = "text", ...props }, ref) => {
    return (
      <div className="relative">
        {leadingIcon && (
          <div className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-stone-400">
            {leadingIcon}
          </div>
        )}
        <input
          ref={ref}
          type={type}
          aria-invalid={Boolean(error)}
          className={cn(
            "block w-full rounded-md border bg-white text-sm text-stone-900",
            "placeholder:text-stone-400",
            "h-10 px-3",
            leadingIcon && "pl-9",
            trailingAddon && "pr-12",
            error
              ? "border-red-400 focus-visible:ring-red-500"
              : "border-stone-300 focus-visible:border-brand-600 focus-visible:ring-brand-600",
            "transition-colors disabled:bg-stone-50 disabled:text-stone-500",
            className,
          )}
          {...props}
        />
        {trailingAddon && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-500">
            {trailingAddon}
          </div>
        )}
      </div>
    );
  },
);
Input.displayName = "Input";

export interface LabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  required?: boolean;
}

export function Label({ className, required, children, ...props }: LabelProps) {
  return (
    <label
      className={cn("mb-1.5 block text-xs font-medium text-stone-700", className)}
      {...props}
    >
      {children}
      {required && <span className="ml-0.5 text-red-500">*</span>}
    </label>
  );
}

export function FormError({ message }: { message?: string }) {
  if (!message) return null;
  return (
    <p className="mt-1.5 flex items-start gap-1 text-xs text-red-600">
      <span>{message}</span>
    </p>
  );
}

export function FormHint({ children }: { children: ReactNode }) {
  return <p className="mt-1.5 text-xs text-stone-500">{children}</p>;
}

/** Pre-composed field block: label + control + error/hint */
export function Field({
  label,
  required,
  error,
  hint,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  hint?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div>
      <Label required={required}>{label}</Label>
      {children}
      {error ? <FormError message={error} /> : hint && <FormHint>{hint}</FormHint>}
    </div>
  );
}
