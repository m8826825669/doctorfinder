"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { NAV_SECTIONS } from "@/lib/navigation";
import { useAuthStore } from "@/lib/auth/store";

export function Sidebar() {
  const pathname = usePathname();
  const school = useAuthStore((s) => s.school);
  const userRoles = useAuthStore((s) => s.user?.roles ?? []);

  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-stone-200 bg-stone-950 lg:flex">
      {/* Brand */}
      <div className="flex h-16 items-center gap-2.5 border-b border-stone-800 px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-brand-600 text-white shadow-sm">
          <GraduationCap className="h-4.5 w-4.5" strokeWidth={2.25} />
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-stone-100">
            {school?.name ?? "School ERP"}
          </p>
          <p className="truncate text-[11px] uppercase tracking-wider text-stone-500">
            {school?.subdomain ?? "Sign in to continue"}
          </p>
        </div>
      </div>

      {/* Sections */}
      <nav className="flex-1 overflow-y-auto px-3 py-5">
        {NAV_SECTIONS.map((section, sIdx) => {
          const visible = section.items.filter(
            (item) =>
              !item.roles || item.roles.some((r) => userRoles.includes(r)),
          );
          if (visible.length === 0) return null;

          return (
            <div key={sIdx} className={cn(sIdx > 0 && "mt-6")}>
              {section.label && (
                <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.12em] text-stone-500">
                  {section.label}
                </p>
              )}
              <ul className="space-y-0.5">
                {visible.map((item) => {
                  const active =
                    pathname === item.href ||
                    pathname.startsWith(item.href + "/");
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        className={cn(
                          "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                          active
                            ? "bg-stone-800 text-white"
                            : "text-stone-400 hover:bg-stone-900 hover:text-stone-100",
                        )}
                      >
                        <item.icon
                          className={cn(
                            "h-4 w-4 shrink-0 transition-colors",
                            active
                              ? "text-brand-400"
                              : "text-stone-500 group-hover:text-stone-300",
                          )}
                          strokeWidth={2}
                        />
                        <span className="flex-1 truncate">{item.label}</span>
                        {item.badge && (
                          <span className="rounded-full bg-stone-700 px-2 py-0.5 text-[10px] font-medium text-stone-200">
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-stone-800 p-4">
        <p className="text-[11px] text-stone-500">
          © {new Date().getFullYear()} School ERP
        </p>
        <p className="mt-0.5 text-[11px] text-stone-600">v0.1.0 · Phase 1</p>
      </div>
    </aside>
  );
}
