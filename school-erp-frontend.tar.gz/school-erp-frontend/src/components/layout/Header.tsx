"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Search, Bell, LogOut, ChevronDown, Building2, Menu, X } from "lucide-react";
import { toast } from "sonner";
import { Avatar, Badge } from "@/components/ui/Primitives";
import { useAuthStore } from "@/lib/auth/store";
import { authApi } from "@/lib/api/auth";
import { getInitials } from "@/lib/utils/format";
import { cn } from "@/lib/utils/cn";
import { NAV_SECTIONS } from "@/lib/navigation";

export function Header() {
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const school = useAuthStore((s) => s.school);
  const clear = useAuthStore((s) => s.clear);

  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const handleLogout = async () => {
    await authApi.logout();
    clear();
    toast.success("Signed out successfully");
    router.push("/login");
  };

  const initials = user ? getInitials(`${user.firstName} ${user.lastName}`) : "?";

  return (
    <>
      <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-stone-200 bg-white/85 px-4 backdrop-blur-md sm:px-6">
        {/* Mobile nav trigger */}
        <button
          type="button"
          onClick={() => setMobileNavOpen(true)}
          className="-ml-2 inline-flex h-9 w-9 items-center justify-center rounded-md text-stone-600 hover:bg-stone-100 lg:hidden"
          aria-label="Open menu"
        >
          <Menu className="h-5 w-5" />
        </button>

        {/* Search */}
        <div className="flex flex-1 items-center">
          <div className="relative w-full max-w-md">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
            <input
              type="search"
              placeholder="Search students, classes, invoices…"
              className="h-9 w-full rounded-md border border-stone-200 bg-stone-50 pl-9 pr-12 text-sm placeholder:text-stone-400 focus-visible:border-brand-500 focus-visible:bg-white focus-visible:ring-1 focus-visible:ring-brand-500"
            />
            <kbd className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 rounded border border-stone-200 bg-white px-1.5 py-0.5 font-mono text-[10px] text-stone-500 sm:inline-block">
              ⌘ K
            </kbd>
          </div>
        </div>

        {/* Right cluster */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            className="relative inline-flex h-9 w-9 items-center justify-center rounded-md text-stone-600 hover:bg-stone-100"
            aria-label="Notifications"
          >
            <Bell className="h-4.5 w-4.5" />
            <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-accent-500" />
          </button>

          {/* User dropdown */}
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setMenuOpen((o) => !o)}
              className="flex items-center gap-2 rounded-md px-1.5 py-1 hover:bg-stone-100"
            >
              <Avatar initials={initials} size="sm" />
              <div className="hidden text-left sm:block">
                <p className="text-xs font-semibold text-stone-900 leading-tight">
                  {user?.firstName} {user?.lastName}
                </p>
                <p className="text-[10px] uppercase tracking-wide text-stone-500 leading-tight">
                  {user?.roles[0]?.replace("_", " ").toLowerCase()}
                </p>
              </div>
              <ChevronDown className="h-3.5 w-3.5 text-stone-400" />
            </button>

            {menuOpen && (
              <div className="absolute right-0 mt-2 w-64 origin-top-right animate-slide-up overflow-hidden rounded-lg border border-stone-200 bg-white shadow-pop">
                <div className="border-b border-stone-100 p-4">
                  <p className="text-sm font-semibold text-stone-900">
                    {user?.firstName} {user?.lastName}
                  </p>
                  <p className="truncate text-xs text-stone-500">{user?.email}</p>
                  <div className="mt-3 flex items-start gap-2 rounded-md bg-stone-50 p-2">
                    <Building2 className="mt-0.5 h-4 w-4 shrink-0 text-stone-500" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium text-stone-700">
                        {school?.name}
                      </p>
                      {school?.status === "TRIAL" && (
                        <Badge tone="warning" className="mt-1">
                          Trial
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <div className="p-1.5">
                  <Link
                    href="/settings"
                    onClick={() => setMenuOpen(false)}
                    className="flex w-full items-center gap-2 rounded px-3 py-2 text-sm text-stone-700 hover:bg-stone-100"
                  >
                    School settings
                  </Link>
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="flex w-full items-center gap-2 rounded px-3 py-2 text-sm text-stone-700 hover:bg-stone-100"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    Sign out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Mobile nav drawer */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-stone-950/60 backdrop-blur-sm"
            onClick={() => setMobileNavOpen(false)}
          />
          <div className="absolute inset-y-0 left-0 w-72 bg-stone-950 p-5 shadow-pop">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-sm font-semibold text-stone-100">
                {school?.name ?? "School ERP"}
              </p>
              <button
                type="button"
                onClick={() => setMobileNavOpen(false)}
                className="text-stone-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav>
              {NAV_SECTIONS.flatMap((s) => s.items).map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileNavOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm text-stone-300 hover:bg-stone-800 hover:text-white",
                  )}
                >
                  <item.icon className="h-4 w-4 text-stone-500" />
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
