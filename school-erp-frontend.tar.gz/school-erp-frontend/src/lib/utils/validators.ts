import { z } from "zod";

const indianPhone = /^[6-9]\d{9}$/;
const subdomainPattern = /^[a-z0-9][a-z0-9-]{2,49}$/;
const pinCode = /^[1-9]\d{5}$/;

export const loginSchema = z.object({
  email: z.string().email("Enter a valid email"),
  password: z.string().min(8, "At least 8 characters"),
  subdomain: z.string().optional(),
});

export const registerSchema = z.object({
  schoolName: z.string().min(3, "School name is too short"),
  subdomain: z
    .string()
    .min(3, "At least 3 characters")
    .max(50, "Too long")
    .regex(subdomainPattern, "Lowercase letters, numbers, hyphens only"),
  board: z.enum(["CBSE", "ICSE", "STATE", "IB", "CAMBRIDGE", "OTHER"]),
  city: z.string().min(2),
  state: z.string().min(2),
  adminFirstName: z.string().min(1, "Required"),
  adminLastName: z.string().min(1, "Required"),
  adminEmail: z.string().email("Enter a valid email"),
  adminPhone: z.string().regex(indianPhone, "Enter a valid 10-digit Indian mobile"),
  password: z
    .string()
    .min(8, "At least 8 characters")
    .regex(/[A-Z]/, "Include an uppercase letter")
    .regex(/[0-9]/, "Include a number"),
});

export const studentSchema = z.object({
  firstName: z.string().min(1, "Required").max(60),
  lastName: z.string().min(1, "Required").max(60),
  dateOfBirth: z.string().refine((d) => {
    const date = new Date(d);
    const age = (Date.now() - date.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
    return age >= 2 && age <= 25;
  }, "Age must be between 2 and 25"),
  gender: z.enum(["MALE", "FEMALE", "OTHER"]),
  classId: z.coerce.number().int().positive("Select a class"),
  sectionId: z.coerce.number().int().positive("Select a section"),
  rollNumber: z.string().min(1, "Required").max(20),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().regex(indianPhone, "Invalid mobile").optional().or(z.literal("")),
  bloodGroup: z
    .enum(["A_POS", "A_NEG", "B_POS", "B_NEG", "AB_POS", "AB_NEG", "O_POS", "O_NEG"])
    .optional(),
  address: z.string().max(300).optional(),
  fatherName: z.string().max(100).optional(),
  motherName: z.string().max(100).optional(),
  guardianPhone: z.string().regex(indianPhone, "Invalid mobile").optional().or(z.literal("")),
});

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type StudentInput = z.infer<typeof studentSchema>;
