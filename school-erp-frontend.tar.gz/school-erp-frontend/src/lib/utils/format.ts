import { format, formatDistanceToNow, isToday, isYesterday, parseISO } from "date-fns";

/**
 * Indian Rupee formatting with lakh/crore separators.
 *   12345 -> "₹12,345"
 *   1234567 -> "₹12,34,567"
 */
export function formatCurrency(amount: number, options?: { compact?: boolean }): string {
  if (options?.compact) {
    if (amount >= 10_000_000) return `₹${(amount / 10_000_000).toFixed(2)} Cr`;
    if (amount >= 100_000) return `₹${(amount / 100_000).toFixed(2)} L`;
    if (amount >= 1_000) return `₹${(amount / 1_000).toFixed(1)}K`;
  }
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-IN").format(n);
}

/** Indian phone display: +91 98765 43210 */
export function formatPhone(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  if (digits.length === 10) {
    return `+91 ${digits.slice(0, 5)} ${digits.slice(5)}`;
  }
  if (digits.length === 12 && digits.startsWith("91")) {
    return `+${digits.slice(0, 2)} ${digits.slice(2, 7)} ${digits.slice(7)}`;
  }
  return phone;
}

/** "12 Jan 2026" */
export function formatDate(iso: string): string {
  return format(parseISO(iso), "d MMM yyyy");
}

/** "12 Jan 2026, 3:45 PM" */
export function formatDateTime(iso: string): string {
  return format(parseISO(iso), "d MMM yyyy, h:mm a");
}

/** Smart relative — "Today", "Yesterday", "3 days ago", "12 Jan 2026" */
export function formatRelative(iso: string): string {
  const date = parseISO(iso);
  if (isToday(date)) return "Today";
  if (isYesterday(date)) return "Yesterday";
  const dist = formatDistanceToNow(date);
  if (dist.includes("month") || dist.includes("year")) {
    return format(date, "d MMM yyyy");
  }
  return `${dist} ago`;
}

/** Compute age in years from DOB */
export function calculateAge(dob: string): number {
  const birth = parseISO(dob);
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}

/** Get initials from a full name: "Aarav Kumar Singh" -> "AS" */
export function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/** "PAID" -> "Paid", "HALF_DAY" -> "Half day" */
export function humanizeEnum(value: string): string {
  return value
    .toLowerCase()
    .split("_")
    .map((w, i) => (i === 0 ? w[0].toUpperCase() + w.slice(1) : w))
    .join(" ");
}

/** "A_POS" -> "A+" (blood group) */
export function formatBloodGroup(group: string): string {
  return group.replace("_POS", "+").replace("_NEG", "-");
}
