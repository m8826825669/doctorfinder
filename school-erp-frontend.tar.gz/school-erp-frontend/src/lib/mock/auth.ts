import type {
  AuthUser,
  LoginRequest,
  LoginResponse,
  RegisterSchoolRequest,
  School,
} from "@/types";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const demoSchool: School = {
  id: 1,
  name: "Delhi Public School, Sector 45",
  subdomain: "dpssec45",
  udiseCode: "08120100109",
  board: "CBSE",
  primaryLanguage: "English",
  city: "Gurugram",
  state: "Haryana",
  pinCode: "122003",
  email: "office@dpssec45.edu.in",
  phone: "+91 124 4567890",
  status: "ACTIVE",
  createdAt: "2024-04-01T00:00:00Z",
};

const demoUser: AuthUser = {
  id: 1,
  email: "admin@dpssec45.edu.in",
  firstName: "Priya",
  lastName: "Sharma",
  roles: ["SCHOOL_ADMIN"],
  schoolId: 1,
};

export async function mockLogin(req: LoginRequest): Promise<LoginResponse> {
  await sleep(700);
  if (req.password.length < 4) {
    throw {
      response: {
        status: 401,
        data: { success: false, message: "Invalid email or password" },
      },
      isAxiosError: true,
    };
  }
  return {
    accessToken: "mock-access-" + Date.now(),
    refreshToken: "mock-refresh-" + Date.now(),
    user: { ...demoUser, email: req.email },
    school: demoSchool,
  };
}

export async function mockRegister(req: RegisterSchoolRequest): Promise<LoginResponse> {
  await sleep(1100);
  return {
    accessToken: "mock-access-" + Date.now(),
    refreshToken: "mock-refresh-" + Date.now(),
    user: {
      id: 1,
      email: req.adminEmail,
      firstName: req.adminFirstName,
      lastName: req.adminLastName,
      roles: ["SCHOOL_ADMIN"],
      schoolId: 1,
    },
    school: {
      id: 1,
      name: req.schoolName,
      subdomain: req.subdomain,
      board: req.board,
      city: req.city,
      state: req.state,
      status: "TRIAL",
      createdAt: new Date().toISOString(),
    },
  };
}
