import type {
  CreateStudentRequest,
  PageResponse,
  Student,
} from "@/types";
import type { StudentFilters } from "@/lib/api/students";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const FIRST = [
  "Aarav", "Vihaan", "Aditya", "Arjun", "Rohan", "Krishna", "Ishaan", "Kabir",
  "Saanvi", "Aanya", "Ananya", "Diya", "Myra", "Anika", "Pari", "Aadhya",
  "Reyansh", "Vivaan", "Atharv", "Advait", "Kiara", "Riya", "Zara", "Ira",
];
const LAST = [
  "Sharma", "Verma", "Gupta", "Singh", "Patel", "Reddy", "Iyer", "Khan",
  "Kapoor", "Mehta", "Joshi", "Agarwal", "Nair", "Desai", "Chopra", "Bhatia",
];
const CLASSES = [
  { id: 1, name: "Class 1", level: 1 },
  { id: 2, name: "Class 2", level: 2 },
  { id: 3, name: "Class 5", level: 5 },
  { id: 4, name: "Class 8", level: 8 },
  { id: 5, name: "Class 10", level: 10 },
  { id: 6, name: "Class 12", level: 12 },
];
const SECTIONS = ["A", "B", "C"];

function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

function generate(): Student[] {
  const out: Student[] = [];
  for (let i = 1; i <= 240; i++) {
    const first = pick(FIRST, i * 7);
    const last = pick(LAST, i * 13);
    const cls = pick(CLASSES, i);
    const sec = pick(SECTIONS, i * 3);
    const yearOffset = 18 - cls.level + Math.floor((i % 3));
    const dob = new Date(2026 - yearOffset - 5, (i * 11) % 12, ((i * 17) % 27) + 1);
    out.push({
      id: i,
      admissionNumber: `ADM${String(2024000 + i)}`,
      firstName: first,
      lastName: last,
      fullName: `${first} ${last}`,
      dateOfBirth: dob.toISOString().slice(0, 10),
      gender: i % 2 === 0 ? "FEMALE" : "MALE",
      classId: cls.id,
      className: cls.name,
      sectionId: cls.id * 10 + SECTIONS.indexOf(sec),
      sectionName: sec,
      rollNumber: String((i % 40) + 1),
      email: `${first.toLowerCase()}.${last.toLowerCase()}${i}@dpssec45.edu.in`,
      phone: `9${String(8000000000 + i * 137).slice(0, 9)}`,
      bloodGroup: pick(["O_POS", "A_POS", "B_POS", "AB_POS", "O_NEG"] as const, i),
      address: `H. No. ${i}, Block ${pick(["A", "B", "C"], i)}, DLF Phase ${(i % 5) + 1}`,
      city: "Gurugram",
      state: "Haryana",
      pinCode: "122003",
      fatherName: `${pick(["Rajesh", "Suresh", "Vikram", "Anil", "Manoj"], i)} ${last}`,
      motherName: `${pick(["Sunita", "Meena", "Anjali", "Pooja", "Neha"], i * 2)} ${last}`,
      guardianPhone: `9${String(8000000000 + i * 211).slice(0, 9)}`,
      status: i % 23 === 0 ? "INACTIVE" : "ACTIVE",
      admissionDate: `2024-04-${String(((i % 28) + 1)).padStart(2, "0")}`,
    });
  }
  return out;
}

let store: Student[] = generate();
let nextId = store.length + 1;

export const mockStudentsApi = {
  async list(filters: StudentFilters): Promise<PageResponse<Student>> {
    await sleep(350);
    let rows = store;

    if (filters.search) {
      const q = filters.search.toLowerCase();
      rows = rows.filter(
        (s) =>
          s.fullName.toLowerCase().includes(q) ||
          s.admissionNumber.toLowerCase().includes(q) ||
          s.rollNumber.includes(q),
      );
    }
    if (filters.classId) rows = rows.filter((s) => s.classId === filters.classId);
    if (filters.status) rows = rows.filter((s) => s.status === filters.status);

    const page = filters.page ?? 0;
    const size = filters.size ?? 20;
    const totalElements = rows.length;
    const totalPages = Math.max(1, Math.ceil(totalElements / size));
    const content = rows.slice(page * size, page * size + size);

    return {
      content,
      page,
      size,
      totalElements,
      totalPages,
      first: page === 0,
      last: page >= totalPages - 1,
    };
  },

  async getById(id: number): Promise<Student> {
    await sleep(250);
    const s = store.find((s) => s.id === id);
    if (!s) throw new Error(`Student ${id} not found`);
    return s;
  },

  async create(req: CreateStudentRequest): Promise<Student> {
    await sleep(600);
    const cls = CLASSES.find((c) => c.id === req.classId) ?? CLASSES[0];
    const created: Student = {
      id: nextId++,
      admissionNumber: `ADM${String(2024000 + nextId)}`,
      ...req,
      fullName: `${req.firstName} ${req.lastName}`,
      className: cls.name,
      sectionName: SECTIONS[req.sectionId % SECTIONS.length] ?? "A",
      status: "ACTIVE",
      admissionDate: new Date().toISOString().slice(0, 10),
    };
    store = [created, ...store];
    return created;
  },

  async update(id: number, req: Partial<CreateStudentRequest>): Promise<Student> {
    await sleep(400);
    const idx = store.findIndex((s) => s.id === id);
    if (idx === -1) throw new Error("Student not found");
    store[idx] = {
      ...store[idx],
      ...req,
      fullName: `${req.firstName ?? store[idx].firstName} ${req.lastName ?? store[idx].lastName}`,
    };
    return store[idx];
  },

  async delete(id: number): Promise<void> {
    await sleep(300);
    store = store.filter((s) => s.id !== id);
  },
};

export const mockClasses = CLASSES;
export const mockSections = SECTIONS;
