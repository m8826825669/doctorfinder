import type { DashboardStats } from "@/types";

export const mockDashboard = {
  async getStats(): Promise<DashboardStats> {
    await new Promise((r) => setTimeout(r, 400));
    return {
      totalStudents: 1247,
      studentsTrend: 3.2,
      attendanceToday: 92.4,
      attendanceTrend: 1.8,
      feesPending: 1_847_500,
      feesCollected: 18_320_000,
      totalTeachers: 78,
      upcomingExams: 3,
    };
  },
};
