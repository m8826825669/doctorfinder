import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { AuthUser, School } from "@/types";

interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  user: AuthUser | null;
  school: School | null;
  isAuthenticated: boolean;

  setSession: (params: {
    accessToken: string;
    refreshToken: string;
    user: AuthUser;
    school: School;
  }) => void;
  setTokens: (accessToken: string, refreshToken?: string) => void;
  clear: () => void;
  hasRole: (role: AuthUser["roles"][number]) => boolean;
  hasAnyRole: (roles: AuthUser["roles"]) => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      accessToken: null,
      refreshToken: null,
      user: null,
      school: null,
      isAuthenticated: false,

      setSession: ({ accessToken, refreshToken, user, school }) =>
        set({ accessToken, refreshToken, user, school, isAuthenticated: true }),

      setTokens: (accessToken, refreshToken) =>
        set((s) => ({
          accessToken,
          refreshToken: refreshToken ?? s.refreshToken,
        })),

      clear: () =>
        set({
          accessToken: null,
          refreshToken: null,
          user: null,
          school: null,
          isAuthenticated: false,
        }),

      hasRole: (role) => Boolean(get().user?.roles.includes(role)),

      hasAnyRole: (roles) => {
        const userRoles = get().user?.roles ?? [];
        return roles.some((r) => userRoles.includes(r));
      },
    }),
    {
      name: "school-erp-auth",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        accessToken: s.accessToken,
        refreshToken: s.refreshToken,
        user: s.user,
        school: s.school,
        isAuthenticated: s.isAuthenticated,
      }),
    },
  ),
);
