import { apiClient } from "./client";
import { mockDashboard } from "@/lib/mock/dashboard";
import type { ApiResponse, DashboardStats } from "@/types";

const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === "true";

export const dashboardApi = {
  async getStats(): Promise<DashboardStats> {
    if (USE_MOCK) return mockDashboard.getStats();
    const { data } = await apiClient.get<ApiResponse<DashboardStats>>(
      "/api/v1/dashboard/stats",
    );
    if (!data.data) throw new Error("Empty response");
    return data.data;
  },
};
