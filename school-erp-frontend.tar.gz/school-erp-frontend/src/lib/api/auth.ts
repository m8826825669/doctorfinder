import { apiClient } from "./client";
import { mockLogin, mockRegister } from "@/lib/mock/auth";
import type {
  ApiResponse,
  LoginRequest,
  LoginResponse,
  RegisterSchoolRequest,
} from "@/types";

const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === "true";

export const authApi = {
  async login(req: LoginRequest): Promise<LoginResponse> {
    if (USE_MOCK) return mockLogin(req);
    const { data } = await apiClient.post<ApiResponse<LoginResponse>>(
      "/api/v1/auth/login",
      req,
    );
    if (!data.data) throw new Error("Login response missing data");
    return data.data;
  },

  async register(req: RegisterSchoolRequest): Promise<LoginResponse> {
    if (USE_MOCK) return mockRegister(req);
    const { data } = await apiClient.post<ApiResponse<LoginResponse>>(
      "/api/v1/auth/register-school",
      req,
    );
    if (!data.data) throw new Error("Register response missing data");
    return data.data;
  },

  async logout(): Promise<void> {
    if (USE_MOCK) return;
    await apiClient.post("/api/v1/auth/logout").catch(() => {
      // best effort — clearing client-side is enough
    });
  },

  async forgotPassword(email: string): Promise<void> {
    if (USE_MOCK) return new Promise((r) => setTimeout(r, 600));
    await apiClient.post("/api/v1/auth/forgot-password", { email });
  },
};
