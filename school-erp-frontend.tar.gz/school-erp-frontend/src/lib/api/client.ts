import axios, { AxiosError, type InternalAxiosRequestConfig } from "axios";
import { useAuthStore } from "@/lib/auth/store";
import type { ApiResponse } from "@/types";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8080";

export const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  headers: {
    "Content-Type": "application/json",
  },
});

// ---- Request: attach JWT ------------------------------------------------
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = useAuthStore.getState().accessToken;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ---- Response: unwrap envelope, handle 401 ------------------------------
let isRefreshing = false;
let pendingQueue: Array<(token: string | null) => void> = [];

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<ApiResponse<unknown>>) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    // If 401 and we haven't retried, try refresh once.
    if (
      error.response?.status === 401 &&
      original &&
      !original._retry &&
      !original.url?.includes("/auth/")
    ) {
      original._retry = true;

      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          pendingQueue.push((token) => {
            if (token) {
              original.headers.Authorization = `Bearer ${token}`;
              resolve(apiClient(original));
            } else {
              reject(error);
            }
          });
        });
      }

      isRefreshing = true;
      try {
        const refreshToken = useAuthStore.getState().refreshToken;
        if (!refreshToken) throw new Error("No refresh token");

        const { data } = await axios.post<
          ApiResponse<{ accessToken: string; refreshToken: string }>
        >(`${API_URL}/api/v1/auth/refresh`, { refreshToken });

        const newAccess = data.data?.accessToken;
        const newRefresh = data.data?.refreshToken;
        if (!newAccess) throw new Error("No access token in refresh response");

        useAuthStore.getState().setTokens(newAccess, newRefresh);
        pendingQueue.forEach((cb) => cb(newAccess));
        pendingQueue = [];

        original.headers.Authorization = `Bearer ${newAccess}`;
        return apiClient(original);
      } catch (refreshErr) {
        pendingQueue.forEach((cb) => cb(null));
        pendingQueue = [];
        useAuthStore.getState().clear();
        if (typeof window !== "undefined") {
          window.location.href = "/login";
        }
        return Promise.reject(refreshErr);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  },
);

/** Pull a clean error message out of an Axios failure. */
export function extractErrorMessage(err: unknown): string {
  if (axios.isAxiosError<ApiResponse<unknown>>(err)) {
    const data = err.response?.data;
    if (data?.errors && data.errors.length > 0) {
      return data.errors.map((e) => e.message).join(", ");
    }
    if (data?.message) return data.message;
    if (err.code === "ERR_NETWORK") return "Cannot reach server. Check your connection.";
    return err.message;
  }
  if (err instanceof Error) return err.message;
  return "Something went wrong";
}
