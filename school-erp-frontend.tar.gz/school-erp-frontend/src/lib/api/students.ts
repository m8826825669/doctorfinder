import { apiClient } from "./client";
import { mockStudentsApi } from "@/lib/mock/students";
import type {
  ApiResponse,
  CreateStudentRequest,
  PageParams,
  PageResponse,
  Student,
} from "@/types";

const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === "true";

export interface StudentFilters extends PageParams {
  classId?: number;
  sectionId?: number;
  status?: string;
}

export const studentsApi = {
  async list(filters: StudentFilters = {}): Promise<PageResponse<Student>> {
    if (USE_MOCK) return mockStudentsApi.list(filters);
    const { data } = await apiClient.get<ApiResponse<PageResponse<Student>>>(
      "/api/v1/students",
      { params: filters },
    );
    if (!data.data) throw new Error("Empty response");
    return data.data;
  },

  async getById(id: number): Promise<Student> {
    if (USE_MOCK) return mockStudentsApi.getById(id);
    const { data } = await apiClient.get<ApiResponse<Student>>(`/api/v1/students/${id}`);
    if (!data.data) throw new Error("Student not found");
    return data.data;
  },

  async create(req: CreateStudentRequest): Promise<Student> {
    if (USE_MOCK) return mockStudentsApi.create(req);
    const { data } = await apiClient.post<ApiResponse<Student>>("/api/v1/students", req);
    if (!data.data) throw new Error("Empty response");
    return data.data;
  },

  async update(id: number, req: Partial<CreateStudentRequest>): Promise<Student> {
    if (USE_MOCK) return mockStudentsApi.update(id, req);
    const { data } = await apiClient.put<ApiResponse<Student>>(
      `/api/v1/students/${id}`,
      req,
    );
    if (!data.data) throw new Error("Empty response");
    return data.data;
  },

  async delete(id: number): Promise<void> {
    if (USE_MOCK) return mockStudentsApi.delete(id);
    await apiClient.delete(`/api/v1/students/${id}`);
  },
};
