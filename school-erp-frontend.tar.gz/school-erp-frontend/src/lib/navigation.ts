import {
  LayoutDashboard,
  Users,
  GraduationCap,
  CalendarCheck,
  Receipt,
  Settings,
  type LucideIcon,
} from "lucide-react";
import type { UserRole } from "@/types";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  roles?: UserRole[]; // undefined = visible to everyone signed in
  badge?: string;
}

export interface NavSection {
  label?: string;
  items: NavItem[];
}

export const NAV_SECTIONS: NavSection[] = [
  {
    items: [
      { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    ],
  },
  {
    label: "Academics",
    items: [
      { label: "Students", href: "/students", icon: Users },
      { label: "Classes", href: "/classes", icon: GraduationCap },
      { label: "Attendance", href: "/attendance", icon: CalendarCheck },
    ],
  },
  {
    label: "Finance",
    items: [
      { label: "Fees", href: "/fees", icon: Receipt },
    ],
  },
  {
    label: "System",
    items: [
      {
        label: "Settings",
        href: "/settings",
        icon: Settings,
        roles: ["SCHOOL_ADMIN", "SUPER_ADMIN"],
      },
    ],
  },
];
