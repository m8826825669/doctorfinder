# School ERP — Frontend

Next.js 15 + TypeScript + Tailwind frontend for the multi-tenant School ERP SaaS.

Built to pair with the Spring Boot backend in `school-erp-backend/`, but **runs standalone in mock mode** so you can develop the UI without the backend up.

---

## Quick start

```bash
# 1. Install
npm install

# 2. Set env
cp .env.example .env

# 3. Run (mock mode is on by default)
npm run dev
```

Open <http://localhost:3000>. You'll be redirected to `/login`.

**Demo credentials (mock mode):**
- Any email
- Any password ≥ 4 characters

---

## Stack

| Layer | Choice |
|---|---|
| Framework | Next.js 15.1 (App Router) + React 19 |
| Language | TypeScript (strict) |
| Styling | Tailwind CSS 3.4 — custom tokens in `tailwind.config.ts` |
| Type | **Inter** (body) + **Instrument Serif** (display) — both from Google Fonts |
| Brand color | Deep teal `#0f766e` (Tailwind `brand-700`) — distinctive, educational |
| State | Zustand (with localStorage persist for auth) |
| Forms | React Hook Form + Zod |
| HTTP | Axios — interceptor handles JWT + 401 refresh |
| Icons | lucide-react |
| Toasts | sonner |
| Dates | date-fns |

---

## What's wired

| Module | Status | Notes |
|---|---|---|
| `/login` | ✅ Full | Hooks into `authApi.login()` — falls back to mock |
| `/register` | ✅ Full | 2-step wizard: school info → admin account |
| `/forgot-password` | ✅ Stub | Calls API; needs backend endpoint |
| `/dashboard` | ✅ Full | Stats grid, activity feed, today's schedule |
| `/students` | ✅ Full | Search, class/status filter, paginated table, click-to-detail |
| `/students/new` | ✅ Full | Create form: Personal + Academic + Contact sections |
| `/students/[id]` | ✅ Full | Profile view with tabs (attendance/fees/academics tabs ready for next backend phase) |
| `/classes` | ✅ Visual | Capacity meters per section, mock data |
| `/attendance` | ✅ Functional | Class+section+date selector, mark all, per-student status, save (mock) |
| `/fees` | ✅ Visual | Invoice table with status tabs (paid/pending/overdue), mock data |
| `/settings` | ✅ Stub | Layout for groups; quick school profile (read-only) |

---

## Mock mode

Set `NEXT_PUBLIC_USE_MOCK=true` in `.env`. All `*Api` modules in `src/lib/api/*.ts` check this flag and route to `src/lib/mock/*.ts` instead of hitting the network.

```ts
// src/lib/api/students.ts
async list(filters) {
  if (USE_MOCK) return mockStudentsApi.list(filters);
  const { data } = await apiClient.get(...);
  return data.data;
}
```

The mock layer ships with **240 realistic Indian-named students** across Classes 1–12, with phone numbers, addresses, family info, and admission numbers.

To switch to the real backend:

```bash
NEXT_PUBLIC_USE_MOCK=false
NEXT_PUBLIC_API_URL=http://localhost:8080
```

The Axios client (`src/lib/api/client.ts`) handles:
- Bearer token attachment from the Zustand store
- Single-flight 401 refresh queue (re-tries the original request after refresh)
- Automatic redirect to `/login` if refresh fails
- Envelope unwrap matching backend's `ApiResponse<T>`

---

## Project structure

```
src/
├── app/
│   ├── (auth)/             # Public routes — login, register, forgot password
│   │   └── layout.tsx      # Split-panel design (form left, gradient mesh right)
│   ├── (app)/              # Protected routes — sidebar + header shell
│   │   ├── layout.tsx      # Wraps with AuthGuard
│   │   ├── dashboard/
│   │   ├── students/
│   │   │   ├── page.tsx    # List
│   │   │   ├── new/        # Create form
│   │   │   └── [id]/       # Detail
│   │   ├── classes/
│   │   ├── attendance/
│   │   ├── fees/
│   │   └── settings/
│   ├── globals.css         # Tailwind + custom backgrounds + scrollbar
│   ├── layout.tsx          # Fonts, toaster, root metadata
│   └── page.tsx            # Redirects to /dashboard
├── components/
│   ├── ui/                 # Reusable: Button, Input, Select, DataTable, Card, etc.
│   ├── layout/             # Sidebar, Header, AuthGuard
│   └── dashboard/          # Page-specific components
├── lib/
│   ├── api/                # Axios + per-domain API modules
│   ├── auth/               # Zustand store
│   ├── mock/               # Mock data backing the API modules
│   ├── utils/              # cn(), formatters, validators (Zod schemas)
│   ├── hooks/
│   └── navigation.ts       # Single source of truth for sidebar nav
└── types/
    └── index.ts            # Mirrors backend DTOs
```

---

## Design system

The visual system is restrained and dense — meant for school admins who use this all day. Decisions worth knowing before extending:

- **Stone neutrals, not gray.** Warm palette feels less sterile, more "school office" than "tech company."
- **Dark sidebar / light content.** Familiar from Notion/Linear; reduces visual fatigue across long sessions.
- **Display serif used sparingly.** Only for hero numbers and page titles (`.display` class). Body type stays sans for readability.
- **Brand color is teal, not blue.** Conscious choice to look distinctive without being loud.
- **Tailwind tokens, no design tokens lib.** All colors/spacing in `tailwind.config.ts`. No CSS-in-JS to debug.

### Adding a new module

```tsx
// src/app/(app)/exams/page.tsx
import { PageHeader } from "@/components/ui/PageHeader";
import { Card, CardContent } from "@/components/ui/Primitives";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { Button } from "@/components/ui/Button";

export default function ExamsPage() {
  return (
    <>
      <PageHeader
        title="Exams"
        description="Schedule and manage examinations."
        actions={<Button>Schedule exam</Button>}
      />
      <Card>{/* ... */}</Card>
    </>
  );
}
```

Then add it to `src/lib/navigation.ts`.

### Adding an API module

```ts
// 1. src/lib/api/exams.ts
import { apiClient } from "./client";
import { mockExams } from "@/lib/mock/exams";
const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === "true";

export const examsApi = {
  async list() {
    if (USE_MOCK) return mockExams.list();
    const { data } = await apiClient.get<ApiResponse<Exam[]>>("/api/v1/exams");
    return data.data ?? [];
  },
};
```

### Adding a Zod schema

Schemas live in `src/lib/utils/validators.ts` to keep them centralized. Use existing Indian regexes (`indianPhone`, `pinCode`) for consistency.

---

## Scripts

```bash
npm run dev         # Dev server with HMR
npm run build       # Production build
npm run start       # Run built app
npm run lint        # ESLint
npm run typecheck   # tsc --noEmit (no emit, just check)
```

---

## What's intentionally NOT here yet

- **Real auth wired to backend.** Auth APIs aren't in the backend yet — the mock simulates the contract. When backend ships, set `NEXT_PUBLIC_USE_MOCK=false`.
- **Edit student form.** Detail page has the Edit button but no `/students/[id]/edit` route yet. Reuse `students/new/page.tsx` — pass an optional `student` prop and switch between create/update calls.
- **Search modal (⌘K).** Header shows the kbd hint but the spotlight palette is a follow-up.
- **Tests.** No Vitest/Playwright setup. Add when the API contracts settle.
- **i18n.** All copy is in English. Hindi/regional languages will come via a `next-intl` integration later.

---

## Connecting to the Spring Boot backend

The backend's contract is mirrored in `src/types/index.ts`. When the auth module ships in the backend, the only change needed here is:

```diff
# .env
- NEXT_PUBLIC_USE_MOCK=true
+ NEXT_PUBLIC_USE_MOCK=false
NEXT_PUBLIC_API_URL=http://localhost:8080
```

CORS is already enabled on the Spring Boot side (see `SecurityConfig`). The frontend sends `Authorization: Bearer <token>`; the backend's `JwtAuthenticationFilter` populates both `SecurityContext` and `TenantContext`.

If your backend runs on a different port/host, update `NEXT_PUBLIC_API_URL` and rebuild.

---

## License

Internal — not yet published.
