package com.schoolerp.tenant.controller;

import com.schoolerp.common.dto.ApiResponse;
import com.schoolerp.tenant.repository.SchoolRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Public health endpoint. Confirms the app is up and DB is reachable.
 * Once auth is wired, this will move under {@code /api/v1/public/}.
 */
@RestController
@RequestMapping("/api/v1/public/health")
@RequiredArgsConstructor
@Tag(name = "Health")
@SecurityRequirements
public class HealthController {

    private final SchoolRepository schoolRepository;

    @GetMapping
    @Operation(summary = "Liveness + DB connectivity check")
    public ApiResponse<Map<String, Object>> health() {
        long schoolCount = schoolRepository.count();
        return ApiResponse.ok(Map.of(
                "status", "UP",
                "schools_registered", schoolCount,
                "service", "school-erp-backend"
        ));
    }
}
