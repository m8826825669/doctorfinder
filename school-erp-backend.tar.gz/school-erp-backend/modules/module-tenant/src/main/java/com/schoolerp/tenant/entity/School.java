package com.schoolerp.tenant.entity;

import com.schoolerp.common.entity.AuditableEntity;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "schools",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_schools_subdomain", columnNames = "subdomain"),
                @UniqueConstraint(name = "uk_schools_udise_code", columnNames = "udise_code")
        }
)
public class School extends AuditableEntity {

    @Column(nullable = false, length = 200)
    private String name;

    /** Tenant subdomain, e.g. delhipublic.schoolerp.in */
    @Column(nullable = false, length = 100)
    private String subdomain;

    /** UDISE+ code — issued by Govt of India for every recognised school. */
    @Column(name = "udise_code", length = 20)
    private String udiseCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "board", length = 30)
    private BoardType board;

    @Column(name = "primary_language", length = 30)
    private String primaryLanguage;

    @Column(length = 100)
    private String city;

    @Column(length = 100)
    private String state;

    @Column(name = "pin_code", length = 10)
    private String pinCode;

    @Column(length = 200)
    private String email;

    @Column(length = 20)
    private String phone;

    /** GSTIN for invoice generation (optional — many schools are GST exempt). */
    @Column(length = 20)
    private String gstin;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private SchoolStatus status;

    public enum BoardType {
        CBSE, ICSE, STATE, IB, CAMBRIDGE, OTHER
    }

    public enum SchoolStatus {
        TRIAL, ACTIVE, SUSPENDED, INACTIVE
    }
}
