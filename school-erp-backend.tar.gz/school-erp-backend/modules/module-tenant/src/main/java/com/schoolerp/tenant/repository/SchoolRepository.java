package com.schoolerp.tenant.repository;

import com.schoolerp.tenant.entity.School;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SchoolRepository extends JpaRepository<School, Long> {

    Optional<School> findBySubdomainAndDeletedAtIsNull(String subdomain);

    boolean existsBySubdomain(String subdomain);

    boolean existsByUdiseCode(String udiseCode);
}
