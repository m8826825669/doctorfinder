# School ERP Backend

Multi-tenant School ERP SaaS — Spring Boot 3.4 / Java 21 / PostgreSQL 16.

Modular monolith now, extractable to microservices later.

## Project Layout

```
school-erp-backend/
├── pom.xml                          # parent POM, dependency mgmt
├── platform/                        # cross-cutting infrastructure
│   ├── platform-common/             # base entity, DTOs, exceptions, audit
│   ├── platform-security/           # JWT, tenant context, security config
│   └── platform-web/                # global exception handler, OpenAPI, JPA auditing
├── modules/                         # domain modules — each becomes a microservice candidate
│   └── module-tenant/               # schools / tenant management (only one for now)
├── app/                             # bootable Spring Boot app — assembles all modules
│   └── src/main/resources/
│       ├── application.yml
│       └── db/migration/            # Flyway migrations
├── docker-compose.yml               # postgres + redis + pgadmin
└── .env.example
```

### Future modules (added in subsequent phases)

`module-auth`, `module-student`, `module-academic`, `module-attendance`,
`module-finance`, `module-exam`, `module-lms`, `module-notification`,
`module-analytics`.

## Multi-tenancy

- Every tenant-scoped table has `school_id`.
- Entities extend `TenantAwareEntity`, which carries a Hibernate `@Filter`.
- `JwtAuthenticationFilter` reads `school_id` from the JWT and stamps
  `TenantContext` (ThreadLocal).
- `TenantFilterAspect` enables the Hibernate filter on every `@Transactional`
  method — so `WHERE school_id = :current` is auto-applied to every query.
- `TenantEntityListener` populates `school_id` on insert from `TenantContext`.

Net effect: writing repos and services, you almost never reference `school_id`
explicitly — but data leakage is impossible by construction.

> **Root tenant entity** (`School` itself) extends `AuditableEntity`, **not**
> `TenantAwareEntity` — it has no `school_id` column.

## Prerequisites

- JDK 21
- Maven 3.9+
- Docker + Docker Compose

## Quick Start

```bash
# 1. Start infra
docker compose up -d

# 2. Copy env template
cp .env.example .env
# edit .env if needed

# 3. Build
mvn clean install -DskipTests

# 4. Run
cd app
mvn spring-boot:run
# OR
java -jar target/school-erp.jar
```

App runs at `http://localhost:8080`.

- Health: <http://localhost:8080/api/v1/public/health>
- Swagger UI: <http://localhost:8080/swagger-ui.html>
- Actuator: <http://localhost:8080/actuator/health>
- pgAdmin: <http://localhost:5050> (admin@schoolerp.local / admin)

## Verifying multi-tenancy works

After auth is wired up (next phase), you can confirm isolation by:

1. Creating two schools via the bootstrap endpoint.
2. Logging in as user from school A — JWT contains `school_id=1`.
3. Listing students returns only school 1's students. Try forging a query for
   school 2 — Hibernate filter blocks it.

## Adding a new domain module

1. `mkdir modules/module-<name>` and copy `module-tenant/pom.xml` as template.
2. Add it to the parent `<modules>` list.
3. Add a dependency on it in `app/pom.xml`.
4. Entities under `com.schoolerp.<name>` are auto-scanned (root package).

## Common Commands

```bash
# Run tests
mvn test

# Skip tests during local iteration
mvn install -DskipTests

# Reset local DB (destroys all data)
docker compose down -v && docker compose up -d

# Clean build everything
mvn clean install
```

## Conventions

- **DTOs only** in controllers — never expose JPA entities.
- **MapStruct** for entity ↔ DTO mapping.
- **Flyway migrations** versioned `V<n>__<description>.sql` — never edit a
  committed migration; add a new one.
- **`@Transactional` on services**, never on controllers.
- All API responses wrapped in `ApiResponse<T>`.
- Public endpoints under `/api/v1/public/**` and `/api/v1/auth/**`. Everything
  else requires `Authorization: Bearer <jwt>`.

## Roadmap

| Phase | Modules | Status |
|-------|---------|--------|
| 0     | platform-* + module-tenant | ✅ done (this scaffold) |
| 1 — MVP | auth, student, academic, attendance, finance (basic) | next |
| 2     | exam, notification, timetable, lms (basics) | |
| 3     | analytics/AI, parent engagement, automation | |
