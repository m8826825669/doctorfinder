package com.schoolerp.web.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Enables JPA auditing (CreatedBy/LastModifiedBy/etc) wired to {@code AuditorAwareImpl}
 * and pins transaction management at order=0 (outermost) so that the
 * {@code TenantFilterAspect} (order=10) runs INSIDE an active Hibernate session.
 */
@Configuration
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
@EnableTransactionManagement(order = 0)
public class JpaAuditingConfig {
}
