package com.schoolerp.common.exception;

public class ResourceNotFoundException extends BaseException {

    public ResourceNotFoundException(String resource, Object identifier) {
        super(ErrorCode.RESOURCE_NOT_FOUND,
                "%s not found with identifier: %s".formatted(resource, identifier));
    }

    public ResourceNotFoundException(ErrorCode errorCode, String resource, Object identifier) {
        super(errorCode, "%s not found with identifier: %s".formatted(resource, identifier));
    }
}
