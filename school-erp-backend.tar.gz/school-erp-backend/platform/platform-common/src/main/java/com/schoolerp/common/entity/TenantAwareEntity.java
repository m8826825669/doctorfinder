package com.schoolerp.common.entity;

import com.schoolerp.common.tenant.TenantEntityListener;
import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;

/**
 * Base for all tenant-scoped entities. Adds school_id discriminator.
 * <p>
 * The Hibernate filter {@code tenantFilter} is auto-applied per @Transactional
 * method via {@code TenantFilterAspect} — your repos do NOT need to add
 * WHERE school_id = ?.
 * <p>
 * Inserts: schoolId is auto-populated from {@code TenantContext} via
 * {@link TenantEntityListener}.
 */
@Getter
@Setter
@MappedSuperclass
@EntityListeners(TenantEntityListener.class)
@FilterDef(
        name = "tenantFilter",
        parameters = @ParamDef(name = "schoolId", type = Long.class)
)
@Filter(name = "tenantFilter", condition = "school_id = :schoolId")
public abstract class TenantAwareEntity extends AuditableEntity {

    @Column(name = "school_id", nullable = false, updatable = false)
    private Long schoolId;
}
