package com.schoolerp.common.tenant;

import com.schoolerp.common.entity.TenantAwareEntity;
import jakarta.persistence.PrePersist;

/**
 * JPA listener that stamps {@code school_id} from {@link TenantContext}
 * onto any {@link TenantAwareEntity} on insert.
 * <p>
 * Wired globally via {@code @EntityListeners(TenantEntityListener.class)}
 * on {@link TenantAwareEntity} — no per-entity boilerplate needed.
 */
public class TenantEntityListener {

    @PrePersist
    public void prePersist(Object entity) {
        if (entity instanceof TenantAwareEntity tenantEntity) {
            if (tenantEntity.getSchoolId() == null) {
                tenantEntity.setSchoolId(TenantContext.requireTenantId());
            }
        }
    }
}
