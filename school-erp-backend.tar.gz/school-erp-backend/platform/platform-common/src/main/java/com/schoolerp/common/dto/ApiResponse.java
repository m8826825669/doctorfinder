package com.schoolerp.common.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.time.Instant;
import java.util.List;

/**
 * Standard envelope for ALL API responses.
 * <pre>
 * {
 *   "success": true,
 *   "data": {...},
 *   "message": "...",
 *   "timestamp": "..."
 * }
 * </pre>
 */
@Getter
@Builder
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {

    private final boolean success;
    private final T data;
    private final String message;
    private final List<ApiError> errors;
    @Builder.Default
    private final Instant timestamp = Instant.now();

    public static <T> ApiResponse<T> ok(T data) {
        return ApiResponse.<T>builder().success(true).data(data).build();
    }

    public static <T> ApiResponse<T> ok(T data, String message) {
        return ApiResponse.<T>builder().success(true).data(data).message(message).build();
    }

    public static ApiResponse<Void> message(String message) {
        return ApiResponse.<Void>builder().success(true).message(message).build();
    }

    public static <T> ApiResponse<T> failure(String message, List<ApiError> errors) {
        return ApiResponse.<T>builder().success(false).message(message).errors(errors).build();
    }

    public static <T> ApiResponse<T> failure(String message) {
        return ApiResponse.<T>builder().success(false).message(message).build();
    }

    @Getter
    @Builder
    @AllArgsConstructor
    public static class ApiError {
        private final String code;
        private final String field;
        private final String message;
    }
}
