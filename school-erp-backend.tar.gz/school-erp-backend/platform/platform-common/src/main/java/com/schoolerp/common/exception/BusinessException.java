package com.schoolerp.common.exception;

/**
 * Thrown when a business rule is violated (e.g. fee due, attendance constraint).
 * Maps to 4xx by default depending on the {@link ErrorCode}.
 */
public class BusinessException extends BaseException {

    public BusinessException(ErrorCode errorCode, String message) {
        super(errorCode, message);
    }

    public BusinessException(String message) {
        super(ErrorCode.BAD_REQUEST, message);
    }
}
