package com.schoolerp.common.util;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Resolves "who created/updated this row" for JPA auditing.
 * Returns the userId from the JWT principal once auth is wired up;
 * returns Optional.empty() for system/anonymous operations.
 */
@Component("auditorAware")
public class AuditorAwareImpl implements AuditorAware<Long> {

    @Override
    public Optional<Long> getCurrentAuditor() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || "anonymousUser".equals(auth.getPrincipal())) {
            return Optional.empty();
        }
        Object principal = auth.getPrincipal();
        // Will be replaced with the actual UserPrincipal type in the auth module.
        if (principal instanceof Long userId) {
            return Optional.of(userId);
        }
        try {
            return Optional.of(Long.valueOf(principal.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }
}
