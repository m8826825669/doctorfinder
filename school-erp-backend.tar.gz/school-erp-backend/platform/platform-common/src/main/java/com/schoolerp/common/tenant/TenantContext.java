package com.schoolerp.common.tenant;

/**
 * Thread-local holder for the current school/tenant id.
 * <p>
 * Set by {@code JwtAuthenticationFilter} (in platform-security) after JWT auth,
 * read by Hibernate filter to scope every query. Cleared at end of request.
 * <p>
 * For async work (CompletableFuture / @Async / Kafka listeners), propagate
 * explicitly — ThreadLocals do not cross threads automatically.
 */
public final class TenantContext {

    private static final ThreadLocal<Long> CURRENT_TENANT = new ThreadLocal<>();

    private TenantContext() {}

    public static void setTenantId(Long tenantId) {
        CURRENT_TENANT.set(tenantId);
    }

    public static Long getTenantId() {
        return CURRENT_TENANT.get();
    }

    public static Long requireTenantId() {
        Long id = CURRENT_TENANT.get();
        if (id == null) {
            throw new IllegalStateException(
                    "Tenant context not set. Did the request go through JwtAuthenticationFilter?");
        }
        return id;
    }

    public static boolean hasTenant() {
        return CURRENT_TENANT.get() != null;
    }

    public static void clear() {
        CURRENT_TENANT.remove();
    }
}
