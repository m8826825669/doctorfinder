package com.schoolerp.common.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
public enum ErrorCode {

    // Generic
    INTERNAL_ERROR("ERR_INTERNAL", HttpStatus.INTERNAL_SERVER_ERROR),
    VALIDATION_FAILED("ERR_VALIDATION", HttpStatus.BAD_REQUEST),
    BAD_REQUEST("ERR_BAD_REQUEST", HttpStatus.BAD_REQUEST),
    RESOURCE_NOT_FOUND("ERR_NOT_FOUND", HttpStatus.NOT_FOUND),
    RESOURCE_CONFLICT("ERR_CONFLICT", HttpStatus.CONFLICT),
    UNAUTHORIZED("ERR_UNAUTHORIZED", HttpStatus.UNAUTHORIZED),
    FORBIDDEN("ERR_FORBIDDEN", HttpStatus.FORBIDDEN),

    // Tenant
    TENANT_MISSING("ERR_TENANT_MISSING", HttpStatus.BAD_REQUEST),
    TENANT_MISMATCH("ERR_TENANT_MISMATCH", HttpStatus.FORBIDDEN),

    // Auth
    INVALID_CREDENTIALS("ERR_INVALID_CREDENTIALS", HttpStatus.UNAUTHORIZED),
    TOKEN_EXPIRED("ERR_TOKEN_EXPIRED", HttpStatus.UNAUTHORIZED),
    TOKEN_INVALID("ERR_TOKEN_INVALID", HttpStatus.UNAUTHORIZED),

    // Domain (extend per module)
    SCHOOL_NOT_FOUND("ERR_SCHOOL_NOT_FOUND", HttpStatus.NOT_FOUND),
    STUDENT_NOT_FOUND("ERR_STUDENT_NOT_FOUND", HttpStatus.NOT_FOUND);

    private final String code;
    private final HttpStatus status;
}
