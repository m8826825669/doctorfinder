package com.schoolerp.security.tenant;

import com.schoolerp.common.tenant.TenantContext;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.hibernate.Session;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Enables the {@code tenantFilter} Hibernate filter on every transactional
 * service method, scoped to the current {@link TenantContext}.
 * <p>
 * This means repos/queries on tenant entities automatically apply
 * {@code WHERE school_id = :currentTenant} — even native queries via
 * Hibernate's filter. No leakage even if a developer forgets.
 */
@Aspect
@Component
@Order(10)
@RequiredArgsConstructor
public class TenantFilterAspect {

    @PersistenceContext
    private EntityManager entityManager;

    @Around("@within(org.springframework.transaction.annotation.Transactional) " +
            "|| @annotation(org.springframework.transaction.annotation.Transactional)")
    public Object enableTenantFilter(ProceedingJoinPoint pjp) throws Throwable {
        Long tenantId = TenantContext.getTenantId();
        Session session = entityManager.unwrap(Session.class);

        if (tenantId != null) {
            session.enableFilter("tenantFilter").setParameter("schoolId", tenantId);
        }
        try {
            return pjp.proceed();
        } finally {
            if (tenantId != null) {
                session.disableFilter("tenantFilter");
            }
        }
    }
}
