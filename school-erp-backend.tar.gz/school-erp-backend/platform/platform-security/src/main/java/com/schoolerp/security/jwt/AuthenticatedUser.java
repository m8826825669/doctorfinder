package com.schoolerp.security.jwt;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class AuthenticatedUser {
    private final Long userId;
    private final Long schoolId;
    private final List<String> roles;
}
