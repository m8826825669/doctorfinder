package com.schoolerp.security.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class JwtUtil {

    public static final String CLAIM_SCHOOL_ID = "school_id";
    public static final String CLAIM_ROLES = "roles";
    public static final String CLAIM_TYPE = "typ";
    public static final String TYPE_ACCESS = "access";
    public static final String TYPE_REFRESH = "refresh";

    private final SecretKey secretKey;
    private final Duration accessTokenTtl;
    private final Duration refreshTokenTtl;
    private final String issuer;

    public JwtUtil(
            @Value("${app.security.jwt.secret}") String secret,
            @Value("${app.security.jwt.access-ttl:PT1H}") Duration accessTokenTtl,
            @Value("${app.security.jwt.refresh-ttl:P30D}") Duration refreshTokenTtl,
            @Value("${app.security.jwt.issuer:school-erp}") String issuer
    ) {
        if (secret == null || secret.length() < 32) {
            throw new IllegalArgumentException(
                    "app.security.jwt.secret must be at least 32 chars (256 bits) for HS256");
        }
        this.secretKey = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.accessTokenTtl = accessTokenTtl;
        this.refreshTokenTtl = refreshTokenTtl;
        this.issuer = issuer;
    }

    public String issueAccessToken(Long userId, Long schoolId, List<String> roles) {
        return buildToken(userId, schoolId, roles, TYPE_ACCESS, accessTokenTtl);
    }

    public String issueRefreshToken(Long userId, Long schoolId) {
        return buildToken(userId, schoolId, List.of(), TYPE_REFRESH, refreshTokenTtl);
    }

    private String buildToken(Long userId, Long schoolId, List<String> roles, String type, Duration ttl) {
        Instant now = Instant.now();
        return Jwts.builder()
                .issuer(issuer)
                .subject(String.valueOf(userId))
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(ttl)))
                .claims(Map.of(
                        CLAIM_SCHOOL_ID, schoolId,
                        CLAIM_ROLES, roles,
                        CLAIM_TYPE, type
                ))
                .signWith(secretKey)
                .compact();
    }

    public Claims parse(String token) {
        try {
            return Jwts.parser()
                    .verifyWith(secretKey)
                    .requireIssuer(issuer)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (JwtException e) {
            log.debug("JWT parse failed: {}", e.getMessage());
            throw e;
        }
    }
}
