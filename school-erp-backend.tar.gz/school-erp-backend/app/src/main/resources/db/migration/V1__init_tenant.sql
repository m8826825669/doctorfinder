-- ============================================================
-- V1: Bootstrap tenant table + audit conventions
-- ============================================================

CREATE TABLE schools (
    id              BIGSERIAL    PRIMARY KEY,
    name            VARCHAR(200) NOT NULL,
    subdomain       VARCHAR(100) NOT NULL,
    udise_code      VARCHAR(20),
    board           VARCHAR(30),
    primary_language VARCHAR(30),
    city            VARCHAR(100),
    state           VARCHAR(100),
    pin_code        VARCHAR(10),
    email           VARCHAR(200),
    phone           VARCHAR(20),
    gstin           VARCHAR(20),
    status          VARCHAR(20)  NOT NULL DEFAULT 'TRIAL',

    -- audit / soft delete / optimistic locking
    created_at      TIMESTAMPTZ  NOT NULL,
    updated_at      TIMESTAMPTZ  NOT NULL,
    created_by      BIGINT,
    updated_by      BIGINT,
    deleted_at      TIMESTAMPTZ,
    version         BIGINT       NOT NULL DEFAULT 0,

    CONSTRAINT uk_schools_subdomain  UNIQUE (subdomain),
    CONSTRAINT uk_schools_udise_code UNIQUE (udise_code),
    CONSTRAINT chk_schools_status    CHECK (status IN ('TRIAL', 'ACTIVE', 'SUSPENDED', 'INACTIVE')),
    CONSTRAINT chk_schools_board     CHECK (board IS NULL OR board IN ('CBSE', 'ICSE', 'STATE', 'IB', 'CAMBRIDGE', 'OTHER'))
);

CREATE INDEX idx_schools_status      ON schools(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_schools_subdomain   ON schools(subdomain) WHERE deleted_at IS NULL;

COMMENT ON TABLE schools IS 'Root tenant table — every other tenant-scoped table FKs school_id back here.';
COMMENT ON COLUMN schools.udise_code IS 'UDISE+ code (Govt of India). Optional but recommended.';
COMMENT ON COLUMN schools.gstin IS 'GST Identification Number — many schools are GST exempt; nullable.';
