package com.schoolerp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Main application bootstrap.
 * Component / entity / repository scanning is set to the root {@code com.schoolerp}
 * package so all modules (platform-* and module-*) are picked up.
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.schoolerp")
@EntityScan(basePackages = "com.schoolerp")
@EnableJpaRepositories(basePackages = "com.schoolerp")
public class SchoolErpApplication {

    public static void main(String[] args) {
        SpringApplication.run(SchoolErpApplication.class, args);
    }
}
