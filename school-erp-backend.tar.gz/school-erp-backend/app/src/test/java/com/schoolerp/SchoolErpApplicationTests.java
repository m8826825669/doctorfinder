package com.schoolerp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class SchoolErpApplicationTests {

    @Test
    void contextLoads() {
        // smoke: verifies all modules wire together and the Spring context boots
    }
}
